// --- views-academic.js ---
// الشؤون الأكاديمية والأجندة الذكية (مزودة بالتوجيه الذكي للتبويبات الفرعية)

var { useState, useEffect, useMemo } = React;
var ADMIN_EMAIL = "mohammadsafe202a@gmail.com";

// --- 1. الشؤون الأكاديمية (مواد وجدول) ---
window.AcademicView = ({ user, showAlert }) => {
    // التعديل هنا: قراءة الإشارة من الصفحة الرئيسية لتحديد التاب الافتراضي
    const [subTab, setSubTab] = useState(() => {
        const savedTab = localStorage.getItem('academic_subtab');
        if (savedTab) {
            setTimeout(() => localStorage.removeItem('academic_subtab'), 100);
            return savedTab;
        }
        return 'courses';
    }); 
    
    const [courses, setCourses] = useState([]); 
    const [loading, setLoading] = useState(true); 
    const [isAdding, setIsAdding] = useState(false); 
    const [newCourse, setNewCourse] = useState({ name: '', doctor: '', day: 'الأحد', time: '', maxAbsence: 4, credits: 3, grade: '' }); 
    const gradePoints = { 'A+': 4.0, 'A': 3.75, 'B+': 3.5, 'B': 3.0, 'C+': 2.5, 'C': 2.0, 'D+': 1.5, 'D': 1.0, 'F': 0 };
    const daysList = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس'];

    useEffect(() => { 
        const unsub = window.fb.onSnapshot(window.fb.query(window.fb.collection(window.fb.db, "courses"), window.fb.where("uid", "==", user.uid)), (s) => { 
            setCourses(s.docs.map(doc => ({ id: doc.id, ...doc.data() }))); 
            setLoading(false); 
            setTimeout(() => { if(window.lucide) window.lucide.createIcons() }, 100); 
        }); 
        return () => unsub(); 
    }, [user, subTab]);

    const gpa = useMemo(() => { let tP=0, tC=0; courses.forEach(c => { if(c.grade && gradePoints[c.grade] !== undefined) { const cr = parseFloat(c.credits||0); tP+=gradePoints[c.grade]*cr; tC+=cr; } }); return tC===0 ? "0.00" : (tP/tC).toFixed(2); }, [courses]);
    
    const handleAdd = async (e) => { e.preventDefault(); if(!newCourse.name) return; setIsAdding(true); try { await window.fb.addDoc(window.fb.collection(window.fb.db, "courses"), { uid: user.uid, ...newCourse, absences: 0, createdAt: new Date() }); setNewCourse({ name: '', doctor: '', day: 'الأحد', time: '', maxAbsence: 4, credits: 3, grade: '' }); setSubTab('courses'); } catch (error) {} finally { setIsAdding(false); } };
    const updateAbsence = async (c, ch) => { const n = (c.absences||0)+ch; if(n<0) return; await window.fb.updateDoc(window.fb.doc(window.fb.db, "courses", c.id), { absences: n }); };
    const handleDelete = (id) => { showAlert("حذف المادة", "هل أنت متأكد من حذف هذه المادة؟", "danger", async () => { await window.fb.deleteDoc(window.fb.doc(window.fb.db, "courses", id)); }); };
    
    const getCoursesForDay = (day) => courses.filter(c => c.day === day).sort((a,b) => (a.time||'').localeCompare(b.time||''));

    return (
        <div className="space-y-6 animate-fade-in">
            <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
                <div><h2 className="text-2xl font-bold text-slate-800 dark:text-white">الشؤون الأكاديمية</h2><p className="text-slate-500 dark:text-dark-muted text-sm mt-1">تتبع درجاتك، غيابك، وجدولك الدراسي</p></div>
                <div className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-6 py-3 rounded-2xl shadow-lg flex items-center gap-4 w-full md:w-auto">
                    <div><div className="text-xs opacity-80 font-bold uppercase">المعدل التراكمي</div><div className="text-2xl font-bold font-mono">{gpa}</div></div>
                    <div className="h-10 w-px bg-white/20"></div>
                    <div className="text-center"><div className="text-xs opacity-80 font-bold">المواد</div><div className="text-xl font-bold">{courses.length}</div></div>
                </div>
            </div>

            <div className="flex bg-slate-200/50 dark:bg-dark-card p-1.5 rounded-2xl mb-6 shadow-sm border border-slate-200 dark:border-dark-border relative">
                <button onClick={() => setSubTab('courses')} className={`flex-1 py-2.5 text-sm font-bold rounded-xl transition-all duration-300 flex justify-center items-center gap-2 ${subTab === 'courses' ? 'bg-white dark:bg-dark-bg shadow-sm text-indigo-600 dark:text-indigo-400' : 'text-slate-500 dark:text-slate-400 hover:text-indigo-500'}`}><i data-lucide="book-open" className="w-4 h-4"></i> إدارة المواد</button>
                <button onClick={() => setSubTab('timetable')} className={`flex-1 py-2.5 text-sm font-bold rounded-xl transition-all duration-300 flex justify-center items-center gap-2 ${subTab === 'timetable' ? 'bg-white dark:bg-dark-bg shadow-sm text-indigo-600 dark:text-indigo-400' : 'text-slate-500 dark:text-slate-400 hover:text-indigo-500'}`}><i data-lucide="calendar-days" className="w-4 h-4"></i> الجدول الأسبوعي</button>
            </div>

            {subTab === 'courses' && (
                <div className="space-y-6 animate-fade-in">
                    <div className="bg-white dark:bg-dark-card p-5 rounded-2xl shadow-sm border border-slate-200 dark:border-dark-border">
                        <h3 className="font-bold text-slate-700 dark:text-white mb-4 text-sm flex items-center gap-2"><i data-lucide="plus-circle" className="w-4 h-4 text-indigo-500"></i> تسجيل مادة جديدة</h3>
                        <form onSubmit={handleAdd} className="grid grid-cols-2 md:grid-cols-12 gap-3">
                            <input className="col-span-2 md:col-span-3 w-full h-11 px-3 border rounded-lg dark:bg-dark-bg dark:border-dark-border dark:text-white outline-none" placeholder="اسم المادة" required value={newCourse.name} onChange={e=>setNewCourse({...newCourse, name: e.target.value})} />
                            <input className="col-span-2 md:col-span-2 w-full h-11 px-3 border rounded-lg dark:bg-dark-bg dark:border-dark-border dark:text-white outline-none" placeholder="اسم المحاضر" value={newCourse.doctor} onChange={e=>setNewCourse({...newCourse, doctor: e.target.value})} />
                            <select className="col-span-1 md:col-span-2 w-full h-11 px-3 border rounded-lg bg-white dark:bg-dark-bg dark:border-dark-border dark:text-white" value={newCourse.day} onChange={e=>setNewCourse({...newCourse, day: e.target.value})}>{daysList.map(d=><option key={d} value={d}>{d}</option>)}</select>
                            <input type="time" className="col-span-1 md:col-span-2 w-full h-11 px-3 border rounded-lg dark:bg-dark-bg dark:border-dark-border dark:text-white" value={newCourse.time} onChange={e=>setNewCourse({...newCourse, time: e.target.value})} />
                            <select className="col-span-1 md:col-span-1 w-full h-11 px-3 border rounded-lg bg-white dark:bg-dark-bg dark:border-dark-border dark:text-white" value={newCourse.credits} onChange={e=>setNewCourse({...newCourse, credits: e.target.value})}><option value="1">1س</option><option value="2">2س</option><option value="3">3س</option><option value="4">4س</option><option value="5">5س</option></select>
                            <select className="col-span-1 md:col-span-1 w-full h-11 px-3 border rounded-lg bg-white dark:bg-dark-bg dark:border-dark-border dark:text-white" value={newCourse.grade} onChange={e=>setNewCourse({...newCourse, grade: e.target.value})}><option value="">التقدير</option>{Object.keys(gradePoints).map(g=><option key={g} value={g}>{g}</option>)}</select>
                            <input className="col-span-1 md:col-span-1 w-full h-11 px-3 border rounded-lg dark:bg-dark-bg dark:border-dark-border dark:text-white" type="number" min="1" placeholder="أقصى غياب" value={newCourse.maxAbsence} onChange={e=>setNewCourse({...newCourse, maxAbsence: parseInt(e.target.value)})} />
                            <button disabled={isAdding} className="col-span-2 md:col-span-12 h-11 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700 transition shadow-md flex items-center justify-center">{isAdding?'جاري الحفظ...':'إضافة المادة'}</button>
                        </form>
                    </div>

                    {loading ? <div className="text-center text-slate-400 py-10">جاري تحميل المواد...</div> : (
                        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                            {courses.length === 0 ? <div className="col-span-full text-center text-slate-400 py-6 border-2 border-dashed border-slate-200 rounded-2xl">لا توجد مواد مسجلة حتى الآن.</div> : courses.map(course => { 
                                const absences = course.absences||0; const max = course.maxAbsence||4; const isDanger = absences >= max - 1; const isCritical = absences >= max; const progress = Math.min((absences/max)*100, 100); 
                                return ( 
                                    <div key={course.id} className={`bg-white dark:bg-dark-card p-5 rounded-xl shadow-sm border relative group transition-all ${isCritical ? 'border-red-300 dark:border-red-900 bg-red-50 dark:bg-red-900/10' : 'border-slate-100 dark:border-dark-border hover:border-indigo-300'}`}>
                                        <div className="flex justify-between items-start mb-2">
                                            <div>
                                                <h3 className="font-bold text-lg text-slate-800 dark:text-white">{course.name}</h3>
                                                <div className="flex flex-wrap gap-2 text-xs text-slate-500 dark:text-dark-muted mt-2">
                                                    <span className="bg-slate-100 dark:bg-dark-bg px-2 py-1 rounded shadow-sm"><i data-lucide="calendar" className="w-3 h-3 inline mr-1"></i>{course.day}</span>
                                                    <span className="bg-slate-100 dark:bg-dark-bg px-2 py-1 rounded shadow-sm" dir="ltr"><i data-lucide="clock" className="w-3 h-3 inline ml-1"></i>{course.time || '--:--'}</span>
                                                    {course.grade && <span className="bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 px-2 py-1 rounded shadow-sm font-bold text-[10px]">{course.grade}</span>}
                                                </div>
                                            </div>
                                            <button onClick={()=>handleDelete(course.id)} className="text-slate-300 hover:text-red-500 p-1"><i data-lucide="trash-2" className="w-4 h-4"></i></button>
                                        </div>
                                        <div className="bg-slate-50 dark:bg-dark-bg/50 rounded-lg p-3 border border-slate-100 dark:border-dark-border mt-4">
                                            <div className="flex justify-between items-center mb-2">
                                                <span className="text-xs font-bold text-slate-600 dark:text-dark-muted">سجل الغياب: <span className={isDanger ? 'text-red-500' : 'text-indigo-600'}>{absences}</span> من {max}</span>
                                                <div className="flex gap-1">
                                                    <button onClick={()=>updateAbsence(course, -1)} className="w-7 h-7 rounded bg-white dark:bg-dark-card shadow-sm border border-slate-200 dark:border-dark-border flex items-center justify-center font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 transition">-</button>
                                                    <button onClick={()=>updateAbsence(course, 1)} className="w-7 h-7 rounded bg-indigo-50 dark:bg-indigo-900/30 border border-indigo-100 dark:border-indigo-800 flex items-center justify-center font-bold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 transition">+</button>
                                                </div>
                                            </div>
                                            <div className="w-full bg-slate-200 dark:bg-dark-border rounded-full h-2 overflow-hidden"><div className={`h-2 rounded-full transition-all duration-500 ${isDanger ? 'bg-red-500' : 'bg-indigo-500'}`} style={{ width: `${progress}%` }}></div></div>
                                        </div>
                                    </div> 
                                ); 
                            })}
                        </div>
                    )}
                </div>
            )}

            {subTab === 'timetable' && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 animate-fade-in">
                    {daysList.map(day => { 
                        const dayCourses = getCoursesForDay(day); 
                        return ( 
                            <div key={day} className={`rounded-2xl border p-5 transition-all hover:shadow-md ${dayCourses.length > 0 ? 'bg-white dark:bg-dark-card border-slate-200 dark:border-dark-border' : 'bg-slate-50 dark:bg-dark-bg border-dashed border-2 border-slate-200 dark:border-dark-border opacity-70'}`}>
                                <h3 className="font-bold text-indigo-600 dark:text-indigo-400 mb-4 flex items-center justify-between"><span className="flex items-center gap-2"><i data-lucide="calendar" className="w-4 h-4"></i> {day}</span>{dayCourses.length > 0 && <span className="text-[10px] bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 px-2 py-1 rounded-md font-bold">{dayCourses.length} محاضرات</span>}</h3>
                                <div className="space-y-3">
                                    {dayCourses.length > 0 ? dayCourses.map(course => (
                                        <div key={course.id} className="bg-slate-50 dark:bg-dark-bg/60 p-3 rounded-xl border border-slate-100 dark:border-dark-border shadow-sm flex items-center gap-3">
                                            <div className="bg-white dark:bg-dark-card p-2 rounded-lg text-indigo-600 dark:text-indigo-400 font-bold text-xs w-16 text-center shadow-sm shrink-0" dir="ltr">{course.time ? new Date('1970-01-01T' + course.time).toLocaleTimeString('en-US', {hour: 'numeric', minute:'2-digit'}) : '--:--'}</div>
                                            <div><div className="font-bold text-slate-800 dark:text-white text-sm">{course.name}</div><div className="text-[10px] text-slate-500 dark:text-dark-muted mt-1 font-medium"><i data-lucide="user" className="w-3 h-3 inline"></i> {course.doctor || '---'}</div></div>
                                        </div>
                                    )) : <p className="text-xs text-slate-400 dark:text-slate-500 text-center py-6 font-bold">يوم حر</p>}
                                </div>
                            </div> 
                        ); 
                    })}
                </div>
            )}
        </div>
    );
};

// --- 2. الأجندة الذكية (مهام وامتحانات) ---
window.AgendaView = ({ user, showAlert }) => {
    const [subTab, setSubTab] = useState(() => {
        const savedTab = localStorage.getItem('agenda_subtab');
        if (savedTab) {
            setTimeout(() => localStorage.removeItem('agenda_subtab'), 100);
            return savedTab;
        }
        return 'tasks';
    }); 
    
    const [tasks, setTasks] = useState([]); const [newTask, setNewTask] = useState(''); 
    const [exams, setExams] = useState([]); const [newExam, setNewExam] = useState({ subject: '', type: 'Final', date: '', location: '' }); 
    const [isAddingExam, setIsAddingExam] = useState(false); const [loading, setLoading] = useState(true);

    useEffect(() => { 
        const unsubTasks = window.fb.onSnapshot(window.fb.query(window.fb.collection(window.fb.db, "tasks"), window.fb.where("uid", "==", user.uid)), s => { 
            setTasks(s.docs.map(doc => ({id:doc.id, ...doc.data()})).sort((a,b)=>b.createdAt?.seconds - a.createdAt?.seconds)); 
        }); 
        const unsubExams = window.fb.onSnapshot(window.fb.query(window.fb.collection(window.fb.db, "exams"), window.fb.where("uid", "==", user.uid)), (s) => { 
            setExams(s.docs.map(doc => ({ id: doc.id, ...doc.data() })).sort((a, b) => new Date(a.date) - new Date(b.date))); setLoading(false); 
        }); 
        return () => { unsubTasks(); unsubExams(); }; 
    }, [user.uid]);

    useEffect(() => { setTimeout(() => { if(window.lucide) window.lucide.createIcons(); }, 50); }, [subTab, tasks, exams]);

    const addTask = async (e) => { e.preventDefault(); if(newTask.trim()) { await window.fb.addDoc(window.fb.collection(window.fb.db, "tasks"), {uid:user.uid, title:newTask, completed:false, createdAt:new Date()}); setNewTask(''); } };
    const toggleTask = async (t) => await window.fb.updateDoc(window.fb.doc(window.fb.db, "tasks", t.id), {completed: !t.completed});
    const delTask = (id) => { showAlert("حذف المهمة", "هل تريد حذف هذه المهمة نهائياً؟", "danger", async () => { await window.fb.deleteDoc(window.fb.doc(window.fb.db, "tasks", id)); }); };
    
    const addExam = async (e) => { e.preventDefault(); if(!newExam.subject || !newExam.date) return; setIsAddingExam(true); try { await window.fb.addDoc(window.fb.collection(window.fb.db, "exams"), { uid: user.uid, ...newExam, createdAt: new Date() }); setNewExam({ subject: '', type: 'Final', date: '', location: '' }); } catch(err) {} finally { setIsAddingExam(false); } };
    const deleteExam = (id) => { showAlert("حذف الامتحان", "هل أنت متأكد من حذف هذا الامتحان؟", "danger", async () => { await window.fb.deleteDoc(window.fb.doc(window.fb.db, "exams", id)); }); };
    const getTimeLeft = (d) => { const t = Date.parse(d) - Date.parse(new Date()); return { t, days: Math.floor(t / (1000*60*60*24)), hours: Math.floor((t / (1000*60*60)) % 24) }; };

    return (
        <div className="space-y-6 animate-fade-in">
            <div className="flex justify-between items-center mb-2"><div><h2 className="text-2xl font-bold text-slate-800 dark:text-white">الأجندة الذكية</h2><p className="text-slate-500 text-sm mt-1">نظم وقتك، مهامك وامتحاناتك</p></div></div>
            <div className="flex bg-slate-200/50 dark:bg-dark-card p-1.5 rounded-2xl shadow-sm border border-slate-200 dark:border-dark-border relative">
                <button onClick={() => setSubTab('tasks')} className={`flex-1 py-2.5 text-sm font-bold rounded-xl transition-all flex justify-center items-center gap-2 ${subTab === 'tasks' ? 'bg-white dark:bg-dark-bg shadow-sm text-indigo-600' : 'text-slate-500 hover:text-indigo-500'}`}><i data-lucide="list-todo" className="w-4 h-4"></i> المهام المعلقة</button>
                <button onClick={() => setSubTab('exams')} className={`flex-1 py-2.5 text-sm font-bold rounded-xl transition-all flex justify-center items-center gap-2 ${subTab === 'exams' ? 'bg-white dark:bg-dark-bg shadow-sm text-indigo-600' : 'text-slate-500 hover:text-indigo-500'}`}><i data-lucide="alarm-clock" className="w-4 h-4"></i> الامتحانات</button>
            </div>

            {subTab === 'tasks' && (
                <div className="max-w-2xl mx-auto space-y-6 animate-fade-in">
                    <form onSubmit={addTask} className="relative"><input className="w-full h-14 pl-14 pr-4 rounded-2xl border border-slate-200 dark:border-dark-border dark:bg-dark-card dark:text-white shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" placeholder="إضافة مهمة جديدة..." value={newTask} onChange={e=>setNewTask(e.target.value)} /><button className="absolute left-2 top-2 bottom-2 bg-indigo-600 text-white px-4 rounded-xl font-bold hover:bg-indigo-700 transition"><i data-lucide="plus" className="w-5 h-5"></i></button></form>
                    <div className="space-y-3">
                        {loading ? <p className="text-center text-slate-400">تحميل المهام...</p> : tasks.length === 0 ? <p className="text-center text-slate-400 py-6">لا توجد مهام حالياً</p> : tasks.map(t=>(
                            <div key={t.id} className={`flex items-center gap-4 p-4 rounded-xl border transition-all ${t.completed ? 'opacity-60 bg-slate-50 dark:bg-dark-bg' : 'bg-white dark:bg-dark-card shadow-sm border-slate-100 dark:border-dark-border'}`}>
                                <button onClick={()=>toggleTask(t)} className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${t.completed?'bg-green-500 border-green-500':'border-slate-300 dark:border-slate-500'}`}>{t.completed && <i data-lucide="check" className="w-3 h-3 text-white"></i>}</button>
                                <span className={`flex-1 font-medium ${t.completed?'line-through text-slate-400':'text-slate-800 dark:text-white'}`}>{t.title}</span>
                                <button onClick={()=>delTask(t.id)} className="text-slate-300 hover:text-red-500 p-1"><i data-lucide="trash-2" className="w-4 h-4"></i></button>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {subTab === 'exams' && (
                <div className="space-y-6 animate-fade-in">
                    <div className="bg-white dark:bg-dark-card p-5 rounded-2xl shadow-sm border border-slate-200 dark:border-dark-border">
                        <form onSubmit={addExam} className="grid grid-cols-2 md:grid-cols-5 gap-3">
                            <input className="col-span-2 md:col-span-2 w-full h-11 px-3 border rounded-lg dark:bg-dark-bg dark:border-dark-border dark:text-white outline-none" placeholder="اسم المادة" required value={newExam.subject} onChange={e => setNewExam({...newExam, subject: e.target.value})} />
                            <select className="w-full h-11 px-3 border rounded-lg bg-white dark:bg-dark-bg dark:border-dark-border dark:text-white outline-none" value={newExam.type} onChange={e => setNewExam({...newExam, type: e.target.value})}><option value="Final">Final</option><option value="Midterm">Midterm</option><option value="Quiz">Quiz</option><option value="Practical">عملي</option></select>
                            <input type="datetime-local" className="col-span-2 md:col-span-1 w-full h-11 px-3 border rounded-lg dark:bg-dark-bg dark:border-dark-border dark:text-white outline-none" required value={newExam.date} onChange={e => setNewExam({...newExam, date: e.target.value})} />
                            <input className="w-full h-11 px-3 border rounded-lg dark:bg-dark-bg dark:border-dark-border dark:text-white outline-none" placeholder="القاعة" value={newExam.location} onChange={e => setNewExam({...newExam, location: e.target.value})} />
                            <button disabled={isAddingExam} className="col-span-2 md:col-span-5 h-11 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700 transition">{isAddingExam ? '...' : 'حفظ الموعد'}</button>
                        </form>
                    </div>
                    {loading ? <div className="text-center p-10 text-slate-400">تحميل...</div> : <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {exams.length === 0 ? <div className="col-span-full text-center text-slate-400 py-6">لا توجد امتحانات قادمة.</div> : exams.map(exam => { 
                            const { t, days, hours } = getTimeLeft(exam.date); const isPassed = t < 0; const isUrgent = days < 2 && !isPassed; 
                            return ( 
                                <div key={exam.id} className={`p-5 rounded-xl border relative overflow-hidden transition-all ${isPassed ? 'bg-slate-100 dark:bg-dark-bg border-slate-200 opacity-70' : isUrgent ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800' : 'bg-white dark:bg-dark-card border-slate-200 dark:border-dark-border'}`}>
                                    <div className="flex justify-between items-start mb-4 relative z-10">
                                        <div>
                                            <div className="flex items-center gap-2 mb-1"><h3 className="font-bold text-lg text-slate-800 dark:text-white">{exam.subject}</h3><span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${exam.type==='Final'?'bg-red-100 text-red-700': 'bg-blue-100 text-blue-700'}`}>{exam.type}</span></div>
                                            <p className="text-sm text-slate-500 dark:text-dark-muted flex items-center gap-2"><i data-lucide="map-pin" className="w-3 h-3"></i> {exam.location||'-'} <i data-lucide="calendar" className="w-3 h-3 ml-2"></i> {new Date(exam.date).toLocaleString('ar-EG', {month: 'short', day: 'numeric', hour: '2-digit', minute:'2-digit'})}</p>
                                        </div>
                                        <button onClick={() => deleteExam(exam.id)} className="text-slate-300 hover:text-red-500 p-1"><i data-lucide="trash-2" className="w-4 h-4"></i></button>
                                    </div>
                                    <div className="flex items-center gap-4 border-t border-slate-200 dark:border-dark-border pt-3">
                                        {!isPassed ? <><div className="flex-1 text-center"><div className={`text-2xl font-bold font-mono ${isUrgent?'text-red-600 animate-pulse':'text-slate-800 dark:text-white'}`}>{days}</div><div className="text-[10px] text-slate-400 uppercase font-bold">يوم</div></div><div className="w-px h-8 bg-slate-200 dark:bg-dark-border"></div><div className="flex-1 text-center"><div className={`text-2xl font-bold font-mono ${isUrgent?'text-red-600':'text-slate-800 dark:text-white'}`}>{hours}</div><div className="text-[10px] text-slate-400 uppercase font-bold">ساعة</div></div></> : <div className="w-full text-center text-slate-400 font-bold">انتهى</div>}
                                    </div>
                                </div> 
                            ); 
                        })}
                    </div>}
                </div>
            )}
        </div>
    );
};
