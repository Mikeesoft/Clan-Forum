// --- app-auth.js ---
// ملف المصادقة الشامل (تسجيل الدخول، إنشاء حساب، تحديد الرتبة، واستعادة كلمة المرور 🔐👨‍🏫)

var { useState } = React;

window.AuthScreen = ({ onClose }) => {
    const [isRegister, setIsRegister] = useState(false);
    const [isResetting, setIsResetting] = useState(false); 
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('student'); // حالة الرتبة (طالب أو دكتور)
    
    const [error, setError] = useState('');
    const [successMsg, setSuccessMsg] = useState('');
    const [loading, setLoading] = useState(false);
    
    // 🌟 دالة استعادة كلمة المرور 🌟
    const handleResetPassword = async (e) => {
        e.preventDefault();
        setError(''); setSuccessMsg(''); setLoading(true);
        try {
            await window.fb.sendPasswordResetEmail(window.fb.auth, email);
            setSuccessMsg("تم إرسال رابط استعادة كلمة المرور. يرجى مراجعة بريدك الإلكتروني (صندوق الوارد أو الـ Spam).");
            setEmail('');
        } catch (err) {
            setError("تعذر إرسال الرابط. يرجى التأكد من صحة البريد الإلكتروني أو أنه مسجل لدينا.");
        } finally {
            setLoading(false);
        }
    };

    // 🌟 دالة تسجيل الدخول وإنشاء الحساب 🌟
    const handleSubmit = async (e) => {
        e.preventDefault(); setError(''); setSuccessMsg(''); setLoading(true);
        try {
            const { auth, signInWithEmailAndPassword, createUserWithEmailAndPassword, updateProfile } = window.fb;
            
            if (isRegister) { 
                const userCredential = await createUserWithEmailAndPassword(auth, email, password); 
                if(name) await updateProfile(userCredential.user, { displayName: name });
                
                try {
                    // 1. حفظ البيانات العامة (عشان يشوفها باقي الطلاب)
                    const userPublicRef = window.fb.doc(window.fb.db, "users", userCredential.user.uid);
                    await window.fb.setDoc(userPublicRef, { 
                        name: name, 
                        isOnline: true, 
                        photo: '', 
                        uniId: '', 
                        role: role, // حفظ الرتبة هنا ليقرأها البروفايل العام
                        createdAt: Date.now() 
                    }, { merge: true });

                    // 2. حفظ البيانات الخاصة (الخزنة السرية للمستخدم)
                    const userPrivateRef = window.fb.doc(window.fb.db, "users_private", userCredential.user.uid);
                    await window.fb.setDoc(userPrivateRef, { 
                        email: email, 
                        balance: 0, 
                        role: role, // حفظ الرتبة هنا للصلاحيات
                        isBanned: false, 
                        isVerified: false, 
                        isCouncil: false,
                        councilPermissions: { manageForum: false, manageContent: false, manageUsers: false },
                        createdAt: Date.now() 
                    }, { merge: true });

                } catch(e) {}
            } 
            else { 
                await signInWithEmailAndPassword(auth, email, password); 
            }
        } catch (err) { 
            setError("يرجى التأكد من البريد الإلكتروني وكلمة المرور."); 
        } finally { 
            setLoading(false); 
        }
    };
    
    return (
        <div className="min-h-screen bg-slate-100 dark:bg-dark-bg flex items-center justify-center p-4 relative">
            <div className="bg-white dark:bg-dark-card w-full max-w-md rounded-2xl shadow-xl overflow-hidden border dark:border-dark-border animate-zoom-in relative">
                
                {/* الهيدر العلوي */}
                <div className="bg-indigo-600 p-8 text-center relative overflow-hidden">
                    {onClose && (
                        <button onClick={onClose} className="absolute top-4 left-4 p-2 bg-white/20 hover:bg-white/30 rounded-full transition text-white z-20" title="العودة كزائر">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                        </button>
                    )}
                    <div className="absolute inset-0 bg-white/5 transform skew-y-6 scale-150"></div>
                    <i data-lucide={isResetting ? "key" : "graduation-cap"} className="w-14 h-14 text-white mx-auto mb-3 relative z-10 animate-fade-in"></i>
                    <h1 className="text-2xl font-bold text-white relative z-10">{isResetting ? 'استعادة الحساب' : 'جامعتي'}</h1>
                    <p className="text-indigo-100 text-sm relative z-10">{isResetting ? 'لا تقلق، سنساعدك في العودة' : 'بوابتك الذكية للحياة الجامعية'}</p>
                </div>

                <div className="p-8">
                    <h2 className="text-xl font-bold text-slate-800 dark:text-white mb-6 text-center">
                        {isResetting ? 'نسيت كلمة المرور؟' : isRegister ? 'إنشاء حساب جديد' : 'تسجيل الدخول'}
                    </h2>
                    
                    {/* رسائل الخطأ والنجاح */}
                    {error && <div className="bg-red-50 text-red-600 p-3 rounded-xl text-sm mb-4 border border-red-100 flex items-start gap-2 animate-fade-in"><i data-lucide="alert-circle" className="w-4 h-4 shrink-0 mt-0.5"></i><p>{error}</p></div>}
                    {successMsg && <div className="bg-emerald-50 text-emerald-600 p-3 rounded-xl text-sm mb-4 border border-emerald-100 flex items-start gap-2 animate-fade-in"><i data-lucide="check-circle" className="w-4 h-4 shrink-0 mt-0.5"></i><p>{successMsg}</p></div>}
                    
                    {isResetting ? (
                        /* 🌟 واجهة استعادة كلمة المرور 🌟 */
                        <form onSubmit={handleResetPassword} className="space-y-4 animate-fade-in">
                            <p className="text-sm text-slate-500 dark:text-slate-400 text-center mb-4">أدخل بريدك الإلكتروني المسجل لدينا وسنرسل لك رابطاً لإنشاء كلمة مرور جديدة.</p>
                            <input type="email" required className="w-full h-12 px-4 border border-slate-200 dark:border-dark-border rounded-xl bg-white dark:bg-dark-bg dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 transition text-left" dir="ltr" value={email} onChange={e => setEmail(e.target.value)} placeholder="name@example.com" />
                            <button disabled={loading || !email} className={`w-full h-12 rounded-xl font-bold transition flex justify-center items-center gap-2 ${loading || !email ? 'bg-indigo-400 text-white cursor-not-allowed' : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-md hover:shadow-lg active:scale-95'}`}>
                                {loading ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div> : 'إرسال رابط الاستعادة'}
                            </button>
                            <button type="button" onClick={() => {setIsResetting(false); setError(''); setSuccessMsg('');}} className="mt-4 w-full text-slate-500 hover:text-slate-700 dark:hover:text-white text-sm font-medium transition flex items-center justify-center gap-1">
                                <i data-lucide="arrow-right" className="w-4 h-4 rtl:-scale-x-100"></i> العودة لتسجيل الدخول
                            </button>
                        </form>
                    ) : (
                        /* 🌟 واجهة الدخول والتسجيل العادية 🌟 */
                        <>
                            <form onSubmit={handleSubmit} className="space-y-4 animate-fade-in">
                                {isRegister && (
                                    <>
                                        {/* 🌟 أزرار تحديد الرتبة 🌟 */}
                                        <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl gap-1 mb-2">
                                            <button 
                                                type="button" 
                                                onClick={() => setRole('student')} 
                                                className={`flex-1 py-2.5 text-xs font-bold rounded-lg transition-all ${role === 'student' ? 'bg-white dark:bg-indigo-600 shadow-sm text-indigo-600 dark:text-white' : 'text-slate-500 dark:text-slate-400'}`}
                                            >
                                                أنا طالب
                                            </button>
                                            <button 
                                                type="button" 
                                                onClick={() => setRole('doctor')} 
                                                className={`flex-1 py-2.5 text-xs font-bold rounded-lg transition-all ${role === 'doctor' ? 'bg-white dark:bg-indigo-600 shadow-sm text-indigo-600 dark:text-white' : 'text-slate-500 dark:text-slate-400'}`}
                                            >
                                                أنا دكتور/معيد
                                            </button>
                                        </div>

                                        <input type="text" required className="w-full h-12 px-4 border border-slate-200 dark:border-dark-border rounded-xl bg-white dark:bg-dark-bg dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 transition" value={name} onChange={e => setName(e.target.value)} placeholder="الاسم ثلاثي" />
                                    </>
                                )}
                                
                                <input type="email" required className="w-full h-12 px-4 border border-slate-200 dark:border-dark-border rounded-xl bg-white dark:bg-dark-bg dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 transition text-left" dir="ltr" value={email} onChange={e => setEmail(e.target.value)} placeholder="البريد الإلكتروني" />
                                <input type="password" required className="w-full h-12 px-4 border border-slate-200 dark:border-dark-border rounded-xl bg-white dark:bg-dark-bg dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 transition text-left" dir="ltr" value={password} onChange={e => setPassword(e.target.value)} placeholder="كلمة المرور" />
                                
                                {!isRegister && (
                                    <div className="flex justify-end mt-1">
                                        <button type="button" onClick={() => {setIsResetting(true); setError('');}} className="text-xs font-bold text-indigo-500 hover:text-indigo-700 transition">
                                            نسيت كلمة المرور؟
                                        </button>
                                    </div>
                                )}

                                <button disabled={loading} className="w-full h-12 bg-indigo-600 text-white rounded-xl font-bold shadow-md hover:bg-indigo-700 hover:shadow-lg active:scale-95 transition flex justify-center items-center gap-2 mt-2">
                                    {loading ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div> : (isRegister ? 'إنشاء حساب جديد' : 'تسجيل الدخول')}
                                </button>
                            </form>
                            
                            <div className="mt-6 pt-6 border-t border-slate-100 dark:border-slate-800 text-center">
                                <p className="text-slate-500 text-sm mb-3">{isRegister ? 'لديك حساب بالفعل؟' : 'ليس لديك حساب جامعي؟'}</p>
                                <button onClick={() => {setIsRegister(!isRegister); setError('');}} className="w-full h-11 border-2 border-indigo-100 dark:border-indigo-900/50 text-indigo-600 dark:text-indigo-400 font-bold rounded-xl hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition">
                                    {isRegister ? 'تسجيل الدخول' : 'انضم إلينا الآن'}
                                </button>
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};
