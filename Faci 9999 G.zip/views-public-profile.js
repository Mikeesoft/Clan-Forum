// --- views-public-profile.js ---
// ملف الملف الشخصي العام (يُظهر بادج المشرف العام 👑 وبادج الدكاترة 👨‍🏫 وعلامة مجلس الطلاب والتوثيق)

var { useState, useEffect } = React;

window.PublicProfileView = ({ currentUser, targetUid, onBack, showAlert, setTab }) => {
    const [profile, setProfile] = useState(null);
    const [currentData, setCurrentData] = useState(null); 
    const [loading, setLoading] = useState(true);
    
    const [friendStatus, setFriendStatus] = useState('none'); 
    const [actionLoading, setActionLoading] = useState(false);

    const [userPosts, setUserPosts] = useState([]);
    const [loadingPosts, setLoadingPosts] = useState(true);

    const ADMIN_EMAIL = "mohammadsafe202a@gmail.com";
    const isAdmin = currentUser.email === ADMIN_EMAIL;

    const getFriendshipId = () => {
        return currentUser.uid < targetUid ? `${currentUser.uid}_${targetUid}` : `${targetUid}_${currentUser.uid}`;
    };

    useEffect(() => {
        if (!targetUid) return;

        let unsubUser = () => {};
        let unsubFriendship = () => {};
        let unsubCurrent = () => {};
        let unsubPosts = () => {};

        const fetchData = async () => {
            try {
                const userRef = window.fb.doc(window.fb.db, "users", targetUid);
                unsubUser = window.fb.onSnapshot(userRef, (docSnap) => {
                    if (docSnap.exists()) {
                        const data = docSnap.data();
                        setProfile({
                            name: data.name || 'مجهول',
                            photo: data.photo || '',
                            isOnline: data.isOnline || false,
                            uniId: data.uniId || '---',
                            email: data.email || '',
                            role: data.role || 'student', 
                            isVerified: data.isVerified || false,
                            isCouncil: data.isCouncil || false
                        });
                    }
                });

                const currentRef = window.fb.doc(window.fb.db, "users", currentUser.uid);
                unsubCurrent = window.fb.onSnapshot(currentRef, (docSnap) => {
                    if (docSnap.exists()) setCurrentData(docSnap.data());
                });

                const friendshipRef = window.fb.doc(window.fb.db, "friendships", getFriendshipId());
                unsubFriendship = window.fb.onSnapshot(friendshipRef, (docSnap) => {
                    if (docSnap.exists()) {
                        const data = docSnap.data();
                        if (data.status === 'accepted') { setFriendStatus('friends'); } 
                        else if (data.status === 'pending') {
                            if (data.senderId === currentUser.uid) { setFriendStatus('pending_sent'); } 
                            else { setFriendStatus('pending_received'); }
                        }
                    } else { setFriendStatus('none'); }
                    setLoading(false);
                });

                const qPosts = window.fb.query(window.fb.collection(window.fb.db, "forum_posts"), window.fb.where("uid", "==", targetUid));
                unsubPosts = window.fb.onSnapshot(qPosts, (snap) => {
                    const fetched = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                    const publicPosts = fetched.filter(p => !p.isAnonymous);
                    publicPosts.sort((a, b) => window.getSafeTime(b.createdAt) - window.getSafeTime(a.createdAt));
                    setUserPosts(publicPosts);
                    setLoadingPosts(false);
                });

            } catch (err) { setLoading(false); }
        };

        fetchData();

        return () => { unsubUser(); unsubFriendship(); unsubCurrent(); unsubPosts(); };
    }, [targetUid, currentUser.uid]);

    useEffect(() => { 
        let timeoutId;
        if (window.lucide) { timeoutId = setTimeout(() => { try { window.lucide.createIcons(); } catch(e) {} }, 50); }
        return () => clearTimeout(timeoutId);
    }, [friendStatus, loading, profile, actionLoading, userPosts]);

    const handleSendRequest = async () => {
        setActionLoading(true);
        try {
            const friendshipRef = window.fb.doc(window.fb.db, "friendships", getFriendshipId());
            await window.fb.setDoc(friendshipRef, {
                users: [currentUser.uid, targetUid], status: 'pending', senderId: currentUser.uid, createdAt: Date.now()
            });

            await window.fb.addDoc(window.fb.collection(window.fb.db, "interactions"), {
                recipientUid: targetUid, senderUid: currentUser.uid, senderName: currentData?.name || currentUser.displayName || 'طالب',
                senderPhoto: currentData?.photo || '', type: 'friend_request', postSnippet: 'أرسل لك طلب صداقة', createdAt: Date.now(), seen: false
            });

        } catch (e) { showAlert("خطأ", "لم يتم إرسال الطلب.", "danger", ()=>{}); }
        finally { setTimeout(() => setActionLoading(false), 500); } 
    };

    const handleCancelOrRemove = async (isRemove) => {
        const msg = isRemove ? "هل تريد إزالة هذا الصديق؟" : "هل تريد إلغاء طلب الصداقة؟";
        showAlert("تأكيد", msg, "danger", async () => {
            setActionLoading(true);
            try { await window.fb.deleteDoc(window.fb.doc(window.fb.db, "friendships", getFriendshipId())); } 
            catch (e) {} finally { setTimeout(() => setActionLoading(false), 500); }
        });
    };

    const handleAcceptRequest = async () => {
        setActionLoading(true);
        try {
            const friendshipRef = window.fb.doc(window.fb.db, "friendships", getFriendshipId());
            await window.fb.updateDoc(friendshipRef, { status: 'accepted', updatedAt: Date.now() });

            await window.fb.addDoc(window.fb.collection(window.fb.db, "interactions"), {
                recipientUid: targetUid, senderUid: currentUser.uid, senderName: currentData?.name || currentUser.displayName || 'طالب',
                senderPhoto: currentData?.photo || '',  type: 'friend_accept', postSnippet: 'وافق على طلب الصداقة', createdAt: Date.now(), seen: false
            });
        } catch (e) {} finally { setTimeout(() => setActionLoading(false), 500); }
    };

    const handleOpenChat = () => {
        localStorage.setItem('openChatWithUid', targetUid); 
        if (onBack) onBack(); 
        if (setTab) setTab('profile'); 
    };

    if (loading) return (
        <div className="flex flex-col items-center justify-center py-20 animate-fade-in">
            <div className="spinner w-8 h-8 border-4 border-indigo-500 mb-4"></div>
            <p className="text-slate-500 font-bold">جاري تحميل الملف الشخصي...</p>
        </div>
    );

    if (!profile) return (
        <div className="text-center py-20">
            <p className="text-slate-500 font-bold">هذا الحساب غير موجود أو تم حذفه.</p>
            <button onClick={onBack} className="mt-4 text-indigo-600 font-bold">العودة</button>
        </div>
    );

    return (
        <div className="max-w-2xl mx-auto space-y-6 animate-fade-in pb-10 relative">
            <div className="flex items-center gap-3 mb-2">
                <button onClick={onBack} className="w-10 h-10 bg-white dark:bg-dark-card border border-slate-200 dark:border-dark-border rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors shadow-sm">
                    <i data-lucide="arrow-right" className="w-5 h-5 rtl:-scale-x-100"></i>
                </button>
                <h2 className="text-xl font-bold text-slate-800 dark:text-white">الملف الشخصي</h2>
            </div>

            <div className="bg-white dark:bg-dark-card p-6 rounded-3xl shadow-sm border border-slate-200 dark:border-dark-border relative overflow-hidden">
                <div className="flex flex-col items-center pt-4 pb-2">
                    <div className="relative mb-4">
                        <div className="w-28 h-28 rounded-full border-4 border-indigo-50 dark:border-indigo-900/30 overflow-hidden bg-slate-100 dark:bg-dark-bg flex items-center justify-center shadow-lg">
                            {profile.photo ? <img src={profile.photo} alt="Profile" className="w-full h-full object-cover" /> : <i data-lucide="user" className="w-12 h-12 text-slate-400"></i>}
                        </div>
                        {profile.isOnline && <div className="absolute bottom-1 right-1 w-5 h-5 bg-green-500 border-4 border-white dark:border-dark-card rounded-full" title="متصل الآن"></div>}
                    </div>
                    
                    <h3 className="font-bold text-2xl text-slate-800 dark:text-white mb-1 text-center flex items-center justify-center gap-1.5">
                        {profile.name}
                        {/* 🌟 علامة التوثيق 🌟 */}
                        <span style={{ display: (profile.email === ADMIN_EMAIL || profile.isVerified) ? 'inline-flex' : 'none' }} title="حساب موثق">
                            <i data-lucide="badge-check" className="w-6 h-6 text-blue-500"></i>
                        </span>
                        {/* 🌟 علامة مجلس الطلاب التي تم إرجاعها 🌟 */}
                        <span style={{ display: (profile.email === ADMIN_EMAIL || profile.isCouncil) ? 'inline-flex' : 'none' }} title="مجلس الطلاب">
                            <i data-lucide="crown" className="w-6 h-6 text-orange-500"></i>
                        </span>
                    </h3>
                    
                    {/* بادج الرتبة */}
                    <div className="flex gap-2 items-center mb-6 mt-1">
                        {profile.email === ADMIN_EMAIL ? (
                            <span className="text-xs font-bold text-amber-600 bg-amber-50 dark:bg-amber-900/20 dark:text-amber-400 px-3 py-1.5 rounded-full flex items-center gap-1.5 border border-amber-100 dark:border-amber-800/50 shadow-sm">
                                <i data-lucide="crown" className="w-3.5 h-3.5"></i> المشرف العام
                            </span>
                        ) : profile.role === 'doctor' ? (
                            <span className="text-xs font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 dark:text-emerald-400 px-3 py-1.5 rounded-full flex items-center gap-1.5 border border-emerald-100 dark:border-emerald-800/50 shadow-sm">
                                <i data-lucide="briefcase" className="w-3.5 h-3.5"></i> عضو هيئة تدريس
                            </span>
                        ) : (
                            <span className="text-sm text-slate-500 font-medium flex items-center gap-1.5">
                                <i data-lucide="graduation-cap" className="w-4 h-4 text-indigo-400"></i> طالب جامعي
                            </span>
                        )}
                    </div>

                    <div className="flex w-full gap-3 mt-2 border-t border-slate-100 dark:border-dark-border pt-6">
                        {friendStatus === 'none' && (
                            <button onClick={handleSendRequest} disabled={actionLoading} className={`flex-1 h-12 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-md ${actionLoading ? 'bg-indigo-400 text-indigo-100 cursor-not-allowed' : 'bg-indigo-600 text-white hover:bg-indigo-700'}`}>
                                <span style={{ display: actionLoading ? 'none' : 'flex' }} className="items-center gap-2"><i data-lucide="user-plus" className="w-5 h-5"></i> إضافة صديق</span>
                                <span style={{ display: actionLoading ? 'flex' : 'none' }} className="items-center gap-2 text-sm"><div className="spinner w-4 h-4 border-2 border-indigo-100"></div> جاري الطلب...</span>
                            </button>
                        )}
                        {friendStatus === 'pending_sent' && (
                            <button onClick={() => handleCancelOrRemove(false)} disabled={actionLoading} className={`flex-1 h-12 rounded-xl font-bold transition-all flex items-center justify-center gap-2 border ${actionLoading ? 'bg-slate-200 text-slate-400 border-slate-200' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300 hover:bg-slate-200 border-slate-200 dark:border-slate-700'}`}>
                                <span style={{ display: actionLoading ? 'none' : 'flex' }} className="items-center gap-2"><i data-lucide="clock" className="w-5 h-5"></i> تم إرسال الطلب</span>
                                <span style={{ display: actionLoading ? 'flex' : 'none' }} className="items-center gap-2 text-sm"><div className="spinner w-4 h-4 border-2 border-slate-400"></div> جاري الإلغاء...</span>
                            </button>
                        )}
                        {friendStatus === 'pending_received' && (
                            <button onClick={handleAcceptRequest} disabled={actionLoading} className={`flex-1 h-12 rounded-xl font-bold transition-all flex items-center justify-center gap-2 shadow-md ${actionLoading ? 'bg-emerald-400 text-emerald-100 cursor-not-allowed' : 'bg-emerald-500 text-white hover:bg-emerald-600'}`}>
                                <span style={{ display: actionLoading ? 'none' : 'flex' }} className="items-center gap-2"><i data-lucide="user-check" className="w-5 h-5"></i> قبول الطلب</span>
                                <span style={{ display: actionLoading ? 'flex' : 'none' }} className="items-center gap-2 text-sm"><div className="spinner w-4 h-4 border-2 border-emerald-100"></div> جاري القبول...</span>
                            </button>
                        )}
                        {friendStatus === 'friends' && (
                            <div className="flex gap-2 w-full">
                                <button onClick={() => handleCancelOrRemove(true)} disabled={actionLoading} className="w-12 h-12 shrink-0 rounded-xl bg-red-50 dark:bg-red-900/20 text-red-500 hover:bg-red-100 flex items-center justify-center transition-colors" title="إلغاء الصداقة">
                                    <i data-lucide="user-x" className="w-5 h-5"></i>
                                </button>
                                <button onClick={handleOpenChat} className="flex-1 h-12 rounded-xl font-bold bg-indigo-600 text-white hover:bg-indigo-700 transition-all flex items-center justify-center gap-2 shadow-md">
                                    <i data-lucide="message-circle" className="w-5 h-5"></i> مراسلة
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
            
            <div className="mt-8 border-t border-slate-200 dark:border-dark-border pt-6 animate-fade-in">
                <h3 className="font-bold text-lg text-slate-800 dark:text-white mb-4 flex items-center gap-2">
                    <i data-lucide="message-square" className="w-5 h-5 text-indigo-500"></i> نشاط {profile.name.split(' ')[0]}
                </h3>
                
                {loadingPosts ? (
                    <div className="text-center py-6"><div className="spinner w-6 h-6 border-2 border-indigo-500 mx-auto"></div></div>
                ) : userPosts.length === 0 ? (
                    <div className="text-center py-10 bg-slate-50 dark:bg-dark-bg/50 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700">
                        <i data-lucide="file-question" className="w-10 h-10 text-slate-300 mx-auto mb-2"></i>
                        <p className="text-slate-500 font-bold text-sm">لم يشارك أي منشورات عامة بعد.</p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {userPosts.map(post => (
                            <window.PostItem 
                                key={post.id} 
                                post={post} 
                                currentUser={currentUser} 
                                userData={currentData} 
                                isAdmin={isAdmin} 
                                showAlert={showAlert} 
                                isHighlighted={false}
                            />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};
