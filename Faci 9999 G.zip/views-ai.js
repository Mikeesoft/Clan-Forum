// --- views-ai.js ---
// شاشة المساعد الذكي AI (مربوطة بـ أسرع ذكاء اصطناعي في العالم Groq - Llama 3 🚀🤖)

var { useState, useEffect, useRef } = React;

// ⚠️ هام: ضع الـ API Key الذي نسخته من منصة Groq هنا بين علامات التنصيص
const GROQ_API_KEY = "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"; 

window.AiView = ({ user, showAlert }) => {
    const [messages, setMessages] = useState([
        { 
            id: 1, 
            text: "أهلاً بك يا بطل في المساعد الذكي لـ 'جامعتي' 🤖! أنا هنا للإجابة على أسئلتك، تلخيص المحاضرات، أو المساعدة في أي استفسار أكاديمي. كيف يمكنني مساعدتك اليوم؟", 
            sender: 'ai' 
        }
    ]);
    const [input, setInput] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const messagesEndRef = useRef(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => { 
        scrollToBottom(); 
    }, [messages, isTyping]);

    // 🌟 الدالة السحرية للاتصال بـ Groq API (الصاروخ) 🌟
    const fetchGroqResponse = async (userText) => {
        try {
            const systemPrompt = "أنت مساعد ذكي لطلاب الجامعات اسمك 'مساعد جامعتي'. تتحدث بأسلوب ودود، محفز، ومختصر باللغة العربية. دورك مساعدة الطلاب في الشرح الأكاديمي، التلخيص، وتنظيم الوقت. ردودك يجب أن تكون منسقة ومنظمة ومفيدة.";

            const response = await fetch(`https://api.groq.com/openai/v1/chat/completions`, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${GROQ_API_KEY}`
                },
                body: JSON.stringify({
                    model: "llama-3.3-70b-versatile", // أحدث وأذكى موديل من ميتا متاح مجاناً
                    messages: [
                        { role: "system", content: systemPrompt },
                        { role: "user", content: userText }
                    ],
                    temperature: 0.7
                })
            });

            const data = await response.json();

            if (!response.ok) {
                console.error("تفاصيل الخطأ من سيرفرات Groq:", data);
                return `⚠️ عذراً، يوجد ضغط على السيرفرات حالياً أو المفتاح غير صالح.`;
            }
            
            if (data.choices && data.choices[0].message.content) {
                return data.choices[0].message.content;
            } else {
                return "عذراً، لم أتمكن من استيعاب السؤال. هل يمكنك توضيحه أكثر؟";
            }
        } catch (error) {
            console.error("Groq API Error:", error);
            return "عذراً، حدث خطأ في الاتصال. تأكد من اتصالك بالإنترنت.";
        }
    };

    const handleSend = async (e) => {
        e.preventDefault();
        if (!input.trim() || isTyping) return;

        const currentInput = input.trim();
        const userMsg = { id: Date.now(), text: currentInput, sender: 'user' };
        
        setMessages(prev => [...prev, userMsg]);
        setInput('');
        setIsTyping(true);

        const aiResponseText = await fetchGroqResponse(currentInput);

        setIsTyping(false);
        setMessages(prev => [...prev, { 
            id: Date.now() + 1, 
            text: aiResponseText, 
            sender: 'ai' 
        }]);
    };

    useEffect(() => {
        let timeoutId = setTimeout(() => { try { window.lucide.createIcons(); } catch(e) {} }, 100);
        return () => clearTimeout(timeoutId);
    }, [messages, isTyping]);

    const formatMessage = (text) => {
        if (!text) return "";
        const formattedText = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        return <span dangerouslySetInnerHTML={{ __html: formattedText }} />;
    };

    return (
        <div className="flex flex-col h-[80vh] min-h-[500px] max-h-[850px] bg-white dark:bg-dark-card rounded-3xl shadow-sm border border-slate-200 dark:border-dark-border overflow-hidden animate-fade-in max-w-3xl mx-auto mt-2">
            
            {/* الهيدر */}
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-4 md:p-6 text-white flex items-center justify-between shrink-0 shadow-sm z-10 relative">
                <div className="absolute top-0 right-0 w-full h-full bg-white/5" style={{ backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)', backgroundSize: '15px 15px', opacity: '0.2' }}></div>
                
                <div className="flex items-center gap-4 relative z-10">
                    <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center border border-white/30 shadow-inner">
                        <i data-lucide="bot" className="w-6 h-6 text-white"></i>
                    </div>
                    <div>
                        <h2 className="text-xl font-bold flex items-center gap-2">مساعد جامعتي ✨</h2>
                        <p className="text-indigo-100 text-xs md:text-sm mt-1">ذكاء اصطناعي فائق السرعة</p>
                    </div>
                </div>

                <div className="relative z-10 bg-white/20 px-3 py-1.5 rounded-lg border border-white/20 backdrop-blur-sm hidden sm:flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    <span className="text-xs font-bold">متصل</span>
                </div>
            </div>

            {/* منطقة الرسائل */}
            <div className="flex-1 overflow-y-auto p-4 custom-scrollbar bg-slate-50/50 dark:bg-dark-bg/50 space-y-4 relative">
                {messages.map(msg => (
                    <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} animate-zoom-in`}>
                        <div className={`max-w-[85%] md:max-w-[75%] p-4 rounded-2xl shadow-sm ${msg.sender === 'user' ? 'bg-indigo-600 text-white rounded-tl-sm' : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-white border border-slate-100 dark:border-slate-700 rounded-tr-sm'}`}>
                            <p className="text-sm leading-relaxed whitespace-pre-wrap">{formatMessage(msg.text)}</p>
                        </div>
                    </div>
                ))}
                
                {isTyping && (
                    <div className="flex justify-start animate-fade-in">
                        <div className="bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 px-5 py-4 rounded-2xl rounded-tr-sm shadow-sm flex items-center gap-2">
                            <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce"></div>
                            <div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                            <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} className="h-2" />
            </div>

            {/* أزرار اقتراحات سريعة */}
            <div className="px-4 pt-3 pb-1 bg-white dark:bg-dark-card shrink-0 flex gap-2 overflow-x-auto hide-scrollbar">
                <button onClick={() => setInput("كيف أنظم وقتي للمذاكرة؟")} className="whitespace-nowrap px-3 py-1.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 text-xs font-bold rounded-full hover:bg-indigo-100 transition border border-indigo-100 dark:border-indigo-800">كيف أنظم وقتي؟ ⏰</button>
                <button onClick={() => setInput("اشرح لي ما هي الخوارزميات (Algorithms) ببساطة.")} className="whitespace-nowrap px-3 py-1.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 text-xs font-bold rounded-full hover:bg-indigo-100 transition border border-indigo-100 dark:border-indigo-800">شرح الخوارزميات 💻</button>
                <button onClick={() => setInput("لدي امتحان غداً وأشعر بالتوتر، ماذا أفعل؟")} className="whitespace-nowrap px-3 py-1.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 text-xs font-bold rounded-full hover:bg-indigo-100 transition border border-indigo-100 dark:border-indigo-800">نصائح للتوتر 🧘‍♂️</button>
            </div>

            {/* منطقة الكتابة */}
            <div className="p-4 bg-white dark:bg-dark-card border-t border-slate-100 dark:border-dark-border shrink-0 z-10 shadow-[0_-5px_15px_rgba(0,0,0,0.02)]">
                <form onSubmit={handleSend} className="flex gap-2 items-end">
                    <textarea
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(e); } }}
                        placeholder="اسألني عن أي شيء، لخص لي محاضرة..."
                        className="flex-1 bg-slate-100 dark:bg-slate-800 dark:text-white border-transparent focus:bg-white dark:focus:bg-slate-900 border focus:border-indigo-500 rounded-2xl px-4 py-3.5 min-h-[52px] max-h-32 resize-none outline-none transition-all text-sm custom-scrollbar"
                    />
                    <button 
                        type="submit" 
                        disabled={!input.trim() || isTyping} 
                        className={`w-12 h-12 shrink-0 flex items-center justify-center rounded-xl transition-all shadow-sm ${input.trim() && !isTyping ? 'bg-indigo-600 text-white hover:bg-indigo-700 hover:shadow-md hover:scale-105' : 'bg-slate-200 text-slate-400 dark:bg-slate-700 dark:text-slate-500 cursor-not-allowed'}`}
                    >
                        <i data-lucide="send" className="w-5 h-5 rtl:-scale-x-100 ml-1"></i>
                    </button>
                </form>
            </div>
        </div>
    );
};
