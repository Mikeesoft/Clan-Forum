// --- views-timer.js ---
// ساحة تحدي الوقت (الواجهة مربوطة بالمحرك الرئيسي في app.js ليعمل في الخلفية)

var { useState, useEffect } = React;

window.TimerView = ({ user, showAlert, timerState, timerControls }) => {
    const [activeSubTab, setActiveSubTab] = useState('timer');
    
    // 🌟 استخراج الحالات والدوال من الـ Props اللي جاية من app.js 🌟
    const { timeLeft, timerRunning, sessionDuration, soundEnabled } = timerState || {};
    const { toggleTimer, resetTimer, changeDuration, toggleSound } = timerControls || {};

    // --- حالات لوحة الشرف ---
    const [leaderboard, setLeaderboard] = useState([]);
    const [loadingLeaders, setLoadingLeaders] = useState(true);
    const [myTotalMinutes, setMyTotalMinutes] = useState(0);

    // إعادة رسم الأيقونات
    useEffect(() => {
        let timer = setTimeout(() => { if(window.lucide) window.lucide.createIcons(); }, 50);
        return () => clearTimeout(timer);
    }, [activeSubTab, leaderboard, timerRunning, timeLeft, soundEnabled]);

    // جلب بيانات لوحة الشرف وإجمالي دقائق المستخدم
    useEffect(() => {
        if (activeSubTab !== 'leaderboard') return;
        
        let unsub = () => {};
        try {
            const q = window.fb.query(
                window.fb.collection(window.fb.db, "users"),
                window.fb.orderBy("totalStudyMinutes", "desc"),
                window.fb.limit(20)
            );
            
            unsub = window.fb.onSnapshot(q, (snapshot) => {
                const leaders = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                setLeaderboard(leaders.filter(l => l.totalStudyMinutes > 0)); // إخفاء اللي مذكرش خالص
                setLoadingLeaders(false);
            });
        } catch(e) { setLoadingLeaders(false); }
        
        return () => unsub();
    }, [activeSubTab]);

    // جلب دقائق المستخدم الحالي (أنت)
    useEffect(() => {
        const unsub = window.fb.onSnapshot(window.fb.doc(window.fb.db, "users", user.uid), (doc) => {
            if(doc.exists()) setMyTotalMinutes(doc.data().totalStudyMinutes || 0);
        });
        return () => unsub();
    }, [user.uid]);

    // تنسيق عرض الوقت للمؤقت
    const formatTime = (seconds) => {
        if (seconds === undefined) return "25:00"; // قيمة افتراضية للتحميل
        const m = Math.floor(seconds / 60).toString().padStart(2, '0');
        const s = (seconds % 60).toString().padStart(2, '0');
        return `${m}:${s}`;
    };

    // تحويل الدقائق الكلية لساعات ودقائق للعرض في لوحة الشرف
    const formatTotalTime = (totalMins) => {
        if (!totalMins) return '0 دقيقة';
        const h = Math.floor(totalMins / 60);
        const m = totalMins % 60;
        if (h > 0) return `${h} ساعة ${m > 0 ? `و ${m} دقيقة` : ''}`;
        return `${m} دقيقة`;
    };

    return (
        <div className="space-y-6 animate-fade-in pb-20 max-w-lg mx-auto">
            <div className="text-center mb-6">
                <h2 className="text-3xl font-bold text-slate-800 dark:text-white flex items-center justify-center gap-2 mb-2">
                    تحدي الوقت <i data-lucide="timer" className="w-8 h-8 text-indigo-500"></i>
                </h2>
                <p className="text-slate-500 text-sm">ركز في دراستك، جمع الدقائق، وتصدر القائمة!</p>
            </div>

            <div className="flex bg-slate-200/50 dark:bg-dark-card p-1.5 rounded-2xl shadow-sm border border-slate-200 dark:border-dark-border mb-6">
                <button onClick={() => setActiveSubTab('timer')} className={`flex-1 py-3 text-sm font-bold rounded-xl transition flex items-center justify-center gap-2 ${activeSubTab === 'timer' ? 'bg-white dark:bg-dark-bg text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-indigo-500'}`}>
                    <i data-lucide="clock" className="w-4 h-4"></i> المؤقت
                </button>
                <button onClick={() => setActiveSubTab('leaderboard')} className={`flex-1 py-3 text-sm font-bold rounded-xl transition flex items-center justify-center gap-2 ${activeSubTab === 'leaderboard' ? 'bg-white dark:bg-dark-bg text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-indigo-500'}`}>
                    <i data-lucide="trophy" className="w-4 h-4"></i> لوحة الشرف
                </button>
            </div>

            {activeSubTab === 'timer' && (
                <div className="bg-white dark:bg-dark-card p-8 rounded-3xl shadow-lg border border-slate-200 dark:border-dark-border animate-zoom-in relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-2 bg-slate-100 dark:bg-dark-bg">
                        <div className="h-full bg-indigo-500 transition-all duration-1000" style={{ width: `${100 - (timeLeft / (sessionDuration * 60)) * 100}%` }}></div>
                    </div>
                    
                    <div className="flex justify-between items-center mb-8 pt-2">
                        {/* 🌟 زرار كتم/تشغيل الصوت 🌟 */}
                        <button onClick={toggleSound} className={`p-2 rounded-full transition-colors ${soundEnabled ? 'text-indigo-500 bg-indigo-50 dark:bg-indigo-900/30' : 'text-slate-400 bg-slate-100 dark:bg-dark-bg'}`} title={soundEnabled ? 'كتم الصوت' : 'تشغيل الصوت'}>
                            <i data-lucide={soundEnabled ? "volume-2" : "volume-x"} className="w-5 h-5"></i>
                        </button>
                        
                        <div className="flex gap-2">
                            {[15, 25, 45, 60].map(mins => (
                                <button 
                                    key={mins} 
                                    onClick={() => changeDuration(mins)}
                                    className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-colors ${sessionDuration === mins ? 'bg-indigo-100 text-indigo-700 border-2 border-indigo-500 dark:bg-indigo-900/40 dark:text-indigo-400' : 'bg-slate-50 text-slate-500 border-2 border-transparent hover:bg-slate-100 dark:bg-dark-bg dark:text-slate-400'}`}
                                >
                                    {mins} د
                                </button>
                            ))}
                        </div>
                    </div>

                    <div className="text-center mb-8">
                        <div className={`text-7xl font-mono font-bold tracking-wider transition-colors duration-300 ${timerRunning ? 'text-indigo-600 dark:text-indigo-400 animate-pulse-slow' : 'text-slate-800 dark:text-white'}`}>
                            {formatTime(timeLeft)}
                        </div>
                        <p className="text-slate-400 mt-4 font-bold text-sm">
                            {timerRunning ? 'جلسة التركيز مستمرة...' : 'مستعد للبدء؟'}
                        </p>
                    </div>

                    <div className="flex justify-center items-center gap-6">
                        <button onClick={resetTimer} className="w-14 h-14 bg-slate-100 text-slate-500 dark:bg-dark-bg dark:text-slate-400 rounded-2xl flex items-center justify-center hover:bg-slate-200 hover:text-slate-700 transition-all shadow-sm" title="إعادة ضبط الوقت">
                            <i data-lucide="rotate-ccw" className="w-6 h-6"></i>
                        </button>
                        
                        <button onClick={toggleTimer} className={`w-20 h-20 rounded-3xl flex items-center justify-center text-white shadow-lg transition-all hover:scale-105 ${timerRunning ? 'bg-amber-500 shadow-amber-500/40' : 'bg-indigo-600 shadow-indigo-600/40'}`}>
                            <i data-lucide={timerRunning ? "pause" : "play"} className="w-8 h-8 fill-current ml-1"></i>
                        </button>
                    </div>
                </div>
            )}

            {activeSubTab === 'leaderboard' && (
                <div className="animate-fade-in">
                    <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl p-6 text-white mb-6 shadow-lg flex items-center justify-between">
                        <div>
                            <p className="text-indigo-100 text-xs font-bold uppercase mb-1">إجمالي إنجازك</p>
                            <h3 className="text-2xl font-bold font-mono">{formatTotalTime(myTotalMinutes)}</h3>
                        </div>
                        <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                            <i data-lucide="award" className="w-6 h-6 text-white"></i>
                        </div>
                    </div>

                    <div className="bg-white dark:bg-dark-card rounded-2xl shadow-sm border border-slate-200 dark:border-dark-border overflow-hidden">
                        <div className="p-4 bg-slate-50 dark:bg-dark-bg border-b border-slate-200 dark:border-dark-border font-bold text-slate-600 dark:text-slate-400 text-sm flex justify-between">
                            <span>الترتيب</span>
                            <span>ساعات الدراسة</span>
                        </div>
                        
                        {loadingLeaders ? (
                            <div className="py-10 flex justify-center"><div className="spinner w-8 h-8 border-4 border-indigo-500"></div></div>
                        ) : leaderboard.length === 0 ? (
                            <div className="text-center py-10 text-slate-500 font-bold">كن أول من يسجل وقتاً في الدراسة!</div>
                        ) : (
                            <div className="divide-y divide-slate-100 dark:divide-dark-border">
                                {leaderboard.map((leader, index) => (
                                    <div key={leader.id} className={`p-4 flex items-center justify-between transition-colors hover:bg-slate-50 dark:hover:bg-dark-bg/50 ${leader.id === user.uid ? 'bg-indigo-50/50 dark:bg-indigo-900/10' : ''}`}>
                                        <div className="flex items-center gap-4">
                                            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${index === 0 ? 'bg-yellow-100 text-yellow-600 border-2 border-yellow-400' : index === 1 ? 'bg-slate-200 text-slate-600 border-2 border-slate-400' : index === 2 ? 'bg-orange-100 text-orange-700 border-2 border-orange-400' : 'text-slate-400'}`}>
                                                {index < 3 ? <i data-lucide="medal" className="w-4 h-4"></i> : `#${index + 1}`}
                                            </div>
                                            
                                            <div className="flex items-center gap-2">
                                                <div className="w-10 h-10 rounded-full overflow-hidden bg-slate-100 border border-slate-200">
                                                    {leader.photo ? <img src={leader.photo} className="w-full h-full object-cover" /> : <i data-lucide="user" className="w-5 h-5 text-slate-400 mt-2 ml-2"></i>}
                                                </div>
                                                <div>
                                                    <h4 className="font-bold text-sm text-slate-800 dark:text-white flex items-center gap-1">
                                                        {leader.name || 'طالب مجهول'}
                                                        {leader.id === user.uid && <span className="text-[9px] bg-indigo-100 text-indigo-600 px-1.5 py-0.5 rounded ml-1">أنت</span>}
                                                    </h4>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div className="text-sm font-bold font-mono text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/30 px-3 py-1 rounded-lg">
                                            {formatTotalTime(leader.totalStudyMinutes)}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};
