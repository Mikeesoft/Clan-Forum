// --- app.js ---
// المحرك الرئيسي للتطبيق (تم دعم وضع الزائر المقيد Guest Mode 🛡️ + محرك حرب الأيقونات ⚔️)

var { useState, useEffect } = React;

const App = () => {
    const [user, setUser] = useState(null); 
    const [ready, setReady] = useState(false);
    const [showAuth, setShowAuth] = useState(false);

    useEffect(() => { 
        const init = () => { 
            if(window.fb) { 
                setReady(true); 
                window.fb.onAuthStateChanged(window.fb.auth, async (u) => {
                    setUser(u);
                    // لو سجل دخول بنجاح، نقفل شاشة المصادقة أوتوماتيك
                    if (u) {
                        setShowAuth(false);
                        
                        // ⚔️ تشغيل محرك "حرب الأيقونات" في الخلفية لحساب الإنتاج التلقائي للذهب والجيش
                        if (window.WarEngine) {
                            console.log("⚔️ جاري تشغيل محرك الحرب ومزامنة الموارد...");
                            await window.WarEngine.syncPlayer(window.fb.db, u);
                        }
                    }
                }); 
            } 
        }; 
        if(window.fb) init(); 
        else window.addEventListener('firebase-ready', init); 
    }, []);

    if(!ready) return <window.Loading />; 
    
    // لو اختار إنه يسجل دخول (زرار تسجيل الدخول انضغط)
    if(showAuth) return <window.AuthScreen onClose={() => setShowAuth(false)} />;
    
    // توجيه للوحة التحكم (لو اليوزر null، لوحة التحكم هتعرض شاشة القفل الأنيقة للزائر)
    return <window.Dashboard user={user} onLoginClick={() => setShowAuth(true)} />;
};

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
