// --- views-teams.js ---
// منصة فرق العمل (Teams) - تنسيق الكروت الجديد ✏️ + الوضع الليلي للشات 🌙 + إشعارات الانضمام 🔔

var { useState, useEffect, useRef } = React;
var ADMIN_EMAIL = "mohammadsafe202a@gmail.com";

const NINETY_DAYS_MS = 90 * 24 * 60 * 60 * 1000; // 3 شهور

// ==========================================
// 1️⃣ واجهة إعدادات الفريق ⚙️
// ==========================================
const TeamSettingsView = ({ team, user, isAdmin, onBack, showAlert, onUserClick }) => {
    const [editName, setEditName] = useState(team.name);
    const [editDesc, setEditDesc] = useState(team.description || '');
    const [requiresApproval, setRequiresApproval] = useState(team.requiresApproval || false);
    const [isLocked, setIsLocked] = useState(team.isLocked || false);
    
    const [isSaving, setIsSaving] = useState(false);
    const [actionLoading, setActionLoading] = useState(null); 
    
    const [joinRequests, setJoinRequests] = useState([]);
    const [loadingReqs, setLoadingReqs] = useState(true);

    const isCreator = team.creatorUid === user.uid;
    const canEdit = isAdmin || isCreator;

    useEffect(() => {
        const fetchRequests = async () => {
            if (!team.joinRequests || team.joinRequests.length === 0) {
                setJoinRequests([]); setLoadingReqs(false); return;
            }
            try {
                const reqs = [];
                for (let uid of team.joinRequests) {
                    const doc = await window.fb.getDoc(window.fb.doc(window.fb.db, "users", uid));
                    if (doc.exists()) reqs.push({ id: uid, ...doc.data() });
                }
                setJoinRequests(reqs);
            } catch(e) {} finally { setLoadingReqs(false); }
        };
        fetchRequests();
    }, [team.joinRequests]);

    const handleSaveSettings = async () => {
        if (!editName.trim()) return;
        setIsSaving(true);
        try {
            await window.fb.updateDoc(window.fb.doc(window.fb.db, "teams", team.id), {
                name: editName.trim(), description: editDesc.trim(), requiresApproval, isLocked
            });
            showAlert("نجاح", "تم حفظ الإعدادات بنجاح", "success");
        } catch(e) { showAlert("خطأ", "فشل الحفظ", "danger"); }
        finally { setIsSaving(false); }
    };

    const handleRequest = async (requesterUid, action) => {
        setActionLoading(requesterUid);
        try {
            const teamRef = window.fb.doc(window.fb.db, "teams", team.id);
            let newMembers = [...team.members];
            let newReqs = team.joinRequests.filter(id => id !== requesterUid);
            
            if (action === 'approve') newMembers.push(requesterUid);
            
            await window.fb.updateDoc(teamRef, { members: newMembers, joinRequests: newReqs });
            showAlert("نجاح", action === 'approve' ? "تمت الموافقة على الانضمام" : "تم رفض الطلب", "success");
        } catch(e) { showAlert("خطأ", "حدث خطأ", "danger"); }
        finally { setActionLoading(null); }
    };

    return (
        <div className="flex flex-col h-[85vh] max-h-[800px] bg-slate-50 dark:bg-dark-bg rounded-3xl overflow-hidden shadow-lg border border-slate-200 dark:border-dark-border animate-fade-in relative z-50">
            <div className="flex items-center gap-3 bg-white dark:bg-dark-card p-4 shadow-sm z-10 border-b border-slate-200 dark:border-dark-border">
                <button onClick={onBack} className="w-10 h-10 rounded-full flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"><i data-lucide="arrow-right" className="w-5 h-5 rtl:-scale-x-100"></i></button>
                <h3 className="font-bold text-slate-800 dark:text-white text-lg">إعدادات الفريق</h3>
            </div>

            <div className="flex-1 overflow-y-auto p-4 custom-scrollbar space-y-6">
                <div className="bg-white dark:bg-dark-card p-5 rounded-2xl shadow-sm border border-slate-200 dark:border-dark-border space-y-4">
                    <div className="flex flex-col items-center mb-2">
                        <div className="relative w-24 h-24 rounded-full overflow-hidden border-4 border-slate-100 dark:border-slate-800 bg-slate-100 dark:bg-slate-800 flex items-center justify-center shadow-sm">
                            {team.photo ? <img src={team.photo} className="w-full h-full object-cover" /> : <i data-lucide="users" className="w-8 h-8 text-slate-400"></i>}
                        </div>
                    </div>
                    
                    {canEdit ? (
                        <>
                            <div><label className="block text-xs font-bold text-slate-500 mb-1">اسم الفريق</label><input type="text" value={editName} onChange={e => setEditName(e.target.value)} className="w-full h-12 px-4 border rounded-xl dark:bg-dark-bg dark:border-dark-border dark:text-white outline-none focus:ring-2 focus:ring-indigo-500" /></div>
                            <div><label className="block text-xs font-bold text-slate-500 mb-1">الوصف</label><textarea value={editDesc} onChange={e => setEditDesc(e.target.value)} className="w-full h-20 p-3 border rounded-xl dark:bg-dark-bg dark:border-dark-border dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 resize-none"></textarea></div>
                            
                            <div className="pt-3 space-y-3 border-t border-slate-100 dark:border-dark-border">
                                <label className="flex items-center justify-between cursor-pointer p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                                    <div><p className="font-bold text-sm text-slate-800 dark:text-white">الموافقة على الانضمام</p><p className="text-[10px] text-slate-500">يتطلب موافقتك لدخول أي عضو جديد</p></div>
                                    <input type="checkbox" checked={requiresApproval} onChange={e => setRequiresApproval(e.target.checked)} className="w-5 h-5 accent-indigo-600" />
                                </label>
                                <label className="flex items-center justify-between cursor-pointer p-3 bg-red-50 dark:bg-red-900/10 rounded-xl">
                                    <div><p className="font-bold text-sm text-red-600 dark:text-red-400">إغلاق الفريق نهائياً</p><p className="text-[10px] text-red-500/70">يمنع دخول أي شخص جديد تماماً</p></div>
                                    <input type="checkbox" checked={isLocked} onChange={e => setIsLocked(e.target.checked)} className="w-5 h-5 accent-red-600" />
                                </label>
                            </div>
                            
                            <button onClick={handleSaveSettings} disabled={isSaving} className={`w-full h-12 rounded-xl font-bold shadow-md flex items-center justify-center gap-2 transition-colors ${isSaving ? 'bg-indigo-400 text-indigo-100 cursor-wait' : 'bg-indigo-600 text-white hover:bg-indigo-700'}`}>
                                {isSaving ? <div className="spinner w-4 h-4 border-2"></div> : 
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg>
                                }
                                {isSaving ? 'جاري الحفظ...' : 'حفظ الإعدادات'}
                            </button>
                        </>
                    ) : (
                        <div className="text-center"><h2 className="font-bold text-xl dark:text-white">{team.name}</h2><p className="text-sm text-slate-500 mt-2">{team.description}</p></div>
                    )}
                </div>

                {canEdit && requiresApproval && (
                    <div className="bg-white dark:bg-dark-card p-5 rounded-2xl shadow-sm border border-slate-200 dark:border-dark-border">
                        <h4 className="font-bold text-slate-800 dark:text-white flex items-center gap-2 mb-4"><i data-lucide="user-plus" className="w-5 h-5 text-indigo-500"></i> طلبات الانضمام</h4>
                        {loadingReqs ? <div className="text-center text-slate-400 text-sm">جاري التحميل...</div> : 
                         joinRequests.length === 0 ? <div className="text-center text-slate-400 text-sm bg-slate-50 dark:bg-slate-800 p-4 rounded-xl">لا توجد طلبات معلقة.</div> : 
                         <div className="space-y-4">
                            {joinRequests.map(req => (
                                <div key={req.id} className="flex flex-col bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-700">
                                    <div className="flex items-center gap-3 cursor-pointer mb-3" onClick={() => onUserClick && onUserClick(req.id)}>
                                        <img src={req.photo || ''} className="w-12 h-12 rounded-full object-cover bg-slate-200 border border-slate-200" onError={(e)=>{e.target.src=''; e.target.className='w-12 h-12 rounded-full bg-slate-200 flex items-center justify-center'}} />
                                        <div>
                                            <p className="font-bold text-sm text-slate-800 dark:text-white hover:text-indigo-500 transition-colors">{req.name}</p>
                                            <p className="text-[10px] text-slate-500">يطلب الانضمام للفريق</p>
                                        </div>
                                    </div>
                                    <div className="flex gap-2 w-full">
                                        <button onClick={() => handleRequest(req.id, 'approve')} disabled={actionLoading === req.id} className="flex-1 h-9 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1 shadow-sm">
                                            {actionLoading === req.id ? 'لحظة...' : <>قبول الطلب</>}
                                        </button>
                                        <button onClick={() => handleRequest(req.id, 'reject')} disabled={actionLoading === req.id} className="flex-1 h-9 bg-red-50 hover:bg-red-100 text-red-600 dark:bg-red-900/20 dark:text-red-400 border border-red-100 dark:border-red-900/50 rounded-lg text-xs font-bold transition-colors">
                                            رفض
                                        </button>
                                    </div>
                                </div>
                            ))}
                         </div>
                        }
                    </div>
                )}
            </div>
        </div>
    );
};

// ==========================================
// 2️⃣ مكون شاشة الدردشة 💬 (بإصلاح الوضع الليلي 🌙)
// ==========================================
const TeamChatView = ({ team, user, userData, isAdmin, onBack, onOpenSettings, onUserClick, showAlert }) => {
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const [pendingImage, setPendingImage] = useState(null);
    const [isSending, setIsSending] = useState(false);
    const messagesEndRef = useRef(null);

    useEffect(() => {
        const q = window.fb.query(window.fb.collection(window.fb.db, `teams/${team.id}/messages`));
        const unsub = window.fb.onSnapshot(q, (snapshot) => {
            const now = Date.now();
            const fetched = [];
            snapshot.docs.forEach(doc => {
                const data = doc.data();
                if (now - data.createdAt > NINETY_DAYS_MS) {
                    if(isAdmin) window.fb.deleteDoc(doc.ref).catch(()=>{}); 
                } else {
                    fetched.push({ id: doc.id, ...data });
                }
            });
            fetched.sort((a, b) => a.createdAt - b.createdAt);
            setMessages(fetched);
            setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
        });
        return () => unsub();
    }, [team.id, isAdmin]);

    useEffect(() => {
        let timeoutId = setTimeout(() => { try { window.lucide.createIcons(); } catch (e) {} }, 50);
        return () => clearTimeout(timeoutId);
    }, [messages, pendingImage]);

    const handleImageSelect = (e) => {
        const file = e.target.files[0];
        if (!file) return;
        if (!file.type.startsWith('image/')) { showAlert("خطأ", "اختر ملف صورة فقط", "danger"); return; }

        const reader = new FileReader();
        reader.onload = (event) => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const MAX_SIZE = 800; 
                let width = img.width; let height = img.height;
                if (width > height) { if (width > MAX_SIZE) { height *= MAX_SIZE / width; width = MAX_SIZE; } } 
                else { if (height > MAX_SIZE) { width *= MAX_SIZE / height; height = MAX_SIZE; } }
                canvas.width = width; canvas.height = height;
                const ctx = canvas.getContext('2d'); ctx.drawImage(img, 0, 0, width, height);
                setPendingImage(canvas.toDataURL('image/jpeg', 0.6)); 
            };
            img.src = event.target.result;
        };
        reader.readAsDataURL(file);
    };

    const handleSendMessage = async (e) => {
        e.preventDefault();
        if ((!newMessage.trim() && !pendingImage) || isSending) return;
        
        setIsSending(true);
        try {
            await window.fb.addDoc(window.fb.collection(window.fb.db, `teams/${team.id}/messages`), {
                uid: user.uid,
                senderName: userData?.name || user?.displayName || 'طالب',
                senderPhoto: userData?.photo || user?.photoURL || '',
                senderIsAdmin: isAdmin,
                senderIsCouncil: userData?.isCouncil || false,
                senderIsVerified: userData?.isVerified || false,
                text: newMessage.trim(),
                imageUrl: pendingImage || null,
                createdAt: Date.now()
            });
            setNewMessage('');
            setPendingImage(null);
            setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
        } catch (err) { showAlert("خطأ", "فشل إرسال الرسالة", "danger"); }
        finally { setIsSending(false); }
    };

    return (
        <div className="flex flex-col h-[85vh] max-h-[800px] bg-slate-50 dark:bg-slate-900 rounded-3xl overflow-hidden shadow-lg border border-slate-200 dark:border-slate-800 animate-fade-in relative z-50">
            <div className="flex items-center gap-3 bg-white dark:bg-dark-card p-3 shadow-sm z-20 border-b border-slate-200 dark:border-slate-800">
                <button onClick={onBack} className="w-10 h-10 rounded-full flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"><i data-lucide="arrow-right" className="w-5 h-5 rtl:-scale-x-100"></i></button>
                <div onClick={onOpenSettings} className="flex-1 min-w-0 flex items-center gap-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 p-1.5 rounded-xl transition-colors">
                    <div className="w-10 h-10 rounded-full overflow-hidden shrink-0 border border-slate-200 dark:border-slate-700 bg-slate-100">
                        {team.photo ? <img src={team.photo} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-indigo-500"><i data-lucide="users" className="w-5 h-5"></i></div>}
                    </div>
                    <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-slate-800 dark:text-white truncate">{team.name}</h3>
                        <p className="text-[10px] text-slate-500 truncate">انقر لعرض الإعدادات والتفاصيل</p>
                    </div>
                </div>
            </div>

            {/* 🌟 حل مشكلة الوضع الليلي: تم استخدام Overlay شفاف بدل الـ blend-mode 🌟 */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar relative bg-slate-50 dark:bg-[#0f172a]">
                <div className="absolute inset-0 z-0 opacity-[0.04] dark:opacity-[0.06] pointer-events-none" style={{ backgroundImage: "url('https://www.transparenttextures.com/patterns/cubes.png')" }}></div>
                
                <div className="relative z-10 flex flex-col space-y-4">
                    {messages.length === 0 ? (
                        <div className="text-center text-slate-400 text-sm mt-10 font-bold bg-white/80 dark:bg-slate-800/80 p-4 rounded-xl w-max mx-auto backdrop-blur-sm shadow-sm border border-slate-100 dark:border-slate-700">بداية الدردشة لـ {team.name} 👋</div>
                    ) : (
                        messages.map((msg, idx) => {
                            const isMe = msg.uid === user.uid;
                            const showAvatar = !isMe && (idx === 0 || messages[idx - 1].uid !== msg.uid);
                            
                            return (
                                <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'} gap-2 animate-fade-in`}>
                                    {!isMe && (
                                        <div onClick={() => onUserClick && onUserClick(msg.uid)} className={`w-8 h-8 rounded-full overflow-hidden shrink-0 mt-auto shadow-sm border border-slate-200 dark:border-slate-700 bg-slate-200 flex items-center justify-center ${showAvatar ? 'cursor-pointer hover:ring-2 ring-indigo-300' : ''}`}>
                                            {showAvatar ? (msg.senderPhoto ? <img src={msg.senderPhoto} className="w-full h-full object-cover"/> : <i data-lucide="user" className="w-4 h-4 text-slate-500"></i>) : null}
                                        </div>
                                    )}
                                    <div className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} max-w-[75%]`}>
                                        {showAvatar && !isMe && (
                                            <div onClick={() => onUserClick && onUserClick(msg.uid)} className="flex items-center gap-1 mb-1 ltr:ml-1 rtl:mr-1 cursor-pointer hover:underline">
                                                <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400">{msg.senderName}</span>
                                                {msg.senderIsVerified && <i data-lucide="badge-check" className="w-3 h-3 text-blue-500"></i>}
                                                {msg.senderIsCouncil && <i data-lucide="crown" className="w-3 h-3 text-amber-500"></i>}
                                            </div>
                                        )}
                                        <div className={`relative p-3 shadow-sm flex flex-col gap-1 ${isMe ? 'bg-indigo-600 text-white rounded-2xl rounded-br-sm' : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-white border border-slate-100 dark:border-slate-700 rounded-2xl rounded-bl-sm'}`}>
                                            {msg.imageUrl && (
                                                <a href={msg.imageUrl} target="_blank" rel="noreferrer" className="block w-full max-w-[200px] mb-1">
                                                    <img src={msg.imageUrl} className="w-full h-auto rounded-xl border border-black/10 shadow-sm" />
                                                </a>
                                            )}
                                            {msg.text && <p className="text-[14px] whitespace-pre-wrap leading-relaxed">{msg.text}</p>}
                                            <span className={`text-[9px] mt-1 self-end opacity-70 ${isMe ? 'text-indigo-100' : 'text-slate-400'}`}>
                                                {new Date(msg.createdAt).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            );
                        })
                    )}
                    <div ref={messagesEndRef} />
                </div>
            </div>

            <div className="bg-white dark:bg-dark-card p-3 border-t border-slate-200 dark:border-slate-800 z-20 shadow-[0_-5px_15px_rgba(0,0,0,0.02)]">
                {pendingImage && (
                    <div className="relative mb-3 w-max bg-slate-100 dark:bg-slate-800 p-2 rounded-xl border border-slate-200 dark:border-slate-700">
                        <img src={pendingImage} className="h-20 rounded-lg shadow-sm" />
                        <button onClick={() => setPendingImage(null)} className="absolute -top-2 -right-2 bg-red-500 text-white w-6 h-6 rounded-full flex items-center justify-center shadow-md hover:bg-red-600 transition-colors"><i data-lucide="x" className="w-3 h-3"></i></button>
                    </div>
                )}
                <form onSubmit={handleSendMessage} className="flex items-end gap-2">
                    <label className="w-11 h-11 rounded-full flex items-center justify-center text-slate-400 hover:text-indigo-500 hover:bg-indigo-50 dark:hover:bg-slate-800 cursor-pointer transition-colors shrink-0">
                        <i data-lucide="image" className="w-5 h-5"></i>
                        <input type="file" accept="image/*" className="hidden" onChange={handleImageSelect} disabled={isSending} />
                    </label>
                    <textarea 
                        value={newMessage} onChange={e => setNewMessage(e.target.value)} placeholder="اكتب رسالة..." disabled={isSending}
                        onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(e); } }}
                        className="flex-1 bg-slate-100 dark:bg-slate-800 border-transparent rounded-2xl p-3 max-h-32 min-h-[44px] resize-none outline-none focus:ring-2 focus:ring-indigo-100 dark:focus:ring-indigo-900 text-sm text-slate-800 dark:text-white custom-scrollbar" 
                    />
                    <button type="submit" disabled={isSending || (!newMessage.trim() && !pendingImage)} className={`w-11 h-11 rounded-full flex items-center justify-center shrink-0 transition-colors ${newMessage.trim() || pendingImage ? 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-md' : 'bg-slate-200 dark:bg-slate-700 text-slate-400 cursor-not-allowed'}`}>
                        {isSending ? <div className="spinner w-4 h-4 border-2"></div> : 
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="rtl:-scale-x-100 ltr:ml-1"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                        }
                    </button>
                </form>
            </div>
        </div>
    );
};

// ==========================================
// 3️⃣ واجهة التيمات الأساسية (الرئيسية) 🌐
// ==========================================
window.TeamsView = ({ user, showAlert, onBack, onUserClick }) => {
    const [teams, setTeams] = useState([]);
    const [userData, setUserData] = useState(null);
    const [isCreating, setIsCreating] = useState(false);
    const [newTeam, setNewTeam] = useState({ name: '', description: '', photo: '' });
    
    const [isProcessingImage, setIsProcessingImage] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const [currentView, setCurrentView] = useState('list'); 
    const [activeTeamId, setActiveTeamId] = useState(null);
    const [filterMode, setFilterMode] = useState('all'); 
    
    const [actionLoadingId, setActionLoadingId] = useState(null); 
    const [pinnedTeams, setPinnedTeams] = useState(() => JSON.parse(localStorage.getItem('pinnedTeams') || '[]'));

    const isAdmin = user?.email === ADMIN_EMAIL;
    const isCouncil = userData?.isCouncil || false;

    useEffect(() => {
        const unsub = window.fb.onSnapshot(window.fb.doc(window.fb.db, "users", user.uid), (doc) => {
            if (doc.exists()) setUserData(doc.data());
        });
        return () => unsub();
    }, [user.uid]);

    useEffect(() => {
        const q = window.fb.query(window.fb.collection(window.fb.db, "teams"));
        const unsub = window.fb.onSnapshot(q, (snapshot) => {
            const fetched = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            setTeams(fetched);
        });
        return () => unsub();
    }, []);

    useEffect(() => {
        let timeoutId = setTimeout(() => { try { window.lucide.createIcons(); } catch (e) {} }, 50);
        return () => clearTimeout(timeoutId);
    }, [teams, isCreating, isProcessingImage, isSubmitting, currentView, filterMode]);

    const handlePinToggle = async (team) => {
        if (isAdmin) {
            try {
                await window.fb.updateDoc(window.fb.doc(window.fb.db, "teams", team.id), { isGlobalPinned: !team.isGlobalPinned });
                showAlert("نجاح", team.isGlobalPinned ? "تم إلغاء التثبيت العام" : "تم التثبيت لجميع الطلاب", "success");
            } catch(e) {}
        } else {
            setPinnedTeams(prev => {
                const newPins = prev.includes(team.id) ? prev.filter(id => id !== team.id) : [...prev, team.id];
                localStorage.setItem('pinnedTeams', JSON.stringify(newPins));
                return newPins;
            });
        }
    };

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (!file) return;
        if (!file.type.startsWith('image/')) { showAlert("خطأ", "يرجى اختيار ملف صورة صحيح.", "danger"); return; }
        setIsProcessingImage(true);
        setTimeout(() => {
            try {
                const imgUrl = URL.createObjectURL(file);
                const img = new Image();
                img.onload = () => {
                    const canvas = document.createElement('canvas');
                    const MAX_SIZE = 250; 
                    let width = img.width; let height = img.height;
                    if (width > height) { if (width > MAX_SIZE) { height *= MAX_SIZE / width; width = MAX_SIZE; } } 
                    else { if (height > MAX_SIZE) { width *= MAX_SIZE / height; height = MAX_SIZE; } }
                    canvas.width = width; canvas.height = height;
                    const ctx = canvas.getContext('2d'); ctx.drawImage(img, 0, 0, width, height);
                    setNewTeam(prev => ({ ...prev, photo: canvas.toDataURL('image/jpeg', 0.6) }));
                    URL.revokeObjectURL(imgUrl); setIsProcessingImage(false); 
                };
                img.src = imgUrl;
            } catch (err) { setIsProcessingImage(false); }
        }, 500); 
    };

    const handleCreateTeam = async (e) => {
        e.preventDefault();
        if (!newTeam.name.trim() || isProcessingImage) return;
        setIsSubmitting(true);
        try {
            await window.fb.addDoc(window.fb.collection(window.fb.db, "teams"), {
                name: newTeam.name.trim(),
                description: newTeam.description.trim(),
                photo: newTeam.photo,
                creatorUid: user.uid,
                creatorName: userData?.name || 'الإدارة',
                creatorIsVerified: userData?.isVerified || isAdmin,
                creatorIsCouncil: userData?.isCouncil || isAdmin,
                isGlobalPinned: isAdmin, 
                isLocked: false,
                requiresApproval: false,
                members: [user.uid],
                joinRequests: [],
                createdAt: Date.now()
            });
            setIsCreating(false); setNewTeam({ name: '', description: '', photo: '' });
            showAlert("نجاح", "تم إنشاء الفريق بنجاح.", "success");
        } catch (error) { showAlert("خطأ", "فشل الإنشاء.", "danger"); } 
        finally { setIsSubmitting(false); }
    };

    const handleJoinAction = async (team) => {
        if (team.isLocked && !isAdmin && team.creatorUid !== user.uid) {
            showAlert("مغلق", "هذا الفريق مغلق حالياً ولا يقبل أعضاء جدد.", "info"); return;
        }

        setActionLoadingId(team.id);
        
        try {
            const isMember = team.members.includes(user.uid);
            const hasRequested = team.joinRequests?.includes(user.uid);
            const teamRef = window.fb.doc(window.fb.db, "teams", team.id);

            if (isMember) {
                if (team.creatorUid === user.uid && !isAdmin) {
                    showAlert("تنبيه", "أنت مؤسس هذا الفريق، لا يمكنك المغادرة.", "info"); setActionLoadingId(null); return;
                }
                await window.fb.updateDoc(teamRef, { members: team.members.filter(id => id !== user.uid) });
            } else if (team.requiresApproval) {
                if (hasRequested) {
                    await window.fb.updateDoc(teamRef, { joinRequests: team.joinRequests.filter(id => id !== user.uid) });
                    showAlert("تنبيه", "تم إلغاء طلب الانضمام", "info");
                } else {
                    await window.fb.updateDoc(teamRef, { joinRequests: [...(team.joinRequests || []), user.uid] });
                    
                    // 🌟 إرسال إشعار لصاحب التيم 🌟
                    if (team.creatorUid !== user.uid) {
                        await window.fb.addDoc(window.fb.collection(window.fb.db, "interactions"), {
                            recipientUid: team.creatorUid,
                            senderUid: user.uid,
                            senderName: userData?.name || 'طالب',
                            senderPhoto: userData?.photo || '',
                            type: 'team_join_request',
                            teamId: team.id,
                            teamName: team.name,
                            createdAt: Date.now(),
                            seen: false
                        });
                    }
                    showAlert("نجاح", "تم إرسال طلب الانضمام للمشرفين", "success");
                }
            } else {
                await window.fb.updateDoc(teamRef, { members: [...team.members, user.uid] });
                showAlert("نجاح", `أنت الآن عضو في ${team.name}`, "success");
            }
        } catch(e) {} finally { setActionLoadingId(null); }
    };

    const handleDeleteTeam = (teamId, teamName) => {
        showAlert("حذف الفريق", `هل أنت متأكد من حذف فريق "${teamName}" نهائياً؟`, "danger", async () => {
            try {
                await window.fb.deleteDoc(window.fb.doc(window.fb.db, "teams", teamId));
                showAlert("تم الحذف", "تم حذف الفريق بنجاح.", "success");
            } catch (error) {}
        });
    };

    if (currentView === 'chat' && activeTeamId) {
        const activeTeam = teams.find(t => t.id === activeTeamId);
        if (!activeTeam) { setCurrentView('list'); return null; }
        return <TeamChatView team={activeTeam} user={user} userData={userData} isAdmin={isAdmin} showAlert={showAlert} onUserClick={onUserClick} onBack={() => setCurrentView('list')} onOpenSettings={() => setCurrentView('settings')} />;
    }

    if (currentView === 'settings' && activeTeamId) {
        const activeTeam = teams.find(t => t.id === activeTeamId);
        if (!activeTeam) { setCurrentView('list'); return null; }
        return <TeamSettingsView team={activeTeam} user={user} isAdmin={isAdmin} showAlert={showAlert} onUserClick={onUserClick} onBack={() => setCurrentView('chat')} />;
    }

    let displayedTeams = filterMode === 'my_teams' ? teams.filter(t => t.members.includes(user.uid)) : [...teams];
    displayedTeams.sort((a, b) => {
        if (a.isGlobalPinned && !b.isGlobalPinned) return -1;
        if (!a.isGlobalPinned && b.isGlobalPinned) return 1;
        const aPinned = pinnedTeams.includes(a.id);
        const bPinned = pinnedTeams.includes(b.id);
        if (aPinned && !bPinned) return -1;
        if (!aPinned && bPinned) return 1;
        return b.createdAt - a.createdAt;
    });

    return (
        <div className="space-y-4 animate-fade-in max-w-2xl mx-auto mt-2">
            <div className="flex flex-col gap-3 bg-white dark:bg-dark-card p-4 rounded-2xl shadow-sm border border-slate-200 dark:border-dark-border">
                <div className="flex justify-between items-center w-full">
                    <div className="flex items-center gap-3">
                        <button onClick={onBack} className="w-10 h-10 bg-slate-50 dark:bg-dark-bg text-slate-500 hover:text-indigo-600 rounded-full flex items-center justify-center transition-colors">
                            <i data-lucide="arrow-right" className="w-5 h-5 rtl:-scale-x-100"></i>
                        </button>
                        <div>
                            <h2 className="font-bold text-slate-800 dark:text-white text-lg flex items-center gap-2">فرق العمل</h2>
                            <p className="text-[10px] text-slate-500">مجموعات دراسية وتيمات</p>
                        </div>
                    </div>
                    <button onClick={() => setIsCreating(true)} className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold rounded-xl shadow-sm flex items-center gap-2 transition-all">
                        <i data-lucide="plus" className="w-4 h-4"></i> إنشاء
                    </button>
                </div>
                
                <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-xl w-full">
                    <button onClick={() => setFilterMode('all')} className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1 ${filterMode === 'all' ? 'bg-white dark:bg-slate-700 shadow-sm text-indigo-600 dark:text-indigo-400' : 'text-slate-500 hover:text-slate-700'}`}><i data-lucide="globe" className="w-3.5 h-3.5"></i> الكل</button>
                    <button onClick={() => setFilterMode('my_teams')} className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1 ${filterMode === 'my_teams' ? 'bg-white dark:bg-slate-700 shadow-sm text-indigo-600 dark:text-indigo-400' : 'text-slate-500 hover:text-slate-700'}`}><i data-lucide="users-round" className="w-3.5 h-3.5"></i> تيماتي</button>
                </div>
            </div>

            {isCreating && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center px-4 animate-fade-in">
                    <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => !isSubmitting && !isProcessingImage && setIsCreating(false)}></div>
                    <div className="bg-white dark:bg-dark-card w-full max-w-md rounded-3xl shadow-2xl relative z-10 overflow-hidden animate-zoom-in border border-slate-200 dark:border-dark-border p-6">
                        <div className="flex justify-between items-center mb-6">
                            <h3 className="text-xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-indigo-500"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                                إنشاء فريق جديد
                            </h3>
                            <button onClick={() => !isSubmitting && !isProcessingImage && setIsCreating(false)} className="text-slate-400 hover:text-red-500">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                            </button>
                        </div>
                        <form onSubmit={handleCreateTeam} className="space-y-4">
                            <div className="flex flex-col items-center mb-6 mt-2">
                                <div className="relative group cursor-pointer w-24 h-24 rounded-2xl border-2 border-dashed border-indigo-300 dark:border-indigo-700 bg-indigo-50 dark:bg-indigo-900/20 flex flex-col items-center justify-center overflow-hidden transition-all hover:border-indigo-500 shadow-sm">
                                    {newTeam.photo && !isProcessingImage ? (
                                        <img src={newTeam.photo} className="w-full h-full object-cover" />
                                    ) : (
                                        <div className="flex flex-col items-center text-indigo-400">
                                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle></svg>
                                        </div>
                                    )}
                                    <input type="file" accept="image/*" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" disabled={isSubmitting || isProcessingImage}/>
                                </div>
                                {isProcessingImage ? (
                                    <div className="mt-3 flex flex-col items-center animate-fade-in"><div className="spinner w-5 h-5 border-2 border-indigo-500 mb-1"></div><span className="text-[11px] font-bold text-indigo-600 mt-1">جاري المعاينة...</span></div>
                                ) : (
                                    <span className="text-[11px] font-bold text-slate-500 mt-3 bg-slate-50 px-3 py-1 rounded-full border border-slate-200">صورة الفريق</span>
                                )}
                            </div>

                            <div><label className="block text-xs font-bold text-slate-600 mb-1.5">اسم الفريق / المجموعة</label><input type="text" value={newTeam.name} onChange={e => setNewTeam({...newTeam, name: e.target.value})} required className="w-full h-12 px-4 border rounded-xl dark:bg-dark-bg dark:border-dark-border dark:text-white outline-none focus:ring-2 focus:ring-indigo-500" disabled={isSubmitting}/></div>
                            <div><label className="block text-xs font-bold text-slate-600 mb-1.5">الوصف (اختياري)</label><textarea value={newTeam.description} onChange={e => setNewTeam({...newTeam, description: e.target.value})} className="w-full h-20 p-4 border rounded-xl dark:bg-dark-bg dark:border-dark-border dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 resize-none" disabled={isSubmitting}></textarea></div>
                            
                            <button type="submit" disabled={isSubmitting || isProcessingImage || !newTeam.name.trim()} className={`w-full h-12 rounded-xl font-bold flex items-center justify-center gap-2 shadow-md transition-colors ${isSubmitting || isProcessingImage || !newTeam.name.trim() ? 'bg-indigo-400 text-indigo-100' : 'bg-indigo-600 text-white hover:bg-indigo-700'}`}>
                                {isSubmitting ? 'جاري الإنشاء...' : 'تأكيد الإنشاء'}
                            </button>
                        </form>
                    </div>
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {displayedTeams.length === 0 ? (
                    <div className="col-span-full text-center py-16 bg-white dark:bg-dark-card rounded-2xl border border-dashed border-slate-200 dark:border-dark-border">
                        <div className="w-16 h-16 bg-slate-50 dark:bg-dark-bg rounded-full flex items-center justify-center mx-auto mb-3">
                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-400"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                        </div>
                        <p className="text-slate-500 font-bold text-sm">لا توجد فرق عمل حالياً.</p>
                    </div>
                ) : (
                    displayedTeams.map(team => {
                        const isMember = team.members.includes(user.uid);
                        const isCreator = team.creatorUid === user.uid;
                        const isPinned = isAdmin ? team.isGlobalPinned : pinnedTeams.includes(team.id);
                        const hasRequested = team.joinRequests?.includes(user.uid);
                        const canDelete = isAdmin || isCreator || isCouncil;
                        const canEdit = isAdmin || isCreator;
                        
                        let joinBtnText = 'انضمام';
                        if (hasRequested) joinBtnText = 'قيد المراجعة';
                        else if (team.isLocked && !isAdmin) joinBtnText = 'مغلق';
                        else if (team.requiresApproval) joinBtnText = 'طلب انضمام';

                        return (
                            <div key={team.id} className={`bg-white dark:bg-dark-card p-4 rounded-2xl border shadow-sm flex flex-col gap-3 transition-all relative group ${team.isGlobalPinned ? 'border-indigo-300 dark:border-indigo-700 bg-indigo-50/20 dark:bg-indigo-900/10' : isPinned ? 'border-amber-300 dark:border-amber-700 bg-amber-50/30 dark:bg-amber-900/10' : 'border-slate-200 dark:border-dark-border hover:shadow-md'}`}>
                                
                                {/* 🌟 زراير الكارت الجديدة المترتبة زي المنتدى 🌟 */}
                                <div className="flex justify-between items-start mb-1">
                                    <div className="flex gap-3 items-start pr-2 flex-1 min-w-0">
                                        <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-slate-800 text-indigo-500 flex items-center justify-center shrink-0 overflow-hidden border border-slate-200 shadow-sm">
                                            {team.photo ? <img src={team.photo} className="w-full h-full object-cover" /> : <i data-lucide="users" className="w-5 h-5"></i>}
                                        </div>
                                        <div className="flex-1 min-w-0 pt-1">
                                            <h3 className="font-bold text-slate-800 dark:text-white text-sm truncate flex items-center gap-1">
                                                {team.name}
                                                {team.creatorIsVerified && <i data-lucide="badge-check" className="w-3.5 h-3.5 text-blue-500" title="منشئ موثق"></i>}
                                                {team.creatorIsCouncil && <i data-lucide="crown" className="w-3.5 h-3.5 text-orange-500" title="مجلس الطلاب"></i>}
                                            </h3>
                                            {team.description && <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">{team.description}</p>}
                                        </div>
                                    </div>
                                    
                                    {/* زراير التحكم */}
                                    <div className="flex items-center gap-1 shrink-0 z-10 pl-1">
                                        <button onClick={(e) => { e.stopPropagation(); handlePinToggle(team); }} className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors shadow-sm border ${isPinned ? (team.isGlobalPinned ? 'bg-indigo-100 text-indigo-600 border-indigo-200' : 'bg-amber-100 text-amber-600 border-amber-200') : 'bg-white dark:bg-slate-800 text-slate-300 border-slate-100 dark:border-slate-700 hover:text-amber-500'}`} title="تثبيت">
                                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21.1 16.3 15 10.2l-3-3-2.1-2.1c-.8-.8-2-.8-2.8 0l-2.8 2.8c-.8.8-.8 2 0 2.8l2.1 2.1 3 3 6.1 6.1c.8.8 2 .8 2.8 0l2.8-2.8c.8-.8.8-2 0-2.8z"></path><path d="m14 10-4-4"></path><path d="m3 21 6.8-6.8"></path></svg>
                                        </button>
                                        
                                        {canEdit && (
                                            <button onClick={(e) => { e.stopPropagation(); setActiveTeamId(team.id); setCurrentView('settings'); }} className="w-8 h-8 bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 text-slate-300 dark:text-slate-500 hover:bg-indigo-50 hover:text-indigo-500 hover:border-indigo-200 rounded-full flex items-center justify-center transition-colors shadow-sm" title="إعدادات الفريق">
                                                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg>
                                            </button>
                                        )}
                                        
                                        {canDelete && (
                                            <button onClick={(e) => { e.stopPropagation(); handleDeleteTeam(team.id, team.name); }} className="w-8 h-8 bg-white dark:bg-slate-800 border border-red-100 dark:border-red-900/50 text-slate-300 dark:text-slate-500 hover:bg-red-500 hover:text-white rounded-full flex items-center justify-center transition-colors shadow-sm" title="حذف الفريق">
                                                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                                            </button>
                                        )}
                                    </div>
                                </div>

                                <div className="flex items-center justify-between pt-3 border-t border-slate-50 dark:border-slate-800 mt-auto relative z-20">
                                    <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-500 bg-slate-50 dark:bg-slate-800 px-2 py-1 rounded-lg">
                                        <i data-lucide="users" className="w-3 h-3"></i> {team.members.length} أعضاء
                                        {team.isLocked && <i data-lucide="lock" className="w-3 h-3 text-red-500 ml-1"></i>}
                                    </div>
                                    {isMember ? (
                                        <div className="flex gap-2">
                                            {(!isCreator || isAdmin) && <button onClick={() => handleJoinAction(team)} disabled={actionLoadingId === team.id} className="px-3 py-1.5 bg-slate-100 text-slate-500 dark:bg-slate-800 rounded-lg text-[11px] font-bold transition-colors">
                                                {actionLoadingId === team.id ? 'لحظة...' : 'مغادرة'}
                                            </button>}
                                            <button onClick={() => { setActiveTeamId(team.id); setCurrentView('chat'); }} className="px-4 py-1.5 bg-indigo-600 text-white rounded-lg text-[11px] font-bold shadow-sm hover:bg-indigo-700 flex items-center gap-1 transition-colors"><i data-lucide="message-square" className="w-3.5 h-3.5"></i> دخول</button>
                                        </div>
                                    ) : (
                                        <button onClick={() => handleJoinAction(team)} disabled={(team.isLocked && !isAdmin) || actionLoadingId === team.id} className={`px-4 py-1.5 rounded-lg text-[11px] font-bold transition-all flex items-center justify-center gap-1 ${hasRequested ? 'bg-amber-100 text-amber-600' : team.isLocked && !isAdmin ? 'bg-slate-100 text-slate-400 cursor-not-allowed' : 'bg-indigo-50 text-indigo-600 dark:bg-slate-800 hover:bg-indigo-600 hover:text-white'}`}>
                                            {actionLoadingId === team.id ? (
                                                <><div className="spinner w-3 h-3 border-2 border-current"></div> {team.requiresApproval ? 'جاري الطلب...' : 'جاري الانضمام...'}</>
                                            ) : hasRequested ? (
                                                'قيد المراجعة'
                                            ) : team.isLocked && !isAdmin ? (
                                                'مغلق'
                                            ) : (
                                                <>
                                                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg> 
                                                    {joinBtnText}
                                                </>
                                            )}
                                        </button>
                                    )}
                                </div>
                            </div>
                        )
                    })
                )}
            </div>
        </div>
    );
};
