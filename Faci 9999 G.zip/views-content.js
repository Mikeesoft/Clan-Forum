// --- views-content.js ---
// الواجهة الأساسية للمحتوى العلمي (إلغاء التجريبي + تسعير ديناميكي من الإدارة + تصميم VIP مميز 💎)

var { useState, useEffect } = React;
var ADMIN_EMAIL = "mohammadsafe202a@gmail.com";

window.ContentView = ({ user, showAlert }) => {
    const AdminPanel = window.ContentAdminPanel;

    const [materials, setMaterials] = useState([]);
    const [userData, setUserData] = useState(null);
    const [privateData, setPrivateData] = useState(null); // 🌟 الخزنة السرية
    const [vipPrice, setVipPrice] = useState(250); // 🌟 السعر الديناميكي
    
    const [showSubModal, setShowSubModal] = useState(false);
    const [checkingSub, setCheckingSub] = useState(true);
    const [showAdminPanel, setShowAdminPanel] = useState(false);

    const [searchQuery, setSearchQuery] = useState('');
    const [activeFilter, setActiveFilter] = useState('all'); 
    const [viewMode, setViewMode] = useState('browse'); 

    // --- حالات واجهة حل الاختبار للطالب ---
    const [activeQuiz, setActiveQuiz] = useState(null);
    const [currentQIndex, setCurrentQIndex] = useState(0);
    const [selectedAns, setSelectedAns] = useState(null);
    const [isAnsChecked, setIsAnsChecked] = useState(false);
    const [quizScore, setQuizScore] = useState(0);
    const [isCalculatingResult, setIsCalculatingResult] = useState(false);
    const [showQuizResult, setShowQuizResult] = useState(false);

    const isAdmin = user.email === ADMIN_EMAIL;
    const canManageContent = isAdmin || (userData?.isCouncil && userData?.councilPermissions?.manageContent);

    useEffect(() => {
        if (!canManageContent && showAdminPanel) {
            setShowAdminPanel(false);
        }
    }, [canManageContent, showAdminPanel]);

    const getSafeTimeLocal = (val) => {
        try {
            if (!val) return 0;
            if (typeof val === 'number') return val;
            if (val.toMillis) return val.toMillis();
            if (val.seconds) return val.seconds * 1000;
            return Date.parse(val) || 0;
        } catch(e) { return 0; }
    };

    useEffect(() => {
        let unsubUser = () => {};
        let unsubPriv = () => {};
        let unsubMat = () => {};
        let unsubSettings = () => {};

        try {
            // جلب البيانات العامة
            const userRef = window.fb.doc(window.fb.db, "users", user.uid);
            unsubUser = window.fb.onSnapshot(userRef, (docSnap) => {
                if (docSnap.exists()) setUserData(docSnap.data());
            });

            // 🌟 جلب البيانات السرية (الرصيد والاشتراك) 🌟
            const privRef = window.fb.doc(window.fb.db, "users_private", user.uid);
            unsubPriv = window.fb.onSnapshot(privRef, (docSnap) => {
                if (docSnap.exists()) setPrivateData(docSnap.data());
                setCheckingSub(false);
            });

            // 🌟 جلب سعر الاشتراك من لوحة الإدارة 🌟
            const settingsRef = window.fb.doc(window.fb.db, "settings", "general");
            unsubSettings = window.fb.onSnapshot(settingsRef, (docSnap) => {
                if (docSnap.exists() && docSnap.data().vipPrice !== undefined) {
                    setVipPrice(docSnap.data().vipPrice);
                }
            });

            // جلب المحتوى
            const q = window.fb.query(window.fb.collection(window.fb.db, "materials"));
            unsubMat = window.fb.onSnapshot(q, (snapshot) => {
                try {
                    const fetched = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                    fetched.sort((a,b) => getSafeTimeLocal(b.createdAt) - getSafeTimeLocal(a.createdAt));
                    setMaterials(fetched);
                } catch(err) {
                    setMaterials(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
                }
            });
        } catch (e) { setCheckingSub(false); }

        return () => { unsubUser(); unsubPriv(); unsubMat(); unsubSettings(); };
    }, [user.uid]);

    useEffect(() => { 
        let timeoutId;
        if (window.lucide) {
            timeoutId = setTimeout(() => {
                try { window.lucide.createIcons(); } catch(e) {}
            }, 50);
        }
        return () => clearTimeout(timeoutId);
    }, [searchQuery, activeFilter, viewMode, materials, userData, privateData, showAdminPanel, showSubModal, activeQuiz, currentQIndex, showQuizResult, isCalculatingResult, canManageContent, vipPrice]);

    // 🌟 التحقق من الاشتراك من الخزنة السرية 🌟
    const hasValidSubscription = () => {
        try {
            if (isAdmin || canManageContent) return true; 
            if (!privateData || !privateData.subExpiry) return false;
            return new Date(privateData.subExpiry).getTime() > new Date().getTime();
        } catch(e) { return false; }
    };

    // 🌟 الاشتراك المباشر من الخزنة السرية (بدون تجريبي) 🌟
    const handleSubscribe = async () => {
        if (!privateData) return;
        const balance = privateData.balance || 0;
        
        if (balance < vipPrice) { 
            setShowSubModal(false);
            setTimeout(() => showAlert("رصيد غير كافٍ", `رصيدك الحالي (${balance} ج.م) لا يكفي للاشتراك. تحتاج إلى (${vipPrice} ج.م)، يرجى الشحن من الإدارة.`, "danger", ()=>{}), 150);
            return; 
        }

        try {
            const expiry = new Date(); 
            expiry.setDate(expiry.getDate() + 30); // شهر كامل
            
            // خصم الرصيد وتفعيل الاشتراك في الخزنة السرية
            const privRef = window.fb.doc(window.fb.db, "users_private", user.uid);
            await window.fb.setDoc(privRef, { 
                subExpiry: expiry.toISOString(), 
                balance: balance - vipPrice 
            }, { merge: true });
            
            setShowSubModal(false);
            setTimeout(() => showAlert("تم التفعيل", `تم خصم ${vipPrice} ج.م وتفعيل اشتراك VIP لمدة شهر بنجاح.`, "success", ()=>{}), 150);
        } catch(e) {}
    };

    const handleDelete = (id) => { showAlert("حذف المحتوى", "متأكد من حذف هذا المحتوى؟", "danger", async () => { await window.fb.deleteDoc(window.fb.doc(window.fb.db, "materials", id)); }); };
    
    const trackView = async (mat) => {
        if (isAdmin || canManageContent) return;
        try {
            const viewedByArray = mat.viewedBy || [];
            if (!viewedByArray.includes(user.uid)) {
                const matRef = window.fb.doc(window.fb.db, "materials", mat.id);
                await window.fb.updateDoc(matRef, { 
                    views: (mat.views || 0) + 1,
                    viewedBy: [...viewedByArray, user.uid] 
                });
            }
        } catch (e) {}
    };

    const handleOpenLink = async (mat) => {
        const isSubscribed = hasValidSubscription();
        if (!mat.isFree && !isSubscribed && !isAdmin && !canManageContent) {
            setShowSubModal(true);
            return;
        }

        if (mat.type === 'quiz') {
            trackView(mat);
            setActiveQuiz(mat);
            setCurrentQIndex(0);
            setSelectedAns(null);
            setIsAnsChecked(false);
            setQuizScore(0);
            setShowQuizResult(false);
            setIsCalculatingResult(false);
            window.scrollTo(0, 0);
        } else {
            window.open(mat.url, '_blank');
            trackView(mat);
        }
    };

    const handleCheckAnswer = () => {
        if (selectedAns === null) return;
        setIsAnsChecked(true);
        const currentQ = activeQuiz.questions[currentQIndex];
        if (selectedAns === currentQ.correctOptionIndex) {
            setQuizScore(prev => prev + 1);
        }
    };

    const handleNextQuestion = async () => {
        if (currentQIndex < activeQuiz.questions.length - 1) {
            setCurrentQIndex(prev => prev + 1);
            setSelectedAns(null);
            setIsAnsChecked(false);
        } else {
            setIsCalculatingResult(true);
            try {
                const finalScore = quizScore + (selectedAns === activeQuiz.questions[currentQIndex].correctOptionIndex ? 1 : 0);
                const percentage = Math.round((finalScore / activeQuiz.questions.length) * 100);
                
                if (!isAdmin && !canManageContent) {
                    const userRef = window.fb.doc(window.fb.db, "users", user.uid);
                    const currentQuizScores = userData?.quizScores || {};
                    currentQuizScores[activeQuiz.id] = percentage;
                    await window.fb.updateDoc(userRef, { quizScores: currentQuizScores });
                }
            } catch(e) {}

            setTimeout(() => {
                setIsCalculatingResult(false);
                setShowQuizResult(true);
            }, 1500);
        }
    };

    const handleCloseQuiz = () => {
        setActiveQuiz(null);
    };

    const toggleBookmark = async (matId) => {
        if (!userData) return;
        const currentBookmarks = userData.bookmarks || [];
        const isBookmarked = currentBookmarks.includes(matId);
        const updatedBookmarks = isBookmarked ? currentBookmarks.filter(id => id !== matId) : [...currentBookmarks, matId];
        try { await window.fb.updateDoc(window.fb.doc(window.fb.db, "users", user.uid), { bookmarks: updatedBookmarks }); } catch(e) {}
    };

    const toggleCompleted = async (matId) => {
        if (!userData) return;
        const currentCompleted = userData.completed || [];
        const isCompleted = currentCompleted.includes(matId);
        const updatedCompleted = isCompleted ? currentCompleted.filter(id => id !== matId) : [...currentCompleted, matId];
        try { await window.fb.updateDoc(window.fb.doc(window.fb.db, "users", user.uid), { completed: updatedCompleted }); } catch(e) {}
    };

    if (checkingSub) return <div className="text-center py-20 text-slate-400">جاري التحقق من حالة الاشتراك...</div>;

    if (activeQuiz) {
        if (isCalculatingResult) {
            return (
                <div className="max-w-md mx-auto mt-32 text-center animate-fade-in bg-white dark:bg-dark-card p-10 rounded-3xl border border-slate-200 dark:border-dark-border shadow-sm">
                    <div className="spinner w-12 h-12 border-4 border-indigo-500 mx-auto mb-6"></div>
                    <h2 className="text-xl font-bold text-slate-800 dark:text-white mb-2">جاري مراجعة إجاباتك ورصد الدرجات...</h2>
                    <p className="text-slate-500 text-sm">يرجى الانتظار لحظات</p>
                </div>
            );
        }

        if (showQuizResult) {
            const finalScore = quizScore + (selectedAns === activeQuiz.questions[currentQIndex].correctOptionIndex && isAnsChecked ? 0 : 0); 
            const percentage = Math.round((finalScore / activeQuiz.questions.length) * 100);
            return (
                <div className="max-w-md mx-auto animate-zoom-in mt-10">
                    <div className="bg-white dark:bg-dark-card rounded-3xl p-8 text-center border border-slate-200 dark:border-dark-border shadow-lg">
                        <div className={`w-24 h-24 mx-auto rounded-full flex items-center justify-center mb-6 ${percentage >= 50 ? 'bg-emerald-50 text-emerald-500 dark:bg-emerald-900/20' : 'bg-red-50 text-red-500 dark:bg-red-900/20'}`}>
                            <i data-lucide={percentage >= 50 ? "check-circle" : "alert-triangle"} className="w-12 h-12"></i>
                        </div>
                        <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-2">نتيجة الاختبار</h2>
                        <p className="text-slate-500 mb-6 font-bold">{activeQuiz.title}</p>
                        
                        <div className="flex justify-center items-center gap-4 mb-8">
                            <div className="text-center p-4 bg-slate-50 dark:bg-dark-bg rounded-2xl w-full border border-slate-100 dark:border-dark-border">
                                <div className="text-4xl font-bold font-mono text-indigo-600 dark:text-indigo-400 mb-1">{percentage}%</div>
                                <div className="text-xs font-bold text-slate-500 uppercase">النسبة المئوية المكتسبة</div>
                            </div>
                        </div>

                        <button onClick={handleCloseQuiz} className="w-full h-12 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition flex items-center justify-center gap-2">
                            <i data-lucide="arrow-right" className="w-4 h-4"></i> العودة للمكتبة
                        </button>
                    </div>
                </div>
            );
        }

        const currentQ = activeQuiz.questions[currentQIndex];
        const isLastQuestion = currentQIndex === activeQuiz.questions.length - 1;
        
        return (
            <div className="max-w-2xl mx-auto space-y-6 animate-fade-in pb-20">
                <div className="flex items-center justify-between bg-white dark:bg-dark-card p-4 rounded-2xl border border-slate-200 dark:border-dark-border shadow-sm">
                    <div>
                        <h2 className="font-bold text-slate-800 dark:text-white text-lg">{activeQuiz.title}</h2>
                        <p className="text-xs font-bold text-slate-500 flex items-center gap-1 mt-1"><i data-lucide="book" className="w-3 h-3"></i> {activeQuiz.courseName}</p>
                    </div>
                    <div className="text-center bg-indigo-50 dark:bg-indigo-900/20 px-4 py-2 rounded-xl">
                        <div className="text-[10px] text-indigo-500 font-bold uppercase">السؤال</div>
                        <div className="font-mono font-bold text-indigo-700 dark:text-indigo-400">{currentQIndex + 1} / {activeQuiz.questions.length}</div>
                    </div>
                </div>

                <div className="bg-white dark:bg-dark-card p-6 rounded-2xl border border-slate-200 dark:border-dark-border shadow-sm">
                    <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-6 leading-relaxed">
                        {currentQ.questionText}
                    </h3>

                    <div className="space-y-3">
                        {currentQ.options.map((opt, idx) => {
                            let btnClass = "border-slate-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-600 text-slate-600 dark:text-slate-300";
                            if (isAnsChecked) {
                                if (idx === currentQ.correctOptionIndex) {
                                    btnClass = "border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400";
                                } else if (idx === selectedAns) {
                                    btnClass = "border-red-500 bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400";
                                } else {
                                    btnClass = "border-slate-100 dark:border-slate-800 text-slate-400 opacity-50";
                                }
                            } else if (selectedAns === idx) {
                                btnClass = "border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-400";
                            }

                            return (
                                <button 
                                    key={idx}
                                    disabled={isAnsChecked}
                                    onClick={() => setSelectedAns(idx)}
                                    className={`w-full text-right p-4 rounded-xl border-2 transition-all flex justify-between items-center ${btnClass}`}
                                >
                                    <span className="font-bold text-sm">{opt}</span>
                                    <div style={{ display: (isAnsChecked && idx === currentQ.correctOptionIndex) ? 'block' : 'none' }}>
                                        <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" className="text-emerald-500">
                                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline>
                                        </svg>
                                    </div>
                                    <div style={{ display: (isAnsChecked && idx === selectedAns && idx !== currentQ.correctOptionIndex) ? 'block' : 'none' }}>
                                        <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" className="text-red-500">
                                            <circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line>
                                        </svg>
                                    </div>
                                </button>
                            );
                        })}
                    </div>

                    <div style={{ display: (isAnsChecked && currentQ.explanation) ? 'block' : 'none' }} className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-900/50 rounded-xl animate-fade-in">
                        <h4 className="font-bold text-blue-700 dark:text-blue-400 text-xs uppercase mb-1 flex items-center gap-1">
                            <i data-lucide="info" className="w-3 h-3"></i> تفسير الإجابة
                        </h4>
                        <p className="text-sm text-blue-600 dark:text-blue-300 leading-relaxed">{currentQ.explanation}</p>
                    </div>

                    <div className="mt-8 pt-6 border-t border-slate-100 dark:border-dark-border flex gap-3">
                        <button 
                            onClick={handleCheckAnswer}
                            disabled={selectedAns === null}
                            style={{ display: !isAnsChecked ? 'flex' : 'none' }}
                            className={`flex-1 h-12 rounded-xl font-bold transition-all justify-center items-center gap-2 ${selectedAns !== null ? 'bg-indigo-600 text-white hover:bg-indigo-700' : 'bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-600 cursor-not-allowed'}`}
                        >
                            <i data-lucide="check-square" className="w-4 h-4"></i> تحقق من الإجابة
                        </button>

                        <button 
                            onClick={handleNextQuestion}
                            style={{ display: (isAnsChecked && !isLastQuestion) ? 'flex' : 'none' }}
                            className="flex-1 h-12 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all justify-center items-center gap-2"
                        >
                            السؤال التالي <i data-lucide="arrow-left" className="w-4 h-4"></i>
                        </button>

                        <button 
                            onClick={handleNextQuestion}
                            style={{ display: (isAnsChecked && isLastQuestion) ? 'flex' : 'none' }}
                            className="flex-1 h-12 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all justify-center items-center gap-2"
                        >
                            إنهاء الاختبار <i data-lucide="flag" className="w-4 h-4"></i>
                        </button>
                        
                        <button onClick={handleCloseQuiz} className="h-12 px-6 bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300 rounded-xl font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors">
                            إغلاق
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    const userBookmarks = userData?.bookmarks || [];
    const userCompleted = userData?.completed || [];
    const userQuizScores = userData?.quizScores || {};

    const filteredMaterials = materials.filter(m => {
        try {
            const titleSafe = m.title || '';
            const courseSafe = m.courseName || '';
            const q = searchQuery ? searchQuery.toLowerCase() : '';
            const matchesSearch = titleSafe.toLowerCase().includes(q) || courseSafe.toLowerCase().includes(q);
            const matchesFilter = activeFilter === 'all' || m.type === activeFilter;
            const matchesViewMode = viewMode === 'browse' || userBookmarks.includes(m.id);
            return matchesSearch && matchesFilter && matchesViewMode;
        } catch(e) { return true; }
    });

    const groupedMaterials = filteredMaterials.reduce((acc, mat) => {
        try {
            const course = mat.courseName ? mat.courseName.trim() : 'مواد عامة';
            if (!acc[course]) acc[course] = [];
            acc[course].push(mat);
        } catch(e) {}
        return acc;
    }, {});

    return (
        <div className="space-y-6 animate-fade-in pb-20 relative">
            
            {/* 🌟 نافذة الاشتراك المتميزة (التصميم الجديد) 🌟 */}
            {showSubModal && (
                <div className="fixed inset-0 z-40 flex items-center justify-center px-4 animate-fade-in">
                    <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm" onClick={() => setShowSubModal(false)}></div>
                    <div className="bg-white dark:bg-dark-card w-full max-w-sm rounded-3xl shadow-2xl relative z-10 overflow-hidden animate-zoom-in border border-slate-200 dark:border-dark-border">
                        
                        {/* الهيدر الفخم */}
                        <div className="bg-gradient-to-br from-amber-400 to-orange-600 p-8 text-center relative">
                            <div className="absolute top-0 right-0 w-full h-full bg-white/10 opacity-20" style={{ backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)', backgroundSize: '10px 10px' }}></div>
                            <div className="w-16 h-16 mx-auto bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center mb-3 shadow-inner relative z-10 border border-white/30">
                                <i data-lucide="crown" className="w-8 h-8 text-white drop-shadow-md"></i>
                            </div>
                            <h3 className="text-2xl font-bold text-white mb-1 relative z-10 drop-shadow-md">باقة VIP</h3>
                            <p className="text-orange-50 text-sm font-medium relative z-10">افتح جميع الملازم والاختبارات المغلقة</p>
                        </div>

                        <div className="p-6 space-y-5">
                            <div className="text-center p-4 bg-slate-50 dark:bg-dark-bg rounded-2xl border border-slate-100 dark:border-dark-border">
                                <p className="text-xs text-slate-500 dark:text-dark-muted font-bold mb-1 uppercase">رصيدك الحالي</p>
                                <p className="text-3xl font-bold font-mono text-slate-800 dark:text-white">{privateData?.balance || 0} <span className="text-sm font-sans">ج.م</span></p>
                            </div>
                            
                            <button onClick={handleSubscribe} className="w-full h-14 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-xl font-bold hover:shadow-lg hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-between px-5 shadow-orange-500/30">
                                <span className="flex items-center gap-2 text-base"><i data-lucide="unlock" className="w-5 h-5"></i> اشتراك لمدة شهر</span>
                                <span className="font-mono text-lg bg-white/20 px-2 py-1 rounded-lg">{vipPrice} ج.م</span>
                            </button>
                            
                            <button onClick={() => setShowSubModal(false)} className="w-full h-10 text-slate-400 font-bold hover:text-slate-600 dark:hover:text-slate-300 transition">إلغاء</button>
                        </div>
                    </div>
                </div>
            )}

            <div className="flex justify-between items-end">
                <div>
                    <h2 className="text-2xl font-bold text-slate-800 dark:text-white flex items-center gap-2">المكتبة العلمية <i data-lucide="book-open" className="w-5 h-5 text-indigo-500"></i></h2>
                    <p className="text-slate-500 text-sm mt-1">تصفح المحاضرات، المراجع، والاختبارات</p>
                </div>
                <div className="flex flex-col items-end gap-2">
                    {!isAdmin && privateData?.subExpiry && hasValidSubscription() && (
                        <div className="bg-gradient-to-r from-amber-100 to-orange-100 dark:from-amber-900/30 dark:to-orange-900/30 px-3 py-1.5 rounded-xl border border-amber-200 dark:border-amber-800/50 shadow-sm animate-fade-in">
                            <div className="text-[10px] text-amber-700 dark:text-amber-400 font-bold uppercase flex items-center gap-1"><i data-lucide="crown" className="w-3 h-3"></i> مشترك VIP</div>
                        </div>
                    )}
                    <button 
                        style={{ display: canManageContent ? 'flex' : 'none' }}
                        onClick={() => setShowAdminPanel(!showAdminPanel)} 
                        className={`w-10 h-10 rounded-xl items-center justify-center transition-all border ${showAdminPanel ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-dark-card text-slate-500 hover:text-indigo-600 border-slate-200 dark:border-dark-border'}`} 
                        title="إدارة المحتوى"
                    >
                        <i data-lucide={showAdminPanel ? "x" : "edit-3"} className="w-5 h-5"></i>
                    </button>
                </div>
            </div>

            {canManageContent && showAdminPanel && AdminPanel && (
                <AdminPanel onClose={() => setShowAdminPanel(false)} showAlert={showAlert} />
            )}

            <div className="flex bg-slate-100 dark:bg-dark-card p-1.5 rounded-xl border border-slate-200 dark:border-dark-border">
                <button onClick={() => setViewMode('browse')} className={`flex-1 py-2 text-sm font-bold rounded-lg transition flex items-center justify-center gap-2 ${viewMode === 'browse' ? 'bg-white dark:bg-dark-bg text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-indigo-500'}`}><i data-lucide="layout-grid" className="w-4 h-4"></i> التصفح</button>
                <button onClick={() => setViewMode('bookmarks')} className={`flex-1 py-2 text-sm font-bold rounded-lg transition flex items-center justify-center gap-2 ${viewMode === 'bookmarks' ? 'bg-white dark:bg-dark-bg text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-indigo-500'}`}><i data-lucide="bookmark" className="w-4 h-4"></i> مفضلتي ({userBookmarks.length})</button>
            </div>

            {viewMode === 'browse' && (
                <div className="space-y-3">
                    <div className="relative">
                        <i data-lucide="search" className="absolute right-4 top-3 w-5 h-5 text-slate-400"></i>
                        <input type="text" placeholder="ابحث باسم المادة أو المحتوى..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full h-11 pl-4 pr-12 rounded-xl border border-slate-200 dark:border-dark-border bg-white dark:bg-dark-card text-sm outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white" />
                    </div>
                    <div className="flex gap-2 overflow-x-auto hide-scrollbar pb-1">
                        <button onClick={() => setActiveFilter('all')} className={`px-5 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors border ${activeFilter === 'all' ? 'bg-slate-800 text-white border-slate-800 dark:bg-slate-200 dark:text-slate-900' : 'bg-white dark:bg-dark-card text-slate-600 dark:text-slate-300 border-slate-200 dark:border-dark-border hover:bg-slate-50'}`}>الكل</button>
                        <button onClick={() => setActiveFilter('pdf')} className={`px-5 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors border flex items-center gap-1.5 ${activeFilter === 'pdf' ? 'bg-slate-100 text-slate-800 border-slate-300 dark:bg-dark-bg dark:text-white' : 'bg-white dark:bg-dark-card text-slate-600 dark:text-slate-300 border-slate-200 dark:border-dark-border hover:bg-slate-50'}`}><i data-lucide="file-text" className="w-3 h-3"></i> PDF</button>
                        <button onClick={() => setActiveFilter('video')} className={`px-5 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors border flex items-center gap-1.5 ${activeFilter === 'video' ? 'bg-slate-100 text-slate-800 border-slate-300 dark:bg-dark-bg dark:text-white' : 'bg-white dark:bg-dark-card text-slate-600 dark:text-slate-300 border-slate-200 dark:border-dark-border hover:bg-slate-50'}`}><i data-lucide="youtube" className="w-3 h-3"></i> فيديوهات</button>
                        <button onClick={() => setActiveFilter('drive')} className={`px-5 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors border flex items-center gap-1.5 ${activeFilter === 'drive' ? 'bg-slate-100 text-slate-800 border-slate-300 dark:bg-dark-bg dark:text-white' : 'bg-white dark:bg-dark-card text-slate-600 dark:text-slate-300 border-slate-200 dark:border-dark-border hover:bg-slate-50'}`}><i data-lucide="folder" className="w-3 h-3"></i> درايف</button>
                        <button onClick={() => setActiveFilter('quiz')} className={`px-5 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-colors border flex items-center gap-1.5 ${activeFilter === 'quiz' ? 'bg-indigo-50 text-indigo-700 border-indigo-300 dark:bg-indigo-900/30 dark:text-indigo-400' : 'bg-white dark:bg-dark-card text-slate-600 dark:text-slate-300 border-slate-200 dark:border-dark-border hover:bg-slate-50'}`}><i data-lucide="help-circle" className="w-3 h-3"></i> اختبارات</button>
                    </div>
                </div>
            )}

            <div className="space-y-8 mt-2">
                {Object.keys(groupedMaterials).length === 0 ? (
                    <div className="text-center py-12 bg-white dark:bg-dark-card rounded-2xl border border-dashed border-slate-300 dark:border-dark-border">
                        <div className="w-16 h-16 bg-slate-50 dark:bg-dark-bg rounded-full flex items-center justify-center mx-auto mb-3"><i data-lucide="search-x" className="w-8 h-8 text-slate-400"></i></div>
                        <p className="text-slate-600 dark:text-dark-muted font-bold text-sm">لم نجد محتوى يطابق بحثك.</p>
                    </div>
                ) : (
                    Object.keys(groupedMaterials).map(course => (
                        <div key={course} className="animate-fade-in">
                            <h3 className="font-bold text-base text-slate-800 dark:text-white mb-3 flex items-center gap-2 border-b border-slate-100 dark:border-dark-border pb-2">
                                <span className="w-1.5 h-4 bg-indigo-500 rounded-full inline-block"></span> {course}
                            </h3>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                {groupedMaterials[course].map(mat => {
                                    const isBookmarked = userBookmarks.includes(mat.id);
                                    const isCompleted = userCompleted.includes(mat.id);
                                    const isLocked = !mat.isFree && !hasValidSubscription();
                                    
                                    const studentQuizScore = userQuizScores[mat.id];
                                    const hasTakenQuiz = studentQuizScore !== undefined;
                                    
                                    let typeIcon = 'folder';
                                    let typeColor = 'bg-emerald-50 text-emerald-600';
                                    let typeLabel = mat.type;
                                    
                                    if(mat.type==='pdf') { typeIcon='file-text'; typeColor='bg-red-50 text-red-600'; }
                                    if(mat.type==='video') { typeIcon='youtube'; typeColor='bg-blue-50 text-blue-600'; }
                                    if(mat.type==='quiz') { typeIcon='help-circle'; typeColor='bg-indigo-50 text-indigo-600'; typeLabel='اختبار'; }

                                    return (
                                        <div key={mat.id} className={`p-3.5 rounded-xl border transition-all relative overflow-hidden group ${isCompleted ? 'bg-slate-50 dark:bg-dark-bg/50 border-slate-200 dark:border-dark-border opacity-80 hover:opacity-100' : isLocked ? 'bg-slate-50/50 dark:bg-dark-card border-slate-200 dark:border-dark-border opacity-90' : 'bg-white dark:bg-dark-card border-slate-200 dark:border-dark-border hover:border-indigo-200 shadow-sm'}`}>
                                            
                                            <button onClick={() => toggleCompleted(mat.id)} className={`absolute top-3 left-3 px-2 py-1 text-[10px] font-bold rounded transition-colors border flex items-center gap-1 z-10 ${isCompleted ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400 dark:border-emerald-800' : 'bg-white text-slate-400 border-slate-200 hover:bg-slate-50 dark:bg-dark-bg dark:border-dark-border dark:hover:bg-slate-800'}`} title="تحديد كـ 'مكتمل'">
                                                {isCompleted ? <><i data-lucide="check" className="w-3 h-3"></i> مكتمل</> : <><i data-lucide="circle" className="w-3 h-3"></i> قيد الانتظار</>}
                                            </button>

                                            <div className="flex items-center gap-3 mb-3 pr-1">
                                                <div className={`w-10 h-10 rounded-lg shrink-0 flex items-center justify-center border border-slate-100 dark:border-dark-border relative ${typeColor} dark:bg-dark-bg`}>
                                                    <i data-lucide={typeIcon} className={`w-5 h-5 ${isLocked ? 'opacity-30' : ''}`}></i>
                                                    {isLocked && <div className="absolute inset-0 flex items-center justify-center"><i data-lucide="lock" className="w-4 h-4 text-slate-700 dark:text-slate-300"></i></div>}
                                                </div>
                                                <div className="flex-1 overflow-hidden">
                                                    <h4 className={`font-bold text-sm truncate ${isCompleted ? 'text-slate-500 line-through dark:text-slate-400' : 'text-slate-800 dark:text-white'}`}>{mat.title}</h4>
                                                    <div className="flex items-center gap-2 mt-1">
                                                        <span className="text-[10px] font-bold uppercase text-slate-500 flex items-center gap-1"><i data-lucide="layout" className="w-3 h-3"></i> {typeLabel}</span>
                                                        
                                                        {/* 🌟 تصميم التبويبات الجديد 🌟 */}
                                                        {mat.isFree ? (
                                                            <span className="text-[10px] font-bold bg-emerald-100 text-emerald-700 border border-emerald-200 dark:bg-emerald-900/40 dark:border-emerald-800/50 dark:text-emerald-400 px-2 py-0.5 rounded-md flex items-center gap-1 shadow-sm"><i data-lucide="unlock" className="w-3 h-3"></i> مجاني</span>
                                                        ) : (
                                                            <span className="text-[10px] font-bold bg-gradient-to-r from-amber-400 to-orange-500 text-white shadow-sm px-2 py-0.5 rounded-md flex items-center gap-1"><i data-lucide="crown" className="w-3 h-3"></i> VIP</span>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-dark-border mt-1 relative z-10">
                                                <button onClick={() => handleOpenLink(mat)} className={`flex-1 h-9 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${isLocked ? 'bg-orange-50 text-orange-600 border border-orange-200 hover:bg-orange-100 dark:bg-orange-900/20 dark:border-orange-800/50 dark:text-orange-400 shadow-sm' : (mat.type === 'quiz' ? (hasTakenQuiz ? 'bg-slate-50 text-slate-600 border border-slate-200 hover:bg-slate-100 dark:bg-dark-bg dark:text-slate-300 dark:border-slate-700' : 'bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white dark:bg-indigo-900/30 dark:text-indigo-400 dark:hover:bg-indigo-600 dark:hover:text-white') : 'bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white dark:bg-indigo-900/30 dark:text-indigo-400 dark:hover:bg-indigo-600 dark:hover:text-white')}`}>
                                                    {isLocked ? (
                                                        <><i data-lucide="lock" className="w-3 h-3"></i> اشترك للفتح</>
                                                    ) : (
                                                        mat.type === 'quiz' ? (
                                                            hasTakenQuiz ? <><i data-lucide="rotate-ccw" className="w-3 h-3"></i> إعادة ({studentQuizScore}%)</> : <><i data-lucide="play-circle" className="w-3 h-3"></i> ابدأ الاختبار</>
                                                        ) : <><i data-lucide="external-link" className="w-3 h-3"></i> فتح المحتوى</>
                                                    )}
                                                </button>
                                                
                                                <div className="flex items-center gap-1 rtl:mr-2 ltr:ml-2">
                                                    <button onClick={() => toggleBookmark(mat.id)} className={`w-9 h-9 flex items-center justify-center rounded-lg transition-colors ${isBookmarked ? 'bg-indigo-50 text-indigo-600 dark:bg-indigo-900/20' : 'text-slate-400 hover:bg-slate-100 dark:bg-dark-bg'}`} title={isBookmarked ? "إزالة من المفضلة" : "إضافة للمفضلة"}>
                                                        <span key={isBookmarked ? 'marked' : 'unmarked'}><i data-lucide="bookmark" className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`}></i></span>
                                                    </button>
                                                    
                                                    <div style={{ display: canManageContent ? 'flex' : 'none' }} className="items-center gap-1">
                                                        <div className="flex items-center gap-1 text-[10px] font-bold text-slate-400 bg-slate-50 dark:bg-dark-bg px-2 h-9 rounded-lg border border-slate-100 dark:border-dark-border" title="مشاهدات فريدة">
                                                            <i data-lucide="eye" className="w-3 h-3"></i> {mat.views || 0}
                                                        </div>
                                                        <button onClick={() => handleDelete(mat.id)} className="w-9 h-9 flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-red-500 transition-colors">
                                                            <i data-lucide="trash-2" className="w-3 h-3"></i>
                                                        </button>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};
 