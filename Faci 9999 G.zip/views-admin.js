// --- views-admin.js ---
// الغرفة السريّة: (تم حل مشكلة الشاشة البيضاء نهائياً وتأمين أزرار الحفظ 🛡️)

var { useState, useEffect } = React;
var ADMIN_EMAIL = "mohammadsafe202a@gmail.com";

var AdminPanelView = ({ user, showAlert }) => {
    const [tab, setTab] = useState('students');
    const [students, setStudents] = useState([]);
    const [newPost, setNewPost] = useState({ title: '', content: '', type: 'info' });
    const [isAdding, setIsAdding] = useState(false);
    
    const [isMigrating, setIsMigrating] = useState(false);
    const [migrationDone, setMigrationDone] = useState(false);
    
    // 🌟 حالة سعر الـ VIP 🌟
    const [vipPrice, setVipPrice] = useState(250); 
    const [isSavingPrice, setIsSavingPrice] = useState(false);
    
    const [totalPosts, setTotalPosts] = useState(0);

    const [roleModalOpen, setRoleModalOpen] = useState(false);
    const [selectedStudent, setSelectedStudent] = useState(null);
    const [tempRoles, setTempRoles] = useState({ isVerified: false, isCouncil: false });
    const [isSavingRoles, setIsSavingRoles] = useState(false);

    const [pinnedStudents, setPinnedStudents] = useState(() => {
        const saved = localStorage.getItem('pinnedAdminStudents');
        return saved ? JSON.parse(saved) : [];
    });

    useEffect(() => {
        let unsubUsersPublic = () => {};
        let unsubUsersPrivate = () => {};
        let unsubPosts = () => {};
        let unsubSettings = () => {};

        try {
            let publicData = [];
            let privateData = [];

            const combineData = () => {
                let fetchedStudents = publicData.map(pub => {
                    const priv = privateData.find(p => p.id === pub.id) || {};
                    
                    const finalBalance = priv.migrated ? (priv.balance || 0) : (pub.balance || priv.balance || 0);
                    const finalIsCouncil = priv.migrated ? priv.isCouncil : (pub.isCouncil || false);
                    const finalIsVerified = priv.migrated ? priv.isVerified : (pub.isVerified || false);
                    const finalIsBanned = priv.migrated ? priv.isBanned : (pub.isBanned || false);
                    const finalSubExpiry = priv.migrated ? priv.subExpiry : pub.subExpiry;
                    
                    return { 
                        ...pub, ...priv, 
                        balance: finalBalance, isCouncil: finalIsCouncil, isVerified: finalIsVerified,
                        isBanned: finalIsBanned, subExpiry: finalSubExpiry, id: pub.id 
                    };
                });
                
                fetchedStudents.sort((a, b) => {
                    const aPinned = pinnedStudents.includes(a.id);
                    const bPinned = pinnedStudents.includes(b.id);
                    if (aPinned && !bPinned) return -1;
                    if (!aPinned && bPinned) return 1;
                    if (a.isOnline === b.isOnline) return (a.name || '').localeCompare(b.name || '', 'ar');
                    return a.isOnline ? -1 : 1;
                });
                
                setStudents(fetchedStudents);
            };

            unsubUsersPublic = window.fb.onSnapshot(window.fb.query(window.fb.collection(window.fb.db, "users")), (snapshot) => {
                publicData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                combineData();
            });

            unsubUsersPrivate = window.fb.onSnapshot(window.fb.query(window.fb.collection(window.fb.db, "users_private")), (snapshot) => {
                privateData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                combineData();
            });

            unsubPosts = window.fb.onSnapshot(window.fb.query(window.fb.collection(window.fb.db, "forum_posts")), (snap) => setTotalPosts(snap.size));

            const settingsRef = window.fb.doc(window.fb.db, "settings", "general");
            unsubSettings = window.fb.onSnapshot(settingsRef, (docSnap) => {
                if (docSnap.exists() && docSnap.data().vipPrice !== undefined) {
                    setVipPrice(docSnap.data().vipPrice);
                } else {
                    window.fb.setDoc(settingsRef, { vipPrice: 250 }, { merge: true }).catch(()=>{});
                }
            });

        } catch(e) {}

        return () => { unsubUsersPublic(); unsubUsersPrivate(); unsubPosts(); unsubSettings(); };
    }, [pinnedStudents]); 

    useEffect(() => { 
        let timeoutId;
        if (window.lucide) {
            timeoutId = setTimeout(() => { try { window.lucide.createIcons(); } catch(e) {} }, 100);
        }
        return () => clearTimeout(timeoutId);
    }, [tab, students, roleModalOpen]);

    const onlineCount = students.filter(s => s.isOnline).length;
    const vipCount = students.filter(s => s.subExpiry && new Date(s.subExpiry) > new Date()).length;
    const totalStudents = students.length;

    const togglePin = (studentId) => {
        setPinnedStudents(prev => {
            const newPinned = prev.includes(studentId) ? prev.filter(id => id !== studentId) : [...prev, studentId];
            localStorage.setItem('pinnedAdminStudents', JSON.stringify(newPinned));
            return newPinned;
        });
    };

    const addBalance = async (studentId, currentBalance, studentName) => {
        const amount = prompt(`أدخل المبلغ المراد إضافته للطالب (${studentName}):\n(يمكنك كتابة رقم سالب لخصم رصيد)`);
        if(amount && !isNaN(amount)) {
            try {
                const numAmount = parseFloat(amount);
                const newBalance = (currentBalance || 0) + numAmount;
                await window.fb.setDoc(window.fb.doc(window.fb.db, "users_private", studentId), { balance: newBalance, migrated: true }, { merge: true });
                
                let msg = numAmount > 0 
                    ? `تم إضافة مبلغ ${numAmount} ج.م. لحسابك بنجاح، وأصبح رصيدك الحالي ${newBalance} ج.م.` 
                    : `تم خصم مبلغ ${Math.abs(numAmount)} ج.م. من حسابك، وأصبح رصيدك الحالي ${newBalance} ج.م.`;

                await window.fb.addDoc(window.fb.collection(window.fb.db, "news"), {
                    title: 'تحديث الرصيد', content: msg, type: 'info', date: new Date().toISOString(), author: 'Admin', seenBy: [], targetUid: studentId
                });
                showAlert("تمت العملية", `تم التحديث لـ ${studentName}.`, "success", ()=>{});
            } catch(e) {}
        }
    };

    const giftVIP = async (student) => {
        showAlert("إهداء VIP", `هل تريد منح اشتراك المحتوى العلمي مجاناً لمدة شهر للطالب ${student.name}؟`, "info", async () => {
            try {
                const expiry = new Date();
                expiry.setDate(expiry.getDate() + 30);
                await window.fb.setDoc(window.fb.doc(window.fb.db, "users_private", student.id), { subExpiry: expiry.toISOString(), migrated: true }, { merge: true });
                
                await window.fb.addDoc(window.fb.collection(window.fb.db, "news"), {
                    title: 'هدية من الإدارة', content: 'مبروك! تم منحك وصولاً كاملاً للمحتوى العلمي (VIP) لمدة شهر مجاناً من قِبل الإدارة.', type: 'event', date: new Date().toISOString(), author: 'Admin', targetUid: student.id, seenBy: []
                });
                showAlert("تم الإهداء", "تم تفعيل الاشتراك للطالب بنجاح.", "success", ()=>{});
            } catch(e) {}
        });
    };

    const toggleBan = async (student) => {
        const isBanning = !student.isBanned;
        const actionText = isBanning ? 'حظر' : 'فك حظر';
        showAlert(`${actionText} المستخدم`, `هل أنت متأكد أنك تريد ${actionText} الطالب ${student.name}؟`, "danger", async () => {
            try {
                await window.fb.setDoc(window.fb.doc(window.fb.db, "users_private", student.id), { isBanned: isBanning, migrated: true }, { merge: true });
                showAlert("تم", `تم ${actionText} الطالب بنجاح.`, "success", ()=>{});
            } catch(e) {}
        });
    };

    const openRoleModal = (student) => {
        setSelectedStudent(student);
        setTempRoles({ isVerified: student.isVerified || false, isCouncil: student.isCouncil || false });
        setRoleModalOpen(true);
    };

    const saveRoles = async () => {
        if (!selectedStudent) return;
        setIsSavingRoles(true); 
        
        const targetId = selectedStudent.id;
        const targetName = selectedStudent.name;
        const wasCouncil = selectedStudent.isCouncil;
        const newRoles = { ...tempRoles };
        
        try {
            await window.fb.setDoc(window.fb.doc(window.fb.db, "users_private", targetId), {
                isVerified: newRoles.isVerified, isCouncil: newRoles.isCouncil, migrated: true
            }, { merge: true });
            
            if (newRoles.isCouncil && !wasCouncil) {
                await window.fb.addDoc(window.fb.collection(window.fb.db, "news"), {
                    title: 'ترقية إدارية', content: 'تهانينا! تمت ترقيتك من قِبل الإدارة لتصبح عضواً رسمياً في مجلس الطلاب.', type: 'event', date: new Date().toISOString(), author: 'Admin', targetUid: targetId, seenBy: []
                });
            }
            
            setIsSavingRoles(false); setRoleModalOpen(false); setSelectedStudent(null);
            showAlert("تم بنجاح", `تم تحديث صلاحيات ${targetName}.`, "success", () => {});
        } catch(e) {
            setIsSavingRoles(false); showAlert("خطأ", "حدث مشكلة أثناء الحفظ، يرجى المحاولة لاحقاً.", "danger", () => {});
        }
    };

    // 🌟 دالة حفظ السعر الآمنة بدون شاشة بيضاء 🌟
    const handleSavePrice = async () => {
        if (vipPrice === '' || isNaN(vipPrice)) return;
        setIsSavingPrice(true);
        try {
            await window.fb.setDoc(window.fb.doc(window.fb.db, "settings", "general"), { vipPrice: Number(vipPrice) }, { merge: true });
            setIsSavingPrice(false);
            showAlert("تم التحديث", `تم تعيين سعر باقة VIP ليكون ${vipPrice} ج.م بنجاح.`, "success", () => {});
        } catch(e) {
            setIsSavingPrice(false);
            showAlert("خطأ", "حدث خطأ أثناء حفظ السعر.", "danger", () => {});
        }
    };

    const exportToCSV = () => {
        let csvContent = "data:text/csv;charset=utf-8,\uFEFF"; 
        csvContent += "الاسم,الكود الجامعي,البريد الإلكتروني,الرصيد,حالة الحساب,الرتبة,نوع الاشتراك\n";
        students.forEach(s => {
            const status = s.isBanned ? "محظور" : "نشط";
            const vip = (s.subExpiry && new Date(s.subExpiry) > new Date()) ? "VIP" : "عادي";
            const role = s.isCouncil ? "مجلس طلاب" : s.isVerified ? "موثق" : "طالب";
            const safeName = (s.name || 'مجهول').replace(/,/g, ' ');
            csvContent += `${safeName},${s.uniId || '-'},${s.email || '-'},${s.balance || 0},${status},${role},${vip}\n`;
        });
        const encodedUri = encodeURI(csvContent); const link = document.createElement("a"); link.setAttribute("href", encodedUri); link.setAttribute("download", `كشف_الطلاب_${new Date().toLocaleDateString('ar-EG')}.csv`); document.body.appendChild(link); link.click(); document.body.removeChild(link);
    };

    const handlePostNews = async (e) => {
        e.preventDefault(); 
        if (!newPost.title.trim() || !newPost.content.trim()) return;
        setIsAdding(true);
        try {
            await window.fb.addDoc(window.fb.collection(window.fb.db, "news"), {
                title: newPost.title, content: newPost.content, type: newPost.type, date: new Date().toISOString(), author: 'Admin', seenBy: []
            });
            setNewPost({ title: '', content: '', type: 'info' }); setIsAdding(false);
            showAlert("تم النشر", "تم نشر الإشعار للجميع بنجاح.", "success", () => {});
        } catch (error) { setIsAdding(false); showAlert("خطأ", "حدث خطأ أثناء النشر.", "danger", () => {}); }
    };

    const isRemovingRoles = selectedStudent && ((selectedStudent.isVerified && !tempRoles.isVerified) || (selectedStudent.isCouncil && !tempRoles.isCouncil));
    const isPromotingRoles = selectedStudent && ((!selectedStudent.isVerified && tempRoles.isVerified) || (!selectedStudent.isCouncil && tempRoles.isCouncil));
    const buttonText = isRemovingRoles ? 'جاري الإزالة...' : isPromotingRoles ? 'جاري الترقية...' : 'جاري الحفظ...';

    return (
        <div className="space-y-6 animate-fade-in pb-20 relative">
            
            {roleModalOpen && selectedStudent && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center px-4 animate-fade-in">
                    <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => !isSavingRoles && setRoleModalOpen(false)}></div>
                    <div className="bg-white dark:bg-dark-card w-full max-w-sm rounded-3xl shadow-2xl relative z-10 overflow-hidden animate-zoom-in border border-slate-200 dark:border-dark-border">
                        <div className="bg-indigo-600 p-6 text-center text-white relative">
                            <button onClick={() => !isSavingRoles && setRoleModalOpen(false)} className="absolute top-4 left-4 p-1 bg-white/20 hover:bg-white/30 rounded-full transition"><i data-lucide="x" className="w-4 h-4"></i></button>
                            <div className="w-12 h-12 mx-auto mb-2 opacity-90 flex items-center justify-center"><i data-lucide="shield-check" className="w-8 h-8"></i></div>
                            <h3 className="text-xl font-bold">إدارة الصلاحيات</h3>
                            <p className="text-indigo-100 text-sm mt-1">{selectedStudent.name}</p>
                        </div>
                        <div className="p-6 space-y-4">
                            <label className={`flex items-center gap-4 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 transition-colors ${isSavingRoles ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
                                <input type="checkbox" checked={tempRoles.isVerified} onChange={e => setTempRoles({...tempRoles, isVerified: e.target.checked})} className="w-5 h-5 accent-blue-500 rounded" disabled={isSavingRoles} />
                                <div><div className="font-bold text-slate-800 dark:text-white flex items-center gap-1.5 text-sm">توثيق الحساب</div><div className="text-xs text-slate-500 mt-0.5">يمنح الطالب علامة التوثيق الزرقاء</div></div>
                            </label>
                            <label className={`flex items-center gap-4 p-4 rounded-2xl border border-orange-200 dark:border-orange-900/30 transition-colors ${isSavingRoles ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:bg-orange-50 dark:hover:bg-orange-900/10'}`}>
                                <input type="checkbox" checked={tempRoles.isCouncil} onChange={e => setTempRoles({...tempRoles, isCouncil: e.target.checked})} className="w-5 h-5 accent-orange-500 rounded" disabled={isSavingRoles} />
                                <div><div className="font-bold text-orange-700 dark:text-orange-500 flex items-center gap-1.5 text-sm">مجلس الطلاب</div><div className="text-xs text-orange-600/70 dark:text-orange-400/70 mt-0.5">ترقية لعضوية فريق الإدارة وإشراف المنتدى</div></div>
                            </label>
                            <button onClick={saveRoles} disabled={isSavingRoles} className={`w-full h-12 mt-2 rounded-xl font-bold text-white transition-all flex items-center justify-center gap-2 shadow-md ${isSavingRoles ? 'bg-indigo-400' : 'bg-indigo-600 hover:bg-indigo-700'}`}>
                                {isSavingRoles ? <div className="spinner w-5 h-5 border-2"></div> : null} 
                                <span>{isSavingRoles ? buttonText : 'حفظ التعديلات'}</span>
                            </button>
                        </div>
                    </div>
                </div>
            )}

            <h2 className="text-2xl font-bold text-slate-800 dark:text-white flex items-center gap-2"><i data-lucide="shield-alert" className="w-6 h-6 text-indigo-500"></i> لوحة الإدارة</h2>
            
            <div className="flex bg-slate-200/50 dark:bg-dark-card p-1.5 rounded-2xl shadow-sm border border-slate-200 dark:border-dark-border overflow-x-auto hide-scrollbar">
                <button onClick={() => setTab('students')} className={`flex-1 min-w-[90px] py-2 text-sm font-bold rounded-xl transition ${tab === 'students' ? 'bg-white dark:bg-dark-bg text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-indigo-500'}`}>الطلاب</button>
                <button onClick={() => setTab('notifications')} className={`flex-1 min-w-[90px] py-2 text-sm font-bold rounded-xl transition ${tab === 'notifications' ? 'bg-white dark:bg-dark-bg text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-indigo-500'}`}>الأخبار</button>
                <button onClick={() => setTab('more')} className={`flex-1 min-w-[90px] py-2 text-sm font-bold rounded-xl transition ${tab === 'more' ? 'bg-white dark:bg-dark-bg text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-indigo-500'}`}>إحصائيات</button>
            </div>

            {tab === 'students' && (
                <div className="grid gap-3 animate-fade-in">
                    {students.map(s => {
                        const isPinned = pinnedStudents.includes(s.id);
                        return (
                            <div key={s.id} className={`bg-white dark:bg-dark-card p-4 rounded-xl shadow-sm border transition-all hover:shadow-md flex flex-col md:flex-row gap-4 justify-between md:items-center ${s.isBanned ? 'border-red-300 bg-red-50 dark:bg-red-900/10' : isPinned ? 'border-indigo-300 dark:border-indigo-700 bg-indigo-50/30 dark:bg-indigo-900/10' : 'border-slate-200 dark:border-dark-border'}`}>
                                <div className="flex items-center gap-4">
                                    <div className="relative shrink-0">
                                        <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-dark-bg flex items-center justify-center overflow-hidden border border-slate-200 dark:border-dark-border cursor-pointer">
                                            {s.photo ? <img src={s.photo} className="w-full h-full object-cover"/> : <div className="flex items-center justify-center"><i data-lucide="user" className="w-6 h-6 text-slate-400"></i></div>}
                                        </div>
                                        <div className={`absolute bottom-0 left-0 w-3.5 h-3.5 border-2 border-white dark:border-dark-card rounded-full ${s.isOnline ? 'bg-green-500' : 'bg-slate-400'}`}></div>
                                        <button onClick={() => togglePin(s.id)} className={`absolute -top-1 -right-1 w-5 h-5 rounded-full border-2 border-white dark:border-dark-card flex items-center justify-center transition-colors ${isPinned ? 'bg-indigo-500 text-white' : 'bg-slate-200 text-slate-400 hover:bg-indigo-100 hover:text-indigo-500'}`} title={isPinned ? "إلغاء التثبيت" : "تثبيت الطالب بالأعلى"}><i data-lucide="pin" className="w-3 h-3"></i></button>
                                    </div>
                                    <div className="overflow-hidden pr-1">
                                        <h3 className="font-bold text-sm text-slate-800 dark:text-white flex items-center gap-1 flex-wrap">
                                            {s.name || 'مجهول'} 
                                            {(s.isVerified || s.email === ADMIN_EMAIL) && <div title="موثق" className="flex items-center justify-center"><i data-lucide="badge-check" className="w-3.5 h-3.5 text-blue-500"></i></div>}
                                            {(s.isCouncil || s.email === ADMIN_EMAIL) && <div title="عضو مجلس" className="flex items-center justify-center"><i data-lucide="crown" className="w-3.5 h-3.5 text-orange-500"></i></div>}
                                            {s.isBanned && <span className="text-[9px] bg-red-500 text-white px-1.5 rounded">محظور</span>}
                                            {s.subExpiry && new Date(s.subExpiry) > new Date() && <span className="text-[9px] bg-indigo-500 text-white px-1.5 rounded">VIP</span>}
                                        </h3>
                                        <p className="text-[10px] text-slate-500 font-mono mt-0.5 truncate">{s.email}</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2 rtl:mr-16 md:rtl:mr-0 border-t md:border-t-0 border-slate-100 dark:border-dark-border pt-3 md:pt-0 shrink-0">
                                    <span className="font-bold font-mono text-indigo-600 dark:text-indigo-400 text-sm w-16 text-center">{s.balance || 0} ج</span>
                                    <button onClick={() => addBalance(s.id, s.balance, s.name)} className="w-8 h-8 bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white rounded-lg flex items-center justify-center transition-colors"><i data-lucide="coins" className="w-4 h-4"></i></button>
                                    <button onClick={() => giftVIP(s)} className="w-8 h-8 bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white rounded-lg flex items-center justify-center transition-colors"><i data-lucide="award" className="w-4 h-4"></i></button>
                                    <button onClick={() => openRoleModal(s)} className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${s.isCouncil || s.isVerified ? 'bg-orange-500 text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-800 hover:text-white'}`}><i data-lucide="shield" className="w-4 h-4"></i></button>
                                    <button onClick={() => toggleBan(s)} className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${s.isBanned ? 'bg-red-500 text-white' : 'bg-red-50 text-red-500 hover:bg-red-500 hover:text-white'}`}><i data-lucide={s.isBanned ? "unlock" : "ban"} className="w-4 h-4"></i></button>
                                </div>
                            </div>
                        )
                    })}
                </div>
            )}

            {tab === 'notifications' && (
                <div className="bg-white dark:bg-dark-card p-6 rounded-2xl shadow-sm border border-slate-200 dark:border-dark-border animate-zoom-in">
                    <form onSubmit={handlePostNews} className="space-y-4">
                        <div><input type="text" placeholder="عنوان الإشعار..." className="w-full h-12 px-4 border rounded-xl bg-slate-50 dark:bg-dark-bg text-slate-800 dark:text-white" value={newPost.title} onChange={e => setNewPost({...newPost, title: e.target.value})} required /></div>
                        <div>
                            <select className="w-full h-12 px-4 border rounded-xl bg-slate-50 dark:bg-dark-bg text-slate-800 dark:text-white" value={newPost.type} onChange={e => setNewPost({...newPost, type: e.target.value})}>
                                <option value="info">عادي</option><option value="urgent">عاجل</option><option value="event">فعالية</option>
                            </select>
                        </div>
                        <div><textarea placeholder="تفاصيل الخبر..." className="w-full h-32 p-4 border rounded-xl bg-slate-50 dark:bg-dark-bg text-slate-800 dark:text-white" value={newPost.content} onChange={e => setNewPost({...newPost, content: e.target.value})} required></textarea></div>
                        <button disabled={isAdding} type="submit" className={`w-full h-12 rounded-xl font-bold transition-colors flex justify-center items-center gap-2 ${isAdding ? 'bg-indigo-400 text-white cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-md'}`}>
                            {isAdding ? <div className="spinner w-4 h-4 border-2 border-white"></div> : null}
                            <span>{isAdding ? 'جاري النشر...' : 'إرسال الإشعار'}</span>
                        </button>
                    </form>
                </div>
            )}

            {tab === 'more' && (
                <div className="space-y-4 animate-fade-in">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        <div className="bg-white dark:bg-dark-card p-4 rounded-2xl text-center shadow-sm border border-slate-100 dark:border-dark-border"><h4 className="text-2xl font-bold font-mono text-slate-800 dark:text-white">{totalStudents}</h4><p className="text-[10px] text-slate-500 uppercase">إجمالي الطلاب</p></div>
                        <div className="bg-white dark:bg-dark-card p-4 rounded-2xl text-center shadow-sm border border-slate-100 dark:border-dark-border"><h4 className="text-2xl font-bold font-mono text-green-500">{onlineCount}</h4><p className="text-[10px] text-slate-500 uppercase">متصل الآن</p></div>
                        <div className="bg-white dark:bg-dark-card p-4 rounded-2xl text-center shadow-sm border border-slate-100 dark:border-dark-border"><h4 className="text-2xl font-bold font-mono text-indigo-500">{vipCount}</h4><p className="text-[10px] text-slate-500 uppercase">مشتركي VIP</p></div>
                        <div className="bg-white dark:bg-dark-card p-4 rounded-2xl text-center shadow-sm border border-slate-100 dark:border-dark-border"><h4 className="text-2xl font-bold font-mono text-purple-500">{totalPosts}</h4><p className="text-[10px] text-slate-500 uppercase">منشورات</p></div>
                    </div>

                    {/* 🌟 صندوق التحكم في سعر الباقة (آمن 100%) 🌟 */}
                    <div className="bg-white dark:bg-dark-card p-6 rounded-2xl shadow-sm border border-slate-200 dark:border-dark-border flex flex-col md:flex-row items-center justify-between gap-4 mt-4">
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 rounded-full flex items-center justify-center shrink-0">
                                <i data-lucide="tag" className="w-6 h-6"></i>
                            </div>
                            <div>
                                <h3 className="font-bold text-lg text-slate-800 dark:text-white">سعر باقة VIP</h3>
                                <p className="text-xs text-slate-500 mt-1">قم بتغيير سعر الاشتراك الشهري لتطبيق خصومات وعروض.</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-2 w-full md:w-auto">
                            <input 
                                type="number" 
                                value={vipPrice} 
                                onChange={(e) => setVipPrice(e.target.value)} 
                                className="w-24 h-12 px-3 border border-slate-200 dark:border-slate-700 rounded-xl text-center font-bold font-mono outline-none focus:ring-2 focus:ring-emerald-500 dark:bg-dark-bg dark:text-white"
                            />
                            <span className="font-bold text-slate-500 mr-1">ج.م</span>
                            <button 
                                onClick={handleSavePrice} 
                                disabled={isSavingPrice}
                                className={`h-12 px-5 font-bold rounded-xl shadow-md transition-colors flex items-center justify-center gap-2 min-w-[130px] ${isSavingPrice ? 'bg-emerald-400 text-white cursor-not-allowed' : 'bg-emerald-600 hover:bg-emerald-700 text-white'}`}
                            >
                                {isSavingPrice ? <div className="spinner w-4 h-4 border-2 border-white"></div> : null}
                                <span>{isSavingPrice ? 'جاري الحفظ...' : 'حفظ التعديل'}</span>
                            </button>
                        </div>
                    </div>

                    <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl p-6 text-white shadow-lg flex flex-col md:flex-row items-center justify-between gap-4 mt-4">
                        <div className="flex items-center gap-4 text-center md:text-right">
                            <div className="w-14 h-14 bg-white/20 rounded-full flex items-center justify-center shrink-0 backdrop-blur-sm"><i data-lucide="file-spreadsheet" className="w-7 h-7 text-white"></i></div>
                            <div>
                                <h3 className="font-bold text-lg">قاعدة بيانات الطلاب</h3>
                                <p className="text-indigo-50 text-xs mt-1 opacity-90">قم بتحميل كشف كامل (Excel/CSV) ببيانات كل المشتركين</p>
                            </div>
                        </div>
                        <button onClick={exportToCSV} className="w-full md:w-auto px-6 py-3 bg-white text-indigo-600 hover:bg-indigo-50 rounded-xl font-bold shadow-md transition-all flex items-center justify-center gap-2">
                            <i data-lucide="download" className="w-4 h-4"></i> تحميل الكشف
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};
