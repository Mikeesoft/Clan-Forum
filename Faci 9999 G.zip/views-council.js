// --- views-council.js ---
// شاشة مجلس الطلاب: تعرض الأعضاء وتتيح للأدمن تحديد الصلاحيات الفرعية لكل مشرف

var { useState, useEffect } = React;
var ADMIN_EMAIL = "mohammadsafe202a@gmail.com";

window.CouncilView = ({ user, showAlert, setTab, onBack }) => {
    const [members, setMembers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedUserUid, setSelectedUserUid] = useState(null);
    
    // حالات نافذة الصلاحيات الخاصة بالأدمن الأساسي
    const [permissionsModalOpen, setPermissionsModalOpen] = useState(false);
    const [selectedMember, setSelectedMember] = useState(null);
    const [tempPerms, setTempPerms] = useState({ manageContent: false, manageForum: false });
    const [isSaving, setIsSaving] = useState(false);

    const isAdmin = user.email === ADMIN_EMAIL;

    useEffect(() => {
        let unsub = () => {};
        try {
            // جلب المستخدمين الذين لديهم صفة "مجلس الطلاب"
            const q = window.fb.query(
                window.fb.collection(window.fb.db, "users"),
                window.fb.where("isCouncil", "==", true)
            );
            
            unsub = window.fb.onSnapshot(q, (snapshot) => {
                const fetchedMembers = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                setMembers(fetchedMembers);
                setLoading(false);
            });
        } catch (error) {
            setLoading(false);
        }
        return () => unsub();
    }, []);

    useEffect(() => {
        let timeoutId;
        if (window.lucide) {
            timeoutId = setTimeout(() => {
                try { window.lucide.createIcons(); } catch(e) {}
            }, 50);
        }
        return () => clearTimeout(timeoutId);
    }, [members, loading, permissionsModalOpen, isSaving]);

    const openPermissionsModal = (member) => {
        setSelectedMember(member);
        // جلب الصلاحيات الحالية إن وجدت، وإلا افتراضية (خطأ)
        setTempPerms({
            manageContent: member.councilPermissions?.manageContent || false,
            manageForum: member.councilPermissions?.manageForum || false
        });
        setPermissionsModalOpen(true);
    };

    const savePermissions = () => {
        if (!selectedMember) return;
        setIsSaving(true);
        
        const targetId = selectedMember.id;
        const newPerms = { ...tempPerms };
        
        setPermissionsModalOpen(false);
        setSelectedMember(null);

        Promise.resolve().then(async () => {
            try {
                await window.fb.updateDoc(window.fb.doc(window.fb.db, "users", targetId), {
                    councilPermissions: newPerms
                });
                setIsSaving(false);
                showAlert("تم بنجاح", "تم تحديث صلاحيات المشرف بنجاح.", "success", () => {});
            } catch (e) {
                setIsSaving(false);
                showAlert("خطأ", "حدث خطأ أثناء حفظ الصلاحيات.", "danger", () => {});
            }
        });
    };

    // في حال الضغط على عضو، نفتح ملفه الشخصي العام
    if (selectedUserUid) {
        return (
            <window.PublicProfileView 
                currentUser={user} 
                targetUid={selectedUserUid} 
                onBack={() => setSelectedUserUid(null)} 
                showAlert={showAlert} 
                setTab={setTab} 
            />
        );
    }

    return (
        <div className="space-y-6 animate-fade-in pb-20 relative">
            
            {/* نافذة تعديل الصلاحيات (للأدمن فقط) */}
            {permissionsModalOpen && selectedMember && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center px-4 animate-fade-in">
                    <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => !isSaving && setPermissionsModalOpen(false)}></div>
                    <div className="bg-white dark:bg-dark-card w-full max-w-sm rounded-3xl shadow-2xl relative z-10 overflow-hidden animate-zoom-in border border-slate-200 dark:border-dark-border">
                        <div className="bg-orange-500 p-6 text-center text-white relative">
                            <button onClick={() => !isSaving && setPermissionsModalOpen(false)} className="absolute top-4 left-4 p-1 bg-white/20 hover:bg-white/30 rounded-full transition">
                                <i data-lucide="x" className="w-4 h-4"></i>
                            </button>
                            <i data-lucide="sliders" className="w-12 h-12 mx-auto mb-2 opacity-90"></i>
                            <h3 className="text-xl font-bold">صلاحيات المشرف</h3>
                            <p className="text-orange-100 text-sm mt-1">{selectedMember.name}</p>
                        </div>
                        <div className="p-6 space-y-4">
                            <label className={`flex items-center gap-4 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 transition-colors ${isSaving ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
                                <input type="checkbox" checked={tempPerms.manageContent} onChange={e => setTempPerms({...tempPerms, manageContent: e.target.checked})} className="w-5 h-5 accent-indigo-600 rounded" disabled={isSaving} />
                                <div>
                                    <div className="font-bold text-slate-800 dark:text-white text-sm">إدارة المحتوى العلمي</div>
                                    <div className="text-xs text-slate-500 mt-0.5">السماح بإضافة وتعديل الملفات والاختبارات</div>
                                </div>
                            </label>
                            
                            <label className={`flex items-center gap-4 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 transition-colors ${isSaving ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
                                <input type="checkbox" checked={tempPerms.manageForum} onChange={e => setTempPerms({...tempPerms, manageForum: e.target.checked})} className="w-5 h-5 accent-indigo-600 rounded" disabled={isSaving} />
                                <div>
                                    <div className="font-bold text-slate-800 dark:text-white text-sm">إدارة المنتدى</div>
                                    <div className="text-xs text-slate-500 mt-0.5">السماح بحذف المنشورات وتثبيتها للطلاب</div>
                                </div>
                            </label>

                            <button onClick={savePermissions} disabled={isSaving} className={`w-full h-12 mt-2 rounded-xl font-bold text-white transition-all flex items-center justify-center gap-2 shadow-md ${isSaving ? 'bg-slate-400 cursor-wait' : 'bg-slate-900 hover:bg-black dark:bg-indigo-600 dark:hover:bg-indigo-700'}`}>
                                {isSaving ? <div className="spinner w-5 h-5 border-2"></div> : 'حفظ الصلاحيات'}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            <div className="flex items-center gap-3 mb-2">
                <button onClick={onBack} className="w-10 h-10 bg-white dark:bg-dark-card border border-slate-200 dark:border-dark-border rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-50 transition-colors shadow-sm">
                    <i data-lucide="arrow-right" className="w-5 h-5 rtl:-scale-x-100"></i>
                </button>
                <div>
                    <h2 className="text-2xl font-bold text-slate-800 dark:text-white flex items-center gap-2">مجلس الطلاب</h2>
                    <p className="text-slate-500 text-sm mt-1">تواصل مع المشرفين وأعضاء المجلس</p>
                </div>
            </div>

            {loading ? (
                <div className="text-center py-10 text-slate-400">جاري تحميل البيانات...</div>
            ) : members.length === 0 ? (
                <div className="text-center py-16 bg-white dark:bg-dark-card rounded-2xl border border-dashed border-slate-300 dark:border-dark-border">
                    <div className="w-16 h-16 bg-slate-50 dark:bg-dark-bg rounded-full flex items-center justify-center mx-auto mb-4">
                        <i data-lucide="users" className="w-8 h-8 text-slate-400"></i>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300 font-bold">لا يوجد أعضاء في مجلس الطلاب حاليا</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {members.map(member => (
                        <div key={member.id} className="bg-white dark:bg-dark-card p-4 rounded-2xl shadow-sm border border-slate-200 dark:border-dark-border flex items-center justify-between transition-colors hover:border-indigo-200 dark:hover:border-indigo-800">
                            <div className="flex items-center gap-3 cursor-pointer flex-1" onClick={() => setSelectedUserUid(member.id)}>
                                <div className="relative shrink-0">
                                    <div className="w-12 h-12 rounded-full overflow-hidden bg-slate-100 border border-slate-200 flex items-center justify-center">
                                        {member.photo ? <img src={member.photo} className="w-full h-full object-cover" /> : <i data-lucide="user" className="w-6 h-6 text-slate-400"></i>}
                                    </div>
                                    <div className={`absolute bottom-0 left-0 w-3.5 h-3.5 border-2 border-white dark:border-dark-card rounded-full ${member.isOnline ? 'bg-green-500' : 'bg-slate-400'}`}></div>
                                </div>
                                <div className="overflow-hidden pr-2">
                                    <h3 className="font-bold text-sm text-slate-800 dark:text-white flex items-center gap-1">
                                        {member.name}
                                        <i data-lucide="crown" className="w-4 h-4 text-orange-500"></i>
                                    </h3>
                                    <p className="text-xs text-slate-500 mt-0.5">مشرف</p>
                                </div>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                                <button onClick={() => setSelectedUserUid(member.id)} className="w-9 h-9 bg-indigo-50 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400 rounded-lg flex items-center justify-center transition-colors hover:bg-indigo-600 hover:text-white" title="عرض الملف والتواصل">
                                    <i data-lucide="user" className="w-4 h-4"></i>
                                </button>

                                {/* القلم يظهر فقط للمسؤول الأساسي */}
                                {isAdmin && (
                                    <button onClick={() => openPermissionsModal(member)} className="w-9 h-9 bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300 rounded-lg flex items-center justify-center transition-colors hover:bg-slate-200 dark:hover:bg-slate-700" title="تعديل صلاحيات المشرف">
                                        <i data-lucide="edit-3" className="w-4 h-4"></i>
                                    </button>
                                )}
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};
