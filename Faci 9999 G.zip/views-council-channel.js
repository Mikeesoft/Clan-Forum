// --- views-council-channel.js ---
// شاشة قناة تحديثات مجلس الطلاب (تصميم منشن احترافي ومفصولة لسهولة التعديل 🚀)

var { useState, useEffect } = React;

const SafeIcon = window.SafeIcon;
const PostItem = window.PostItem;
const getSafeTime = window.getSafeTime;

window.CouncilChannelView = ({ user, userData, isAdmin, showAlert, onBack, setTab }) => {
    const [posts, setPosts] = useState([]);
    const [newPostContent, setNewPostContent] = useState('');
    const [isPosting, setIsPosting] = useState(false);
    const [loading, setLoading] = useState(true);
    const [allowComments, setAllowComments] = useState(true);
    const [targetPostId, setTargetPostId] = useState(null);
    const [selectedUserUid, setSelectedUserUid] = useState(null);
    const [activeMentions, setActiveMentions] = useState([]);

    const canPost = isAdmin || (userData?.isCouncil === true);

    const MentionTextarea = window.MentionTextarea;

    useEffect(() => {
        const savedPostId = localStorage.getItem('scrollToPost');
        if (savedPostId) {
            setTargetPostId(savedPostId);
            localStorage.removeItem('scrollToPost');
        }

        let unsubPosts = () => {};
        try {
            const q = window.fb.query(window.fb.collection(window.fb.db, "forum_posts"));
            unsubPosts = window.fb.onSnapshot(q, (snapshot) => {
                const fetched = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })).filter(p => p.isCouncilUpdate === true);
                fetched.sort((a, b) => getSafeTime(b.createdAt) - getSafeTime(a.createdAt));
                setPosts(fetched);
                setLoading(false);
            });
        } catch (err) { setLoading(false); }
        return () => unsubPosts();
    }, []);

    useEffect(() => {
        if (!loading && targetPostId && posts.length > 0 && !selectedUserUid) {
            setTimeout(() => {
                const element = document.getElementById(`post-${targetPostId}`);
                if (element) {
                    element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    setTimeout(() => setTargetPostId(null), 3000);
                }
            }, 500);
        }
    }, [loading, targetPostId, posts, selectedUserUid]);

    useEffect(() => {
        let timeoutId = setTimeout(() => { if (window.lucide) window.lucide.createIcons(); }, 50);
        return () => clearTimeout(timeoutId);
    }, [posts, canPost, allowComments, selectedUserUid]);

    const handleCreateAnnouncement = async (e) => {
        if (e) e.preventDefault();
        if (!newPostContent.trim() || isPosting) return;
        setIsPosting(true);
        
        let finalContent = newPostContent.trim();
        activeMentions.forEach(mention => {
            finalContent = finalContent.split(`@${mention.name}`).join(`@[${mention.name}](${mention.id})`);
        });

        try {
            const docRef = await window.fb.addDoc(window.fb.collection(window.fb.db, "forum_posts"), {
                uid: user.uid,
                authorName: userData?.name || 'مجلس الطلاب',
                authorEmail: user.email || '',
                authorPhoto: userData?.photo || '',
                realAuthorName: userData?.name || 'مجلس الطلاب',
                authorIsVerified: userData?.isVerified || false,
                authorIsCouncil: true, 
                isAnonymous: false,
                isCouncilUpdate: true, 
                allowComments: allowComments, 
                content: finalContent,
                likes: [],
                isPinned: false,
                createdAt: Date.now()
            });
            
            await window.fb.addDoc(window.fb.collection(window.fb.db, "news"), {
                title: 'إعلان هام من مجلس الطلاب 📢',
                content: finalContent.substring(0, 70) + (finalContent.length > 70 ? '...' : ''),
                type: 'council', 
                postId: docRef.id, 
                date: new Date().toISOString(),
                author: userData?.name || 'المجلس',
                seenBy: [user.uid] 
            });

            setNewPostContent('');
            setActiveMentions([]);
            setAllowComments(true); 
            showAlert("تم النشر", "تم نشر الإعلان وإرسال إشعار لجميع الطلاب بنجاح.", "success", () => {});
        } catch (error) {
            showAlert("خطأ", "حدث خطأ أثناء النشر.", "danger", () => {});
        } finally { setIsPosting(false); }
    };

    const handleUserClick = (uid) => {
        if (uid === user.uid) {
            if (setTab) setTab('profile'); 
            return;
        }
        setSelectedUserUid(uid);
    };

    if (selectedUserUid) {
        return <window.PublicProfileView currentUser={user} targetUid={selectedUserUid} onBack={() => setSelectedUserUid(null)} showAlert={showAlert} setTab={setTab} />;
    }

    return (
        <div className="space-y-6 animate-fade-in pb-20 max-w-2xl mx-auto">
            <div className="flex items-center gap-3 mb-4 bg-gradient-to-r from-indigo-600 to-blue-600 p-6 rounded-3xl text-white shadow-lg relative overflow-hidden">
                <i data-lucide="radio" className="absolute left-[-20px] bottom-[-20px] w-32 h-32 opacity-10 rotate-12 pointer-events-none"></i>
                <button onClick={onBack} className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-xl flex items-center justify-center transition-colors backdrop-blur-sm z-10 shrink-0">
                    <SafeIcon name="arrow-right" className="w-5 h-5 rtl:-scale-x-100" />
                </button>
                <div className="z-10">
                    <h2 className="text-2xl font-bold flex items-center gap-2">أخبار المجلس <SafeIcon name="megaphone" className="w-5 h-5 text-indigo-200" /></h2>
                    <p className="text-indigo-100 text-sm mt-1 opacity-90">القرارات والتحديثات الرسمية للطلاب</p>
                </div>
            </div>

            {canPost && (
                <div className="bg-indigo-50 dark:bg-indigo-900/10 p-5 rounded-2xl shadow-sm border border-indigo-100 dark:border-indigo-900/50 mb-6 relative">
                    <div className="flex items-center gap-2 mb-3 text-indigo-700 dark:text-indigo-400 font-bold text-sm">
                        <SafeIcon name="edit" className="w-4 h-4" /> كتابة إعلان رسمي جديد
                    </div>
                    
                    <div className="flex gap-2">
                        <MentionTextarea 
                            user={user}
                            userData={userData}
                            value={newPostContent} 
                            onChange={setNewPostContent}
                            onMentionAdd={(mention) => setActiveMentions(prev => [...prev, mention])}
                            placeholder="اكتب الإعلان هنا (اكتب @ للإشارة لشخص)..."
                            disabled={isPosting}
                            className="min-h-[90px] w-full resize-none bg-white dark:bg-dark-card border border-indigo-200 dark:border-indigo-800 rounded-xl p-4 text-[14px] text-slate-800 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 transition-all shadow-inner"
                        />
                    </div>
                    
                    <div className="flex justify-between items-center pt-3 mt-2 border-t border-indigo-100 dark:border-indigo-800/50">
                        <button 
                            type="button" 
                            onClick={() => setAllowComments(!allowComments)} 
                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${allowComments ? 'bg-white border-indigo-200 text-indigo-600 dark:bg-dark-card' : 'bg-red-50 border-red-200 text-red-600 dark:bg-red-900/20 dark:border-red-900/50'}`}
                        >
                            <SafeIcon name={allowComments ? "unlock" : "lock"} className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline">{allowComments ? 'التعليقات: مسموحة' : 'التعليقات: مغلقة'}</span>
                        </button>

                        <button type="button" onClick={handleCreateAnnouncement} disabled={!newPostContent.trim() || isPosting} className={`px-6 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center gap-2 shadow-md ${newPostContent.trim() ? 'bg-indigo-600 text-white hover:bg-indigo-700 hover:scale-105' : 'bg-slate-200 text-slate-400 dark:bg-slate-800 dark:text-slate-600 cursor-not-allowed'}`}>
                            {isPosting ? <><div className="spinner w-4 h-4 border-2"></div> جاري النشر...</> : <><SafeIcon name="send" className="w-4 h-4 rtl:-scale-x-100" /> نشر وإشعار</>}
                        </button>
                    </div>
                </div>
            )}

            <div className="space-y-4">
                {loading ? (
                    <div className="text-center py-12 flex flex-col items-center gap-4"><div className="spinner w-10 h-10 border-4 border-indigo-500"></div></div>
                ) : posts.length === 0 ? (
                    <div className="text-center py-16 bg-white dark:bg-dark-card rounded-2xl border border-dashed border-slate-300 dark:border-dark-border">
                        <div className="w-20 h-20 bg-indigo-50 dark:bg-indigo-900/20 rounded-full flex items-center justify-center mx-auto mb-4"><SafeIcon name="radio" className="w-10 h-10 text-indigo-300" /></div>
                        <p className="text-slate-600 dark:text-dark-muted font-bold text-lg">لا توجد إعلانات حالياً</p>
                    </div>
                ) : (
                    posts.map(post => (
                        <PostItem key={post.id} post={post} currentUser={user} userData={userData} isAdmin={isAdmin} showAlert={showAlert} isHighlighted={post.id === targetPostId} onUserClick={handleUserClick} />
                    ))
                )}
            </div>
        </div>
    );
};
