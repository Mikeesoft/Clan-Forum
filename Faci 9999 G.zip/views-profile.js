// --- views-profile.js ---
// ملف الصفحة الشخصية (تم استرجاع بادج مجلس الطلاب 👑 وإضافته لقائمة الشات)

var { useState, useEffect, useMemo } = React;
var ADMIN_EMAIL = "mohammadsafe202a@gmail.com";

window.ProfileView = ({ user, setTab, showAlert }) => {
    const [profile, setProfile] = useState({ name: user.displayName || '', uniId: '', photo: '', balance: 0, isOnline: true });
    const [privateData, setPrivateData] = useState({ balance: 0, isBanned: false, isVerified: false, isCouncil: false, role: 'student' });
    
    const [selectedFile, setSelectedFile] = useState(null); 
    const [previewUrl, setPreviewUrl] = useState(null); 
    const [stats, setStats] = useState({ taskPercent: 0, attendancePercent: 100, gpa: '0.00' });
    const [isSaving, setIsSaving] = useState(false);
    const [loadingData, setLoadingData] = useState(true);
    
    const [activeSection, setActiveSection] = useState('info'); 
    const [activeChatFriend, setActiveChatFriend] = useState(null);
    const [isPreviewPublic, setIsPreviewPublic] = useState(false);
    
    const [friendsList, setFriendsList] = useState([]);
    const [loadingFriends, setLoadingFriends] = useState(true);
    
    const isAdmin = user.email === ADMIN_EMAIL; 
    const gradePoints = { 'A+': 4.0, 'A': 3.75, 'B+': 3.5, 'B': 3.0, 'C+': 2.5, 'C': 2.0, 'D+': 1.5, 'D': 1.0, 'F': 0 };

    useEffect(() => {
        let unsubUserPublic = () => {};
        let unsubUserPrivate = () => {};
        let unsubTasks = () => {};
        let unsubCourses = () => {};

        const fetchData = () => {
            try {
                const userPublicRef = window.fb.doc(window.fb.db, "users", user.uid);
                unsubUserPublic = window.fb.onSnapshot(userPublicRef, (docSnap) => {
                    if (docSnap.exists()) { 
                        const data = docSnap.data();
                        setProfile(prev => ({ ...prev, ...data })); 
                        if (!data.email && user.email === ADMIN_EMAIL) {
                            window.fb.setDoc(userPublicRef, { email: user.email }, { merge: true }).catch(()=>{});
                        }
                    }
                });

                const userPrivateRef = window.fb.doc(window.fb.db, "users_private", user.uid);
                unsubUserPrivate = window.fb.onSnapshot(userPrivateRef, async (docSnap) => {
                    if (docSnap.exists()) {
                        const pData = docSnap.data();
                        setPrivateData({ ...pData, role: pData.role || 'student' });
                        setProfile(prev => ({ ...prev, balance: pData.balance || 0, isVerified: pData.isVerified || false, isCouncil: pData.isCouncil || false }));
                    } else {
                        const pubDoc = await window.fb.getDoc(window.fb.doc(window.fb.db, "users", user.uid));
                        const oldData = pubDoc.exists() ? pubDoc.data() : {};
                        await window.fb.setDoc(userPrivateRef, {
                            email: user.email, balance: oldData.balance || 0, role: 'student', isVerified: oldData.isVerified || false,
                            isCouncil: oldData.isCouncil || false, isBanned: oldData.isBanned || false, migrated: true, createdAt: Date.now()
                        }, { merge: true }).catch(()=>{});
                    }
                });

                const tasksQuery = window.fb.query(window.fb.collection(window.fb.db, "tasks"), window.fb.where("uid", "==", user.uid));
                const coursesQuery = window.fb.query(window.fb.collection(window.fb.db, "courses"), window.fb.where("uid", "==", user.uid));

                unsubTasks = window.fb.onSnapshot(tasksQuery, (s) => {
                    const allTasks = s.docs.map(d => d.data());
                    const completed = allTasks.filter(t => t.completed).length;
                    const percent = allTasks.length === 0 ? 0 : Math.round((completed / allTasks.length) * 100);
                    setStats(prev => ({ ...prev, taskPercent: percent }));
                });

                unsubCourses = window.fb.onSnapshot(coursesQuery, (s) => {
                    const allCourses = s.docs.map(d => d.data());
                    let tP=0, tC=0; let totalAbsences = 0, totalMaxAbsences = 0;
                    allCourses.forEach(c => { 
                        if(c.grade && gradePoints[c.grade] !== undefined) { const cr = parseFloat(c.credits||0); tP+=gradePoints[c.grade]*cr; tC+=cr; }
                        totalAbsences += (c.absences || 0); totalMaxAbsences += (c.maxAbsence || 4);
                    });
                    const gpaCalc = tC === 0 ? "0.00" : (tP/tC).toFixed(2);
                    const attPercent = totalMaxAbsences === 0 ? 100 : Math.max(0, Math.round(((totalMaxAbsences - totalAbsences) / totalMaxAbsences) * 100));
                    setStats(prev => ({ ...prev, gpa: gpaCalc, attendancePercent: attPercent }));
                    setLoadingData(false);
                });
            } catch (err) { setLoadingData(false); }
        };
        fetchData();
        return () => { unsubUserPublic(); unsubUserPrivate(); unsubTasks(); unsubCourses(); };
    }, [user.uid, user.email]);

    useEffect(() => {
        const q = window.fb.query(window.fb.collection(window.fb.db, "friendships"), window.fb.where("users", "array-contains", user.uid), window.fb.where("status", "==", "accepted"));
        const unsubFriends = window.fb.onSnapshot(q, async (snapshot) => {
            try {
                const fetchPromises = snapshot.docs.map(async (d) => {
                    const data = d.data();
                    const safeUsersArray = data.users || [];
                    const friendId = safeUsersArray.find(id => id !== user.uid);
                    if (friendId) {
                        const userDoc = await window.fb.getDoc(window.fb.doc(window.fb.db, "users", friendId));
                        if (userDoc.exists()) {
                            const hasUnread = data.lastMessage && data.lastMessage.senderId !== user.uid && data.lastMessage.seen === false;
                            return { id: friendId, friendshipId: d.id, hasUnread: hasUnread, ...userDoc.data() };
                        }
                    }
                    return null;
                });

                const results = await Promise.all(fetchPromises);
                const fData = results.filter(item => item !== null);
                
                const uniqueFriendsMap = new Map();
                fData.forEach(f => { if (!uniqueFriendsMap.has(f.id) || f.hasUnread) { uniqueFriendsMap.set(f.id, f); } });
                const uniqueFriends = Array.from(uniqueFriendsMap.values());
                
                uniqueFriends.sort((a, b) => {
                    if (a.hasUnread && !b.hasUnread) return -1;
                    if (!a.hasUnread && b.hasUnread) return 1;
                    if (a.isOnline === b.isOnline) return 0;
                    return a.isOnline ? -1 : 1;
                });
                setFriendsList(uniqueFriends);
            } catch (error) { console.error(error); } finally { setLoadingFriends(false); }
        });
        return () => unsubFriends();
    }, [user.uid]);

    useEffect(() => {
        if (friendsList.length > 0) {
            const openUid = localStorage.getItem('openChatWithUid');
            const directUid = localStorage.getItem('directChatUid'); 
            const targetUidToOpen = openUid || directUid;
            if (targetUidToOpen) {
                const targetFriend = friendsList.find(f => f.id === targetUidToOpen);
                if (targetFriend) {
                    setActiveChatFriend(targetFriend);
                    setActiveSection('chat');
                    localStorage.removeItem('openChatWithUid');
                    localStorage.removeItem('directChatUid');
                }
            }
        }
    }, [friendsList]);

    useEffect(() => { 
        let timer = setTimeout(() => { if(window.lucide) window.lucide.createIcons(); }, 50); 
        return () => clearTimeout(timer);
    }, [activeSection, isPreviewPublic, loadingData, selectedFile, isSaving, friendsList, activeChatFriend, profile.isOnline, privateData.role, profile.isCouncil, profile.isVerified]);

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            if (!file.type.startsWith('image/')) { showAlert("خطأ", "يرجى اختيار صورة.", "danger", ()=>{}); e.target.value = ""; return; }
            setSelectedFile(file);
            if (previewUrl) URL.revokeObjectURL(previewUrl); 
            setPreviewUrl(URL.createObjectURL(file)); 
        }
    };

    const processImage = (file) => {
        return new Promise((resolve, reject) => {
            const img = new Image(); const objUrl = URL.createObjectURL(file); 
            img.onload = () => {
                const canvas = document.createElement('canvas'); const MAX_SIZE = 150; 
                let width = img.width; let height = img.height;
                if (width > height) { if (width > MAX_SIZE) { height *= MAX_SIZE / width; width = MAX_SIZE; } } else { if (height > MAX_SIZE) { width *= MAX_SIZE / height; height = MAX_SIZE; } }
                canvas.width = width; canvas.height = height; const ctx = canvas.getContext('2d'); ctx.drawImage(img, 0, 0, width, height);
                const base64 = canvas.toDataURL('image/jpeg', 0.5); URL.revokeObjectURL(objUrl); resolve(base64);
            };
            img.onerror = () => { URL.revokeObjectURL(objUrl); reject("خطأ قراءة."); }; img.src = objUrl;
        });
    };

    const handleSave = async (e) => {
        e.preventDefault(); setIsSaving(true);
        await new Promise(resolve => setTimeout(resolve, 100)); 
        try {
            let finalPhoto = profile.photo;
            if (selectedFile) { finalPhoto = await processImage(selectedFile); }
            const userRef = window.fb.doc(window.fb.db, "users", user.uid);
            const cleanPayload = { name: profile.name || '', uniId: profile.uniId || '', photo: finalPhoto || '', updatedAt: Date.now() };
            await window.fb.setDoc(userRef, cleanPayload, { merge: true });
            setProfile(prev => ({ ...prev, name: cleanPayload.name, uniId: cleanPayload.uniId, photo: finalPhoto }));
            setActiveSection('info'); setSelectedFile(null);
            if (previewUrl) URL.revokeObjectURL(previewUrl); setPreviewUrl(null);
            showAlert("تم بنجاح", "تم الحفظ بنجاح.", "success", ()=>{});
        } catch (error) { showAlert("عذراً", "خطأ في الحفظ.", "danger", ()=>{}); } 
        finally { setIsSaving(false); }
    };

    const handleMobileLogout = () => {
        showAlert("تسجيل الخروج", "هل تود تسجيل الخروج من حسابك؟", "danger", async () => {
            try { await window.fb.updateDoc(window.fb.doc(window.fb.db, "users", user.uid), { isOnline: false }); window.fb.signOut(window.fb.auth); } catch(e) { window.fb.signOut(window.fb.auth); }
        });
    };

    const toggleOnlineStatus = async () => {
        try {
            const newStatus = !profile.isOnline;
            localStorage.setItem('ghostMode', newStatus ? 'false' : 'true');
            await window.fb.updateDoc(window.fb.doc(window.fb.db, "users", user.uid), { isOnline: newStatus });
        } catch(e) {}
    };

    const handleRecharge = () => {
        if (isAdmin) {
            showAlert("مرحباً بك", "أنت المسؤول عن النظام، يمكنك تعديل الأرصدة للطلاب من لوحة الإدارة السريّة.", "info", ()=>{});
            return;
        }
        const q = window.fb.query(window.fb.collection(window.fb.db, "users"), window.fb.where("email", "==", ADMIN_EMAIL));
        const unsub = window.fb.onSnapshot(q, async (snap) => {
            unsub(); 
            if (!snap.empty) {
                const adminDoc = snap.docs[0];
                const adminId = adminDoc.id;
                const fId = user.uid < adminId ? `${user.uid}_${adminId}` : `${adminId}_${user.uid}`;
                try {
                    await window.fb.setDoc(window.fb.doc(window.fb.db, "friendships", fId), {
                        users: [user.uid, adminId], status: 'accepted', updatedAt: Date.now()
                    }, { merge: true });
                    setActiveChatFriend({ id: adminId, friendshipId: fId, ...adminDoc.data() });
                    setActiveSection('chat');
                } catch(e) { showAlert("خطأ", "حدث مشكلة أثناء فتح المحادثة.", "danger", ()=>{}); }
            } else { showAlert("تنبيه", "عذراً، حساب الإدارة غير متوفر حالياً.", "danger", ()=>{}); }
        });
    };

    if (loadingData) return <div className="text-center py-10 text-slate-400">جاري التحميل...</div>;

    if (isPreviewPublic) {
        return (
            <div className="animate-fade-in relative">
                <div className="bg-indigo-100 dark:bg-indigo-900/30 border border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-400 p-3 rounded-2xl mb-4 flex justify-between items-center shadow-sm">
                    <div className="flex items-center gap-2 text-sm font-bold"><i data-lucide="eye" className="w-5 h-5"></i> المعاينة العامة</div>
                    <button onClick={() => setIsPreviewPublic(false)} className="bg-white dark:bg-dark-card px-3 py-1.5 rounded-lg text-xs font-bold hover:shadow-md transition">العودة للوحة التحكم</button>
                </div>
                <window.PublicProfileView currentUser={user} targetUid={user.uid} onBack={() => setIsPreviewPublic(false)} showAlert={showAlert} setTab={setTab} />
            </div>
        );
    }

    const hasAnyUnreadMessage = friendsList.some(f => f.hasUnread);

    return (
        <div className="max-w-md mx-auto space-y-6 animate-fade-in pb-10 mt-2">
            
            <div className="bg-white dark:bg-dark-card p-4 rounded-2xl shadow-sm border border-slate-200 dark:border-dark-border flex justify-between items-center">
                {isAdmin ? (
                    <button onClick={() => { if(setTab) setTab('admin'); }} className="w-11 h-11 rounded-xl bg-slate-900 dark:bg-slate-800 text-white hover:bg-black flex items-center justify-center transition-colors shadow-sm shrink-0" title="لوحة الإدارة السريّة">
                        <i data-lucide="shield" className="w-5 h-5"></i>
                    </button>
                ) : (
                    <button onClick={handleRecharge} className="w-11 h-11 rounded-xl bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 flex items-center justify-center transition-colors shadow-sm shrink-0" title="شحن الرصيد / مراسلة الإدارة">
                        <i data-lucide="plus" className="w-5 h-5"></i>
                    </button>
                )}

                <div className="flex items-center gap-3">
                    <div className="text-left">
                        <p className="text-[10px] text-slate-400 font-bold mb-0.5">الرصيد</p>
                        <p className="text-xl font-bold text-slate-800 dark:text-white font-mono leading-none">{privateData.balance || 0}</p>
                    </div>
                    <div className="w-11 h-11 rounded-full bg-amber-50 dark:bg-amber-900/20 text-amber-500 flex items-center justify-center shrink-0">
                        <i data-lucide="wallet" className="w-5 h-5"></i>
                    </div>
                </div>
            </div>

            <div className="bg-white dark:bg-dark-card p-6 rounded-3xl shadow-sm border border-slate-200 dark:border-dark-border relative overflow-hidden transition-all min-h-[350px]">
                
                {activeSection === 'info' && (
                    <>
                        <div className="absolute top-4 left-4 flex items-center gap-2 z-10">
                            <button onClick={handleMobileLogout} className="p-2 bg-red-50 hover:bg-red-100 dark:bg-red-900/20 text-red-500 hover:text-red-600 rounded-full transition md:hidden" title="تسجيل الخروج"><i data-lucide="log-out" className="w-5 h-5"></i></button>
                            <button onClick={() => setActiveSection('edit')} className="p-2 bg-slate-50 hover:bg-indigo-50 dark:bg-dark-bg text-slate-400 hover:text-indigo-600 rounded-full transition" title="تعديل البيانات"><i data-lucide="edit-3" className="w-5 h-5"></i></button>
                        </div>

                        <div className="absolute top-4 right-4 flex items-center gap-2 z-10">
                            <button onClick={() => setIsPreviewPublic(true)} className="relative p-2 bg-purple-50 hover:bg-purple-100 dark:bg-purple-900/20 text-purple-600 hover:text-purple-700 rounded-full transition" title="تبديل للحساب العام">
                                <i data-lucide="repeat" className="w-5 h-5"></i>
                            </button>
                            <button onClick={() => setActiveSection('friends')} className="relative p-2 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-900/20 text-emerald-600 hover:text-emerald-700 rounded-full transition" title="أصدقائي">
                                <i data-lucide="users" className="w-5 h-5"></i>
                                {hasAnyUnreadMessage && <span className="absolute top-0 right-0 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white dark:border-dark-card animate-pulse"></span>}
                            </button>
                        </div>
                    </>
                )}

                {activeSection === 'info' && (
                    <div className="animate-fade-in space-y-6 pt-2">
                        <div className="flex flex-col items-center">
                            <div key={profile.photo ? 'has-img' : 'no-img'} className="w-24 h-24 rounded-full border-4 border-indigo-50 dark:border-indigo-900/30 overflow-hidden bg-slate-100 dark:bg-dark-bg flex items-center justify-center shadow-md mb-3 relative">
                                {profile.photo ? <img src={profile.photo} alt="Profile" className="w-full h-full object-cover" /> : <i data-lucide="user" className="w-10 h-10 text-slate-400"></i>}
                            </div>
                            
                            {/* 🌟 إرجاع بادج مجلس الطلاب (التاج) جنب التوثيق 🌟 */}
                            <h3 className="font-bold text-xl text-slate-800 dark:text-white mb-1 flex items-center justify-center gap-1.5">
                                {profile.name || 'مجهول'}
                                <span style={{ display: (isAdmin || profile.isVerified) ? 'inline-flex' : 'none' }} title="حساب موثق">
                                    <i data-lucide="badge-check" className="w-5 h-5 text-blue-500"></i>
                                </span>
                                <span style={{ display: (isAdmin || profile.isCouncil) ? 'inline-flex' : 'none' }} title="مجلس الطلاب">
                                    <i data-lucide="crown" className="w-5 h-5 text-orange-500"></i>
                                </span>
                            </h3>

                            <div className="flex gap-2 items-center mt-1">
                                {isAdmin ? (
                                    <span className="text-xs font-bold text-amber-600 bg-amber-50 dark:bg-amber-900/20 dark:text-amber-400 px-3 py-1.5 rounded-full flex items-center gap-1.5 border border-amber-100 dark:border-amber-800/50 shadow-sm">
                                        <i data-lucide="crown" className="w-3.5 h-3.5"></i> المشرف العام
                                    </span>
                                ) : privateData.role === 'doctor' ? (
                                    <span className="text-xs font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 dark:text-emerald-400 px-3 py-1.5 rounded-full flex items-center gap-1.5 border border-emerald-100 dark:border-emerald-800/50 shadow-sm">
                                        <i data-lucide="briefcase" className="w-3.5 h-3.5"></i> عضو هيئة تدريس
                                    </span>
                                ) : (
                                    <span className="text-xs font-mono text-indigo-600 dark:text-indigo-400 font-bold bg-indigo-50 dark:bg-indigo-900/20 px-3 py-1 rounded-full">
                                        ID: {profile.uniId || '---'}
                                    </span>
                                )}
                            </div>
                            <p className="text-[11px] text-slate-400 font-mono mt-2">{user.email}</p>
                        </div>
                        
                        {privateData.role !== 'doctor' && !isAdmin && (
                            <div className="grid grid-cols-3 gap-3 py-4 border-y border-slate-100 dark:border-dark-border animate-fade-in">
                                <div className="text-center"><div className="text-[10px] text-slate-500 mb-1 font-bold uppercase">المهام</div><div className="text-lg font-bold text-emerald-600 dark:text-emerald-400 font-mono">{stats.taskPercent}%</div></div>
                                <div className="text-center border-x border-slate-100 dark:border-dark-border"><div className="text-[10px] text-slate-500 mb-1 font-bold uppercase">الحضور</div><div className="text-lg font-bold text-blue-600 dark:text-blue-400 font-mono">{stats.attendancePercent}%</div></div>
                                <div className="text-center"><div className="text-[10px] text-slate-500 mb-1 font-bold uppercase">المعدل</div><div className="text-lg font-bold text-purple-600 dark:text-purple-400 font-mono">{stats.gpa}</div></div>
                            </div>
                        )}
                        
                        {(privateData.role === 'doctor' || isAdmin) && (
                            <div className="py-4 border-y border-slate-100 dark:border-dark-border text-center animate-fade-in">
                                <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-2 ${isAdmin ? 'bg-amber-50 text-amber-500 dark:bg-amber-900/20' : 'bg-emerald-50 text-emerald-500 dark:bg-emerald-900/20'}`}>
                                    <i data-lucide={isAdmin ? "shield-check" : "book-open"} className="w-6 h-6"></i>
                                </div>
                                <p className="text-sm font-bold text-slate-700 dark:text-slate-300">أهلاً بك في منصة جامعتي</p>
                                <p className="text-xs text-slate-500 dark:text-dark-muted mt-1">{isAdmin ? "أنت المشرف العام للنظام." : "يمكنك الآن إدارة المحتوى العلمي والتواصل مع طلابك."}</p>
                            </div>
                        )}
                    </div>
                )}

                {activeSection === 'edit' && (
                    <form onSubmit={handleSave} className="space-y-6 animate-zoom-in">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="font-bold text-lg text-slate-800 dark:text-white flex items-center gap-2"><i data-lucide="edit-3" className="w-5 h-5 text-indigo-500"></i> تعديل هويتي</h3>
                            <button type="button" onClick={() => setActiveSection('info')} className="text-slate-400 hover:text-slate-600 transition"><i data-lucide="x" className="w-5 h-5"></i></button>
                        </div>
                        <div className="flex flex-col items-center gap-4">
                            <div className="relative group cursor-pointer">
                                <div key={previewUrl ? 'preview' : profile.photo ? 'photo' : 'empty'} className="w-24 h-24 rounded-full border-4 border-indigo-100 dark:border-indigo-900/50 overflow-hidden bg-slate-100 dark:bg-dark-bg flex items-center justify-center relative">
                                    {(previewUrl || profile.photo) ? <img src={previewUrl || profile.photo} alt="Profile" className="w-full h-full object-cover opacity-60" /> : <i data-lucide="user" className="w-10 h-10 text-slate-400"></i>}
                                    <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center transition-opacity"><i data-lucide="camera" className="w-6 h-6 text-white"></i></div>
                                </div>
                                <input type="file" accept="image/*" onChange={handleFileChange} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" title="تغيير الصورة" disabled={isSaving} />
                            </div>
                        </div>
                        <div className="space-y-4">
                            <div><label className="block text-xs font-bold mb-1.5">الاسم بالكامل</label><input type="text" value={profile.name} onChange={e => setProfile({...profile, name: e.target.value})} required className="w-full h-12 px-4 rounded-xl border dark:bg-dark-bg dark:border-dark-border dark:text-white outline-none focus:ring-2 focus:ring-indigo-500" disabled={isSaving} /></div>
                            
                            {privateData.role !== 'doctor' && !isAdmin && (
                                <div><label className="block text-xs font-bold mb-1.5">الكود الجامعي</label><input type="text" value={profile.uniId} onChange={e => setProfile({...profile, uniId: e.target.value.replace(/[^0-9]/g, '')})} className="w-full h-12 px-4 rounded-xl border dark:bg-dark-bg dark:border-dark-border dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 font-mono" disabled={isSaving} /></div>
                            )}
                        </div>
                        <div className="pt-2">
                            <button disabled={isSaving} type="submit" className={`w-full h-12 font-bold rounded-xl flex justify-center items-center gap-2 transition-all ${isSaving ? 'bg-indigo-400 text-indigo-100' : 'bg-indigo-600 text-white hover:bg-indigo-700'}`}>
                                {isSaving ? <><div className="spinner w-4 h-4 border-2 border-white"></div> جاري الحفظ...</> : 'حفظ البيانات'}
                            </button>
                        </div>
                    </form>
                )}

                {activeSection === 'friends' && (
                    <div className="animate-fade-in flex flex-col h-[450px]">
                        <div className="flex justify-between items-center mb-4 pb-3 border-b border-slate-100 dark:border-dark-border shrink-0">
                            <h3 className="font-bold text-lg text-slate-800 dark:text-white flex items-center gap-2">
                                <i data-lucide="users" className="w-5 h-5 text-emerald-500"></i> جهات الاتصال
                            </h3>
                            
                            <div className="flex items-center gap-2">
                                <button onClick={toggleOnlineStatus} className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${profile.isOnline ? 'bg-green-50 text-green-600 hover:bg-green-100 dark:bg-green-900/20 dark:text-green-400' : 'bg-slate-100 text-slate-500 hover:bg-slate-200 dark:bg-dark-bg'}`} title={profile.isOnline ? 'أنت متصل (اضغط للتخفي)' : 'أنت مخفي (اضغط للاتصال)'}>
                                    <i data-lucide={profile.isOnline ? "eye" : "eye-off"} className="w-4 h-4"></i>
                                </button>
                                <button onClick={() => setActiveSection('info')} className="w-8 h-8 bg-slate-50 dark:bg-dark-bg text-slate-400 hover:text-red-500 rounded-full flex items-center justify-center transition-colors" title="رجوع">
                                    <i data-lucide="arrow-right" className="w-4 h-4 rtl:-scale-x-100"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div className="flex-1 overflow-y-auto custom-scrollbar space-y-3 pr-1">
                            {loadingFriends ? (
                                <div className="text-center py-6"><div className="spinner w-6 h-6 border-2 border-indigo-500 mx-auto"></div></div>
                            ) : friendsList.length === 0 ? (
                                <div className="text-center py-10">
                                    <i data-lucide="user-minus" className="w-12 h-12 text-slate-300 mx-auto mb-3"></i>
                                    <p className="text-slate-500 font-bold text-sm">ليس لديك جهات اتصال بعد.</p>
                                </div>
                            ) : (
                                friendsList.map(friend => (
                                    <div key={friend.id} className="flex items-center justify-between bg-slate-50 dark:bg-dark-bg p-3 rounded-2xl border border-slate-100 dark:border-slate-700 transition hover:border-indigo-200 dark:hover:border-indigo-800">
                                        <div className="flex items-center gap-3">
                                            <div className="relative shrink-0">
                                                <div className="w-12 h-12 rounded-full overflow-hidden bg-slate-200 border border-slate-300 flex items-center justify-center">
                                                    {friend.photo ? <img src={friend.photo} className="w-full h-full object-cover" /> : <i data-lucide="user" className="w-6 h-6 text-slate-400"></i>}
                                                </div>
                                                <div className={`absolute bottom-0 right-0 w-3.5 h-3.5 border-2 border-white dark:border-dark-card rounded-full ${friend.isOnline ? 'bg-green-500' : 'bg-slate-400'}`}></div>
                                            </div>
                                            <div>
                                                {/* 🌟 إظهار التوثيق ومجلس الطلاب بجانب اسم الصديق في قائمة الشات 🌟 */}
                                                <h4 className="font-bold text-sm text-slate-800 dark:text-white line-clamp-1 flex items-center gap-1">
                                                    {friend.name}
                                                    {friend.isVerified && <i data-lucide="badge-check" className="w-3.5 h-3.5 text-blue-500" title="موثق"></i>}
                                                    {friend.isCouncil && <i data-lucide="crown" className="w-3.5 h-3.5 text-orange-500" title="مجلس الطلاب"></i>}
                                                    <span style={{ display: friend.hasUnread ? 'inline-block' : 'none' }} className="ml-1 text-[10px] bg-red-100 text-red-600 px-1.5 py-0.5 rounded font-bold">رسالة</span>
                                                </h4>
                                                <p className={`text-xs font-bold mt-0.5 ${friend.isOnline ? 'text-green-500' : 'text-slate-400'}`}>{friend.isOnline ? 'متصل الآن' : 'غير متصل'}</p>
                                            </div>
                                        </div>
                                        
                                        <button 
                                            onClick={() => { setActiveChatFriend(friend); setActiveSection('chat'); }}
                                            className={`w-10 h-10 shrink-0 rounded-xl flex items-center justify-center transition-colors shadow-sm relative ${friend.hasUnread ? 'bg-indigo-600 text-white animate-pulse' : 'bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white dark:bg-indigo-900/30 dark:text-indigo-400 dark:hover:bg-indigo-600 dark:hover:text-white'}`}
                                            title="مراسلة"
                                        >
                                            <i data-lucide="message-circle" className="w-5 h-5"></i>
                                            {friend.hasUnread && <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 border-2 border-white rounded-full"></span>}
                                        </button>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                )}

                {activeSection === 'chat' && window.ProfileChat && (
                    <window.ProfileChat 
                        currentUser={user} 
                        activeChat={activeChatFriend} 
                        onBack={() => setActiveSection('friends')} 
                        showAlert={showAlert} 
                    />
                )}
            </div>
        </div>
    );
};
