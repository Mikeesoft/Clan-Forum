// --- forum-components.js ---
// المكونات الأساسية للمنتدى (تم إصلاح نظام التوجيه في المنشن 🔗✨)

var { useState, useEffect, useRef } = React;
var ADMIN_EMAIL = "mohammadsafe202a@gmail.com";

window.SafeIcon = ({ name, className }) => {
    const iconRef = useRef(null);
    useEffect(() => {
        if (iconRef.current && window.lucide) {
            iconRef.current.innerHTML = `<i data-lucide="${name}" class="${className || ''}"></i>`;
            window.lucide.createIcons({ root: iconRef.current });
        }
    }, [name, className]);

    return <span ref={iconRef} style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}></span>;
};

window.getSafeTime = (val) => {
    try {
        if (!val) return 0;
        if (typeof val === 'number') return val; 
        if (val.seconds) return val.seconds * 1000; 
        return Date.parse(val) || 0; 
    } catch (e) { return 0; }
};

window.PostItem = ({ post, currentUser, userData, isAdmin, showAlert, isHighlighted, onUserClick }) => {
    const [comments, setComments] = useState([]);
    const [newComment, setNewComment] = useState('');
    const [showComments, setShowComments] = useState(false);
    const [isLiking, setIsLiking] = useState(false);
    const [isCommenting, setIsCommenting] = useState(false);
    
    const [isCommentAnonymous, setIsCommentAnonymous] = useState(false);
    const [revealPost, setRevealPost] = useState(false);
    const [revealedComments, setRevealedComments] = useState({}); 

    const [isEditingPost, setIsEditingPost] = useState(false);
    const [editedContent, setEditedContent] = useState('');
    const [isSavingEdit, setIsSavingEdit] = useState(false);

    const [replyingToId, setReplyingToId] = useState(null); 
    const [replyingToName, setReplyingToName] = useState('');
    const [replyingToUid, setReplyingToUid] = useState(null); 

    const [showAllComments, setShowAllComments] = useState(false);

    const SafeIcon = window.SafeIcon;

    const isCouncilManager = userData?.isCouncil && userData?.councilPermissions?.manageForum;
    const hasLiked = post.likes && Array.isArray(post.likes) && post.likes.includes(currentUser.uid);

    // هل التعليقات مسموحة؟
    const isCommentsAllowed = post.allowComments !== false;

    useEffect(() => {
        let unsub = () => {};
        if (showComments || isHighlighted) {
            if (isHighlighted) setShowComments(true); 
            const q = window.fb.query(window.fb.collection(window.fb.db, "forum_comments"), window.fb.where("postId", "==", post.id));
            unsub = window.fb.onSnapshot(q, (snapshot) => {
                const fetched = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                fetched.sort((a, b) => window.getSafeTime(a.createdAt) - window.getSafeTime(b.createdAt));
                setComments(fetched);
            });
        }
        return () => unsub();
    }, [showComments, isHighlighted, post.id]);

    const handleLike = async (e) => {
        e.preventDefault();
        if (isLiking) return;
        setIsLiking(true);
        const postRef = window.fb.doc(window.fb.db, "forum_posts", post.id);
        try {
            const currentLikes = Array.isArray(post.likes) ? post.likes : [];
            if (hasLiked) {
                await window.fb.updateDoc(postRef, { likes: currentLikes.filter(id => id !== currentUser.uid) });
            } else {
                await window.fb.updateDoc(postRef, { likes: [...currentLikes, currentUser.uid] });
                
                if (post.uid !== currentUser.uid) {
                    await window.fb.addDoc(window.fb.collection(window.fb.db, "interactions"), {
                        recipientUid: post.uid, 
                        senderUid: currentUser.uid, 
                        senderName: userData?.name || 'طالب', 
                        senderPhoto: userData?.photo || '',
                        type: 'like', 
                        postId: post.id, 
                        postSnippet: post.content.substring(0, 40) + '...', 
                        createdAt: Date.now(), 
                        seen: false
                    });
                }
            }
        } catch (e) {} finally { setIsLiking(false); }
    };

    const handleAddComment = async (e) => {
        if (e) e.preventDefault();
        if (!newComment.trim() || isCommenting || !isCommentsAllowed) return; 
        
        setIsCommenting(true);
        const commentTextToSave = newComment.trim();

        try {
            await window.fb.addDoc(window.fb.collection(window.fb.db, "forum_comments"), {
                postId: post.id, 
                parentId: replyingToId, 
                uid: currentUser.uid, 
                authorName: isCommentAnonymous ? 'مجهول' : (userData?.name || 'طالب'),
                authorPhoto: isCommentAnonymous ? '' : (userData?.photo || ''), 
                realAuthorName: userData?.name || 'طالب', 
                authorIsVerified: userData?.isVerified || false,
                authorIsCouncil: userData?.isCouncil || false,
                authorEmail: currentUser.email || '',
                isAnonymous: isCommentAnonymous, 
                content: commentTextToSave, 
                likes: [],
                createdAt: Date.now()
            });

            if (replyingToId && replyingToUid && replyingToUid !== currentUser.uid) {
                await window.fb.addDoc(window.fb.collection(window.fb.db, "interactions"), {
                    recipientUid: replyingToUid, 
                    senderUid: currentUser.uid, 
                    senderName: isCommentAnonymous ? 'مجهول' : (userData?.name || 'طالب'),
                    senderPhoto: isCommentAnonymous ? '' : (userData?.photo || ''), 
                    type: 'reply', 
                    postId: post.id, 
                    postSnippet: commentTextToSave.substring(0, 40) + '...', 
                    createdAt: Date.now(), 
                    seen: false
                });
            } else if (!replyingToId && post.uid !== currentUser.uid) {
                await window.fb.addDoc(window.fb.collection(window.fb.db, "interactions"), {
                    recipientUid: post.uid, 
                    senderUid: currentUser.uid, 
                    senderName: isCommentAnonymous ? 'مجهول' : (userData?.name || 'طالب'),
                    senderPhoto: isCommentAnonymous ? '' : (userData?.photo || ''), 
                    type: 'comment', 
                    postId: post.id, 
                    postSnippet: commentTextToSave.substring(0, 40) + '...', 
                    createdAt: Date.now(), 
                    seen: false
                });
            }
            
            setNewComment('');
            setReplyingToId(null);
            setReplyingToName('');
            setReplyingToUid(null); 
            setIsCommentAnonymous(false); 
            setShowAllComments(true); 
        } catch (error) {} 
        finally { setIsCommenting(false); }
    };

    const handleLikeComment = async (comment) => {
        const commentRef = window.fb.doc(window.fb.db, "forum_comments", comment.id);
        const currentLikes = Array.isArray(comment.likes) ? comment.likes : [];
        const hasLikedComment = currentLikes.includes(currentUser.uid);

        try {
            if (hasLikedComment) {
                await window.fb.updateDoc(commentRef, { likes: currentLikes.filter(id => id !== currentUser.uid) });
            } else {
                await window.fb.updateDoc(commentRef, { likes: [...currentLikes, currentUser.uid] });
                
                if (comment.uid !== currentUser.uid) {
                    await window.fb.addDoc(window.fb.collection(window.fb.db, "interactions"), {
                        recipientUid: comment.uid, 
                        senderUid: currentUser.uid, 
                        senderName: userData?.name || 'طالب', 
                        senderPhoto: userData?.photo || '',
                        type: 'comment_like', 
                        postId: post.id, 
                        postSnippet: comment.content.substring(0, 40) + '...', 
                        createdAt: Date.now(), 
                        seen: false
                    });
                }
            }
        } catch (e) {}
    };

    const handleSaveEdit = async () => {
        if (!editedContent.trim() || editedContent.trim() === post.content) {
            setIsEditingPost(false); return;
        }
        setIsSavingEdit(true);
        try {
            const postRef = window.fb.doc(window.fb.db, "forum_posts", post.id);
            await window.fb.updateDoc(postRef, { content: editedContent.trim(), isEdited: true });
            setIsEditingPost(false);
        } catch (error) {} finally { setIsSavingEdit(false); }
    };

    const handleTogglePin = async () => {
        try {
            const postRef = window.fb.doc(window.fb.db, "forum_posts", post.id);
            await window.fb.updateDoc(postRef, { isPinned: !post.isPinned });
        } catch(e) {}
    };

    const handleDeletePost = () => { 
        showAlert("حذف المنشور", "هل أنت متأكد من حذف هذا المنشور نهائياً؟", "danger", async () => { 
            try {
                await window.fb.deleteDoc(window.fb.doc(window.fb.db, "forum_posts", post.id)); 
                if (post.isCouncilUpdate) {
                    const q = window.fb.query(window.fb.collection(window.fb.db, "news"), window.fb.where("postId", "==", post.id));
                    const unsub = window.fb.onSnapshot(q, (snap) => {
                        snap.forEach(d => window.fb.deleteDoc(d.ref));
                        unsub(); 
                    });
                }
            } catch(e) {}
        }); 
    };

    const handleDeleteComment = (commentId) => { showAlert("حذف التعليق", "هل أنت متأكد من حذف هذا التعليق؟", "danger", async () => { await window.fb.deleteDoc(window.fb.doc(window.fb.db, "forum_comments", commentId)); }); };
    const toggleRevealComment = (cid) => { setRevealedComments(prev => ({...prev, [cid]: !prev[cid]})); };

    const formatTimeUI = (t) => {
        const timeNum = window.getSafeTime(t);
        if (timeNum === 0) return 'الآن';
        return new Date(timeNum).toLocaleDateString('ar-EG', { month: 'short', day: 'numeric', hour: '2-digit', minute:'2-digit' });
    };

    const handleSharePost = () => {
        const cleanPath = window.location.pathname.replace('/index.html', '/');
        const shareUrl = `${window.location.origin}${cleanPath === '/' ? '' : cleanPath}/?post=${post.id}`;
        
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(shareUrl).then(() => {
                showAlert("تم النسخ", "تم نسخ رابط المنشور بنجاح.", "success");
            }).catch(() => {});
        }
    };

    const canClickPostAuthor = !post.isAnonymous || revealPost;

    const handleReplyClick = (comment) => {
        setReplyingToId(comment.id);
        setReplyingToName(comment.authorName);
        setReplyingToUid(comment.uid);
        const inputField = document.getElementById(`comment-input-${post.id}`);
        if (inputField) inputField.focus();
    };

    const cancelReply = () => {
        setReplyingToId(null);
        setReplyingToName('');
        setReplyingToUid(null);
    };

    // 🌟 دالة التحليل الذكية الجديدة (Parser) 🌟
    const renderFormattedText = (text) => {
        if (!text) return "";
        // التعبير النمطي ده بيدور على النمط @[الاسم](الآي دي) اللي إحنا بنحفظه في الداتا بيز
        const regex = /@\[(.*?)\]\((.*?)\)/g;
        const parts = [];
        let lastIndex = 0;
        let match;

        while ((match = regex.exec(text)) !== null) {
            // إضافة النص العادي اللي قبل المنشن
            if (match.index > lastIndex) {
                parts.push(text.substring(lastIndex, match.index));
            }
            const userName = match[1];
            const userId = match[2];
            
            // 🌟 إضافة المنشن كزرار تفاعلي 🌟
            parts.push(
                <span 
                    key={`mention-${match.index}`} 
                    onClick={(e) => { 
                        e.stopPropagation(); // عشان لو داس على المنشن ميفتحش حاجة تانية بالغلط
                        if (onUserClick) onUserClick(userId); 
                    }} 
                    className="text-indigo-600 dark:text-indigo-400 font-bold cursor-pointer hover:underline bg-indigo-50 dark:bg-indigo-900/30 px-1.5 py-0.5 rounded-md mx-0.5 transition-colors inline-block shadow-sm"
                    dir="rtl"
                    title={`فتح ملف ${userName}`}
                >
                    @{userName}
                </span>
            );
            lastIndex = regex.lastIndex;
        }
        
        // إضافة باقي النص اللي بعد آخر منشن
        if (lastIndex < text.length) {
            parts.push(text.substring(lastIndex));
        }
        return parts;
    };

    const CommentNode = ({ comment, isReply = false }) => {
        const canClickCommentAuthor = !comment.isAnonymous || revealedComments[comment.id];
        const replies = comments.filter(c => c.parentId === comment.id);
        const [showReplies, setShowReplies] = useState(false);

        return (
            <div className={`space-y-3 ${isReply ? 'mr-6 md:mr-10 mt-2 border-r-2 border-slate-100 dark:border-slate-800 pr-3' : ''}`}>
                <div className="flex gap-3 group">
                    <div 
                        onClick={() => canClickCommentAuthor && onUserClick && onUserClick(comment.uid)}
                        className={`w-8 h-8 rounded-full overflow-hidden shrink-0 flex items-center justify-center border shadow-sm transition-colors ${canClickCommentAuthor ? 'cursor-pointer hover:ring-2 hover:ring-indigo-300' : ''} ${revealedComments[comment.id] ? 'bg-amber-100 border-amber-200 text-amber-600' : comment.isAnonymous ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 dark:bg-dark-bg border-slate-200 dark:border-dark-border text-slate-400'}`}
                    >
                        {revealedComments[comment.id] ? <SafeIcon name="eye" className="w-4 h-4" /> : (comment.authorPhoto && !comment.isAnonymous ? <img src={comment.authorPhoto} className="w-full h-full object-cover" /> : <SafeIcon name={comment.isAnonymous ? "eye-off" : "user"} className="w-4 h-4" />)}
                    </div>
                    <div className={`flex-1 p-3 rounded-2xl rounded-tr-sm relative border transition-colors ${revealedComments[comment.id] ? 'bg-amber-50/50 border-amber-100' : 'bg-slate-50 dark:bg-dark-bg border-transparent'}`}>
                        <h4 
                            onClick={() => canClickCommentAuthor && onUserClick && onUserClick(comment.uid)}
                            className={`text-xs font-bold text-slate-800 dark:text-white mb-1 flex items-center gap-1.5 flex-wrap ${canClickCommentAuthor ? 'cursor-pointer hover:text-indigo-600 transition-colors' : ''}`}
                        >
                            {revealedComments[comment.id] ? (
                                <span className="text-amber-600 dark:text-amber-400">{comment.realAuthorName || 'غير معروف'}</span>
                            ) : (comment.isAnonymous && isAdmin) ? (
                                <span className="text-red-500 flex items-center gap-1" title="تعليق مجهول (يظهر للأدمن فقط)">
                                    {comment.realAuthorName || 'غير معروف'}
                                    <SafeIcon name="ghost" className="w-3 h-3 opacity-70" />
                                </span>
                            ) : (
                                comment.authorName
                            )}
                            
                            <span style={{ display: (!comment.isAnonymous && (comment.authorEmail === ADMIN_EMAIL || comment.authorIsVerified)) ? 'inline-flex' : 'none' }} title="موثق"><SafeIcon name="badge-check" className="w-3.5 h-3.5 text-blue-500" /></span>
                            <span style={{ display: (!comment.isAnonymous && (comment.authorEmail === ADMIN_EMAIL || comment.authorIsCouncil)) ? 'inline-flex' : 'none' }} title="مجلس الطلاب"><SafeIcon name="crown" className="w-3.5 h-3.5 text-orange-500" /></span>
                        </h4>
                        
                        <p className="text-[13px] text-slate-600 dark:text-slate-300 leading-relaxed mb-2 whitespace-pre-wrap">
                            {renderFormattedText(comment.content)}
                        </p>
                        
                        <div className="flex justify-between items-center pt-2 border-t border-slate-200/60 dark:border-slate-700/50">
                            <div className="flex items-center gap-4">
                                <button type="button" onClick={() => handleLikeComment(comment)} className={`flex items-center gap-1.5 text-xs font-bold transition-colors ${comment.likes?.includes(currentUser.uid) ? 'text-red-500' : 'text-slate-400 hover:text-red-500'}`}>
                                    <SafeIcon name="heart" className={`w-3.5 h-3.5 ${comment.likes?.includes(currentUser.uid) ? 'fill-current scale-110' : ''}`} />
                                    <span>{comment.likes?.length || 0}</span>
                                </button>

                                {!isReply && isCommentsAllowed && (
                                    <button type="button" onClick={() => handleReplyClick(comment)} className={`flex items-center gap-1 text-[10px] font-bold transition-colors ${replyingToId === comment.id ? 'text-indigo-600' : 'text-slate-400 hover:text-indigo-600'}`}>
                                        <SafeIcon name="reply" className="w-3.5 h-3.5" />
                                        <span>رد</span>
                                    </button>
                                )}
                            </div>
                            <span className="text-[9px] text-slate-400 font-medium">{formatTimeUI(comment.createdAt)}</span>
                        </div>

                        {(isAdmin || comment.uid === currentUser.uid || isCouncilManager) && (
                            <button type="button" onClick={() => handleDeleteComment(comment.id)} className="absolute left-2 top-2 w-6 h-6 rounded-full flex items-center justify-center text-slate-400 hover:text-red-500 hover:bg-white dark:hover:bg-dark-card opacity-0 group-hover:opacity-100 transition-colors shadow-sm">
                                <SafeIcon name="x" className="w-3 h-3" />
                            </button>
                        )}
                    </div>
                </div>

                {replies.length > 0 && (
                    <button onClick={() => setShowReplies(!showReplies)} className="mr-14 text-[11px] font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1 hover:underline">
                        <SafeIcon name={showReplies ? "chevron-up" : "corner-down-left"} className="w-3 h-3 rtl:-scale-x-100" />
                        {showReplies ? 'إخفاء الردود' : `عرض ${replies.length} رد`}
                    </button>
                )}

                {showReplies && replies.map(reply => <CommentNode key={reply.id} comment={reply} isReply={true} />)}
            </div>
        );
    };

    const baseComments = comments.filter(c => !c.parentId);
    const visibleComments = showAllComments ? baseComments : baseComments.slice(0, 3);

    return (
        <div id={`post-${post.id}`} className={`bg-white dark:bg-dark-card rounded-2xl p-5 shadow-sm border mb-5 transition-all duration-1000 relative ${isHighlighted ? 'border-indigo-500 shadow-indigo-200 shadow-lg ring-4 ring-indigo-50 dark:ring-indigo-900/30 scale-[1.02]' : post.isPinned ? 'border-amber-300 dark:border-amber-700/50 shadow-amber-50 dark:shadow-none' : post.isCouncilUpdate ? 'border-indigo-200 dark:border-indigo-800' : 'border-slate-200 dark:border-dark-border hover:shadow-md'}`}>
            
            <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                    <div onClick={() => canClickPostAuthor && onUserClick && onUserClick(post.uid)} className={`w-11 h-11 rounded-full overflow-hidden border flex items-center justify-center shrink-0 shadow-sm transition-colors ${canClickPostAuthor ? 'cursor-pointer hover:ring-2 hover:ring-indigo-300' : ''} ${revealPost ? 'bg-amber-100 border-amber-200 text-amber-600' : post.isAnonymous ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 dark:bg-dark-bg border-slate-200 dark:border-dark-border text-slate-400'}`}>
                        {revealPost ? <SafeIcon name="eye" className="w-6 h-6" /> : (post.authorPhoto && !post.isAnonymous ? <img src={post.authorPhoto} className="w-full h-full object-cover" /> : <SafeIcon name={post.isAnonymous ? "eye-off" : "user"} className="w-6 h-6" />)}
                    </div>
                    <div>
                        <h3 onClick={() => canClickPostAuthor && onUserClick && onUserClick(post.uid)} className={`font-bold text-[15px] text-slate-800 dark:text-white flex items-center gap-1.5 flex-wrap ${canClickPostAuthor ? 'cursor-pointer hover:text-indigo-600 transition-colors' : ''}`}>
                            {revealPost ? (
                                <span className="text-amber-600 dark:text-amber-400">{post.realAuthorName || 'غير معروف'}</span>
                            ) : (post.isAnonymous && isAdmin) ? (
                                <span className="text-red-500 flex items-center gap-1" title="منشور مجهول (يظهر للأدمن فقط)">
                                    {post.realAuthorName || 'غير معروف'}
                                    <SafeIcon name="ghost" className="w-3.5 h-3.5 opacity-70" />
                                </span>
                            ) : (
                                post.authorName
                            )}
                            
                            <span style={{ display: (!post.isAnonymous && (post.authorEmail === ADMIN_EMAIL || post.authorIsVerified)) ? 'inline-flex' : 'none' }} title="موثق"><SafeIcon name="badge-check" className="w-4 h-4 text-blue-500" /></span>
                            <span style={{ display: (!post.isAnonymous && (post.authorEmail === ADMIN_EMAIL || post.authorIsCouncil)) ? 'inline-flex' : 'none' }} title="مجلس الطلاب"><SafeIcon name="crown" className="w-4 h-4 text-orange-500" /></span>
                            {post.isPinned && <span className="text-[10px] bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 px-1.5 py-0.5 rounded flex items-center gap-1 font-bold"><SafeIcon name="pin" className="w-3 h-3" /> مثبت</span>}
                            {post.isCouncilUpdate && <span className="text-[10px] bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400 px-1.5 py-0.5 rounded flex items-center gap-1 font-bold">إعلان رسمي</span>}
                        </h3>
                        
                        <p className="text-xs text-slate-400 font-medium flex items-center gap-1 mt-0.5"><SafeIcon name="clock" className="w-3 h-3 opacity-70" /> {formatTimeUI(post.createdAt)}</p>
                    </div>
                </div>
                
                <div className="flex items-center gap-1">
                    {(isAdmin || isCouncilManager) && (
                        <button type="button" onClick={handleTogglePin} className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${post.isPinned ? 'text-amber-600 bg-amber-50' : 'text-slate-300 hover:text-amber-500 hover:bg-amber-50'}`}><SafeIcon name="pin" className="w-4 h-4" /></button>
                    )}
                    {(post.uid === currentUser.uid || isAdmin || isCouncilManager) && !isEditingPost && (
                        <button type="button" onClick={() => { setEditedContent(post.content); setIsEditingPost(true); }} className="w-8 h-8 rounded-full flex items-center justify-center text-slate-300 hover:text-indigo-500 hover:bg-indigo-50 transition-colors"><SafeIcon name="edit-3" className="w-4 h-4" /></button>
                    )}
                    {(isAdmin || post.uid === currentUser.uid || isCouncilManager) && (
                        <button type="button" onClick={handleDeletePost} className="w-8 h-8 rounded-full flex items-center justify-center text-slate-300 hover:text-red-500 hover:bg-red-50 transition-colors"><SafeIcon name="trash-2" className="w-4 h-4" /></button>
                    )}
                </div>
            </div>

            {isEditingPost ? (
                <div className="mb-5 animate-fade-in">
                    <textarea value={editedContent} onChange={(e) => setEditedContent(e.target.value)} className="w-full min-h-[90px] p-3 text-[15px] bg-slate-50 dark:bg-dark-bg border border-indigo-300 dark:border-indigo-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-100 dark:text-white resize-none transition-all"></textarea>
                    <div className="flex justify-end gap-2 mt-2">
                        <button type="button" onClick={() => setIsEditingPost(false)} className="px-4 py-1.5 rounded-lg text-xs font-bold bg-slate-100 text-slate-500 hover:bg-slate-200 transition-colors">إلغاء</button>
                        <button type="button" onClick={handleSaveEdit} disabled={isSavingEdit || !editedContent.trim()} className="px-4 py-1.5 rounded-lg text-xs font-bold bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm flex items-center gap-1 transition-all">{isSavingEdit ? <div className="spinner w-3 h-3 border-2"></div> : <SafeIcon name="check" className="w-3 h-3" />} {isSavingEdit ? 'جاري الحفظ...' : 'حفظ التعديل'}</button>
                    </div>
                </div>
            ) : (
                <p className="text-slate-800 dark:text-slate-200 text-[15px] leading-relaxed mb-5 whitespace-pre-wrap">
                    {renderFormattedText(post.content)}
                    {post.isEdited && <span className="text-[10px] text-slate-400 mx-2 font-medium bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">(مُعدل)</span>}
                </p>
            )}

            <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-slate-100 dark:border-dark-border">
                <button type="button" onClick={handleLike} disabled={isLiking} className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-sm font-bold transition-colors ${hasLiked ? 'text-red-500 bg-red-50 dark:bg-red-900/20' : 'text-slate-500 hover:text-red-500 hover:bg-slate-50 dark:hover:bg-dark-bg'}`}>
                    <SafeIcon name="heart" className={`w-5 h-5 transition-transform ${hasLiked ? 'fill-current scale-110' : 'scale-100'}`} />
                    <span>{Array.isArray(post.likes) ? post.likes.length : 0}</span>
                </button>

                <button 
                    type="button" 
                    onClick={() => setShowComments(!showComments)} 
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-sm font-bold transition-colors ${!isCommentsAllowed ? 'text-red-500 bg-red-50 dark:bg-red-900/20' : showComments ? 'text-indigo-600 bg-indigo-50 dark:bg-indigo-900/20' : 'text-slate-500 hover:text-indigo-600 hover:bg-slate-50 dark:hover:bg-dark-bg'}`}
                >
                    <SafeIcon name={!isCommentsAllowed ? "lock" : "message-circle"} className="w-5 h-5" />
                    <span>{!isCommentsAllowed ? 'مغلقة' : `تعليق (${baseComments.length})`}</span>
                </button>

                <button type="button" onClick={handleSharePost} className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-sm font-bold transition-colors text-slate-500 hover:text-emerald-600 hover:bg-slate-50 rtl:mr-auto ltr:ml-auto">
                    <SafeIcon name="share-2" className="w-5 h-5" />
                </button>
            </div>

            {showComments && (
                <div className="mt-4 pt-4 border-t border-slate-100 dark:border-dark-border animate-fade-in relative pb-14">
                    <div className="space-y-4 mb-4">
                        {baseComments.length === 0 ? <p className="text-center text-sm text-slate-400 py-2">لا توجد تعليقات.</p> : visibleComments.map(comment => <CommentNode key={comment.id} comment={comment} />)}
                    </div>
                    
                    <div className="absolute bottom-0 left-0 right-0 w-full max-w-full overflow-hidden bg-white dark:bg-dark-card pt-2 border-t border-slate-100 dark:border-slate-800">
                        {!isCommentsAllowed ? (
                            <div className="flex justify-center items-center gap-2 text-xs font-bold text-slate-500 bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-100 dark:border-slate-700">
                                <SafeIcon name="lock" className="w-4 h-4" /> التعليقات مغلقة لهذا الإعلان
                            </div>
                        ) : (
                            <>
                                {replyingToId && (
                                    <div className="flex items-center justify-between px-2 mb-1 text-[11px] font-bold text-indigo-600 animate-fade-in">
                                        <span className="flex items-center gap-1"><SafeIcon name="reply" className="w-3 h-3" /> جارٍ الرد على: {replyingToName}</span>
                                        <button onClick={cancelReply} className="hover:text-red-500"><SafeIcon name="x" className="w-3.5 h-3.5" /></button>
                                    </div>
                                )}
                                <div className="flex items-center gap-2 w-full">
                                    <div className={`w-9 h-9 rounded-full overflow-hidden shrink-0 border flex items-center justify-center shadow-sm ${isCommentAnonymous ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-400'}`}>
                                        {isCommentAnonymous ? <SafeIcon name="eye-off" className="w-4 h-4" /> : (userData?.photo ? <img src={userData.photo} className="w-full h-full object-cover" /> : <SafeIcon name="user" className="w-4 h-4" />)}
                                    </div>
                                    <div className={`flex-1 min-w-0 flex items-center p-1 h-11 bg-slate-50 dark:bg-dark-bg border rounded-full focus-within:ring-2 focus-within:ring-indigo-100`}>
                                        <button type="button" onClick={() => setIsCommentAnonymous(!isCommentAnonymous)} className={`w-9 h-9 flex items-center justify-center shrink-0 rounded-full ${isCommentAnonymous ? 'bg-slate-200 text-slate-800' : 'text-slate-400 hover:bg-slate-200'}`}>
                                            <SafeIcon name={isCommentAnonymous ? "ghost" : "eye"} className="w-4 h-4" />
                                        </button>
                                        <input 
                                            id={`comment-input-${post.id}`}
                                            type="text" 
                                            value={newComment} 
                                            onChange={e => setNewComment(e.target.value)} 
                                            onKeyDown={e => { if (e.key === 'Enter') handleAddComment(e); }}
                                            placeholder={replyingToId ? "اكتب ردك هنا..." : (isCommentAnonymous ? "تعليق سري..." : "اكتب تعليقاً...")}
                                            className="flex-1 min-w-0 w-full h-full bg-transparent px-2 text-[13px] outline-none text-slate-800 dark:text-white" 
                                        />
                                        <button type="button" onClick={(e) => handleAddComment(e)} disabled={!newComment.trim() || isCommenting} className={`w-9 h-9 flex items-center justify-center rounded-full shrink-0 ${newComment.trim() ? 'bg-indigo-600 text-white' : 'bg-transparent text-slate-300 pointer-events-none'}`}>
                                            <SafeIcon name="send" className="w-4 h-4 rtl:-scale-x-100 ml-0.5" />
                                        </button>
                                    </div>
                                </div>
                            </>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};
