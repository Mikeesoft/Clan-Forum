// --- views-profile-chat.js ---
// نظام المحادثات المدمج (مُعدل لإرسال بيانات إشعار الـ Toast بشكل كامل)

var { useState, useEffect, useRef } = React;

window.ProfileChat = ({ currentUser, activeChat, onBack, showAlert }) => {
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const messagesEndRef = useRef(null);
    const ADMIN_EMAIL = "mohammadsafe202a@gmail.com";

    const scrollToBottom = () => {
        if (messagesEndRef.current) {
            messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
        }
    };

    useEffect(() => { scrollToBottom(); }, [messages]);

    // جلب الرسائل + عمل (Seen) للرسائل الجديدة بمجرد فتح الشات
    useEffect(() => {
        if (!activeChat || !activeChat.friendshipId) return;
        
        // دالة تحويل الرسالة لـ مقروءة (Seen)
        const markAsSeen = async () => {
            try {
                const fDocRef = window.fb.doc(window.fb.db, "friendships", activeChat.friendshipId);
                const fDoc = await window.fb.getDoc(fDocRef);
                if (fDoc.exists()) {
                    const data = fDoc.data();
                    if (data.lastMessage && data.lastMessage.senderId !== currentUser.uid && data.lastMessage.seen === false) {
                        await window.fb.updateDoc(fDocRef, {
                            "lastMessage.seen": true
                        });
                    }
                }
            } catch(e) {}
        };
        markAsSeen();

        let unsubMessages = () => {};
        try {
            const q = window.fb.query(
                window.fb.collection(window.fb.db, "chats", activeChat.friendshipId, "messages")
            );
            
            unsubMessages = window.fb.onSnapshot(q, (snapshot) => {
                const fetchedMessages = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                
                fetchedMessages.sort((a, b) => {
                    const timeA = typeof a.createdAt === 'object' && a.createdAt.seconds ? a.createdAt.seconds * 1000 : Number(a.createdAt) || 0;
                    const timeB = typeof b.createdAt === 'object' && b.createdAt.seconds ? b.createdAt.seconds * 1000 : Number(b.createdAt) || 0;
                    return timeA - timeB;
                });
                
                setMessages(fetchedMessages);
            });
        } catch(err) {
            setMessages([]);
        }
        
        return () => unsubMessages();
    }, [activeChat, currentUser.uid]);

    // 🌟 حماية إعادة رسم الأيقونات 🌟
    useEffect(() => { 
        let timeoutId;
        if (window.lucide) {
            timeoutId = setTimeout(() => {
                try { window.lucide.createIcons(); } catch(e) {}
            }, 50);
        }
        return () => clearTimeout(timeoutId);
    }, [activeChat, messages]);

    // إرسال رسالة جديدة
    const sendMessage = async (e) => {
        e.preventDefault();
        if (!newMessage.trim() || !activeChat || !activeChat.friendshipId) return;
        
        const msgText = newMessage.trim();
        setNewMessage(''); 

        try {
            // استخراج ID المستقبل (الطرف التاني في الشات)
            const recipientId = activeChat.id || activeChat.uid;

            // 1. إرسال الرسالة في الشات (تم إضافة حقول الإشعارات هنا 🌟)
            await window.fb.addDoc(window.fb.collection(window.fb.db, "chats", activeChat.friendshipId, "messages"), {
                senderId: currentUser.uid,
                text: msgText,
                createdAt: Date.now(),
                seen: false,
                // 🌟 الحقول الجديدة عشان إشعار الـ Toast يشتغل في app.js 🌟
                recipientUid: recipientId,
                senderName: currentUser.displayName || 'صديقك',
                senderPhoto: currentUser.photoURL || ''
            });
            
            // 2. تحديث مؤشر الإشعارات للصديق (بدون إرسال إشعار عام)
            await window.fb.updateDoc(window.fb.doc(window.fb.db, "friendships", activeChat.friendshipId), {
                lastMessage: {
                    senderId: currentUser.uid,
                    text: msgText,
                    createdAt: Date.now(),
                    seen: false
                },
                updatedAt: Date.now()
            });

        } catch (err) {
            showAlert("خطأ", "لم يتم الإرسال، تأكد من اتصالك بالإنترنت.", "danger", () => {});
        }
    };

    const formatTime = (val) => {
        try {
            if (!val) return '';
            let timeNum = val;
            if (typeof val === 'object' && val.seconds) { timeNum = val.seconds * 1000; }
            const dateObj = new Date(timeNum);
            if (isNaN(dateObj.getTime())) return '';
            return dateObj.toLocaleTimeString('ar-EG', { hour: '2-digit', minute:'2-digit' });
        } catch (e) { return ''; }
    };

    return (
        <div className="animate-fade-in flex flex-col h-[450px]">
            <div className="flex justify-between items-center mb-3 pb-3 border-b border-slate-100 dark:border-dark-border shrink-0">
                <div className="flex items-center gap-3">
                    <button onClick={onBack} className="text-slate-400 hover:text-indigo-600 transition flex items-center justify-center w-8 h-8 bg-slate-50 dark:bg-dark-bg rounded-full">
                        <i data-lucide="arrow-right" className="w-4 h-4 rtl:-scale-x-100"></i>
                    </button>
                    <div className="relative">
                        <div className="w-10 h-10 rounded-full overflow-hidden bg-slate-200 border border-slate-300 flex items-center justify-center">
                            {activeChat.photo ? <img src={activeChat.photo} className="w-full h-full object-cover" /> : <i data-lucide="user" className="w-5 h-5 text-slate-400"></i>}
                        </div>
                        {activeChat.isOnline && <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white dark:border-dark-card rounded-full"></div>}
                    </div>
                    <div>
                        <h3 className="font-bold text-sm text-slate-800 dark:text-white line-clamp-1 flex items-center gap-1">
                            {activeChat.name}
                            <span style={{ display: (activeChat.email === ADMIN_EMAIL || activeChat.isVerified) ? 'inline-flex' : 'none' }} title="حساب موثق">
                                <i data-lucide="badge-check" className="w-4 h-4 text-blue-500"></i>
                            </span>
                            <span style={{ display: (activeChat.email === ADMIN_EMAIL || activeChat.isCouncil) ? 'inline-flex' : 'none' }} title="مجلس الطلاب">
                                <i data-lucide="crown" className="w-4 h-4 text-orange-500"></i>
                            </span>
                        </h3>
                        <p className={`text-[10px] font-bold ${activeChat.isOnline ? 'text-green-500' : 'text-slate-400'}`}>{activeChat.isOnline ? 'متصل الآن' : 'غير متصل'}</p>
                    </div>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto pr-1 space-y-3 custom-scrollbar bg-slate-50/50 dark:bg-dark-bg/20 rounded-xl p-3 mb-3">
                {messages.length === 0 ? (
                    <div className="text-center text-slate-400 py-10 text-xs font-bold flex flex-col items-center">
                        <i data-lucide="messages-square" className="w-10 h-10 mb-2 opacity-30"></i>
                        بداية المحادثة، أرسل أول رسالة!
                    </div>
                ) : (
                    messages.map((msg, index) => {
                        const isMe = msg.senderId === currentUser.uid;
                        return (
                            <div key={msg.id || index} className={`flex ${isMe ? 'justify-end' : 'justify-start'} animate-zoom-in`}>
                                <div className={`max-w-[85%] rounded-2xl px-3 py-2 shadow-sm ${isMe ? 'bg-indigo-600 text-white rounded-tl-sm' : 'bg-white dark:bg-dark-card border border-slate-100 dark:border-dark-border text-slate-800 dark:text-white rounded-tr-sm'}`}>
                                    <p className="text-[13px] leading-relaxed break-words">{msg.text}</p>
                                    <div className={`text-[9px] mt-1 text-right ${isMe ? 'text-indigo-200' : 'text-slate-400'}`}>
                                        {formatTime(msg.createdAt)}
                                    </div>
                                </div>
                            </div>
                        )
                    })
                )}
                <div ref={messagesEndRef} />
            </div>

            <form onSubmit={sendMessage} className="flex items-center gap-2 shrink-0">
                <input 
                    type="text" 
                    value={newMessage} 
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="اكتب رسالتك..." 
                    className="flex-1 h-11 px-4 bg-slate-50 dark:bg-dark-bg border border-slate-200 dark:border-slate-700 rounded-full text-sm outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white transition-all"
                />
                <button type="submit" disabled={!newMessage.trim()} className={`w-11 h-11 rounded-full flex items-center justify-center transition-all shrink-0 ${newMessage.trim() ? 'bg-indigo-600 text-white shadow-md hover:bg-indigo-700' : 'bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-600 cursor-not-allowed'}`}>
                    <i data-lucide="send" className="w-4 h-4 rtl:-scale-x-100 ml-1"></i>
                </button>
            </form>
        </div>
    );
};
