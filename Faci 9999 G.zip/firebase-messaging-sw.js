// --- firebase-messaging-sw.js ---
// ملف الخلفية (Service Worker)

importScripts('https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.7.1/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "AIzaSyBmCmcR6OIQ00tQrmaTTnoe4kU6L4fQZ00",
  authDomain: "myeduplatform-fe0eb.firebaseapp.com",
  projectId: "myeduplatform-fe0eb",
  storageBucket: "myeduplatform-fe0eb.firebasestorage.app",
  messagingSenderId: "773570577444",
  appId: "1:773570577444:web:c94cc1c8267ecbadd004b1"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage(function(payload) {
  const notificationTitle = payload.notification.title || 'إشعار جديد من جامعتي';
  const notificationOptions = {
    body: payload.notification.body,
    icon: 'https://cdn-icons-png.flaticon.com/512/2997/2997321.png',
    badge: 'https://cdn-icons-png.flaticon.com/512/2997/2997321.png',
    dir: 'rtl'
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});
