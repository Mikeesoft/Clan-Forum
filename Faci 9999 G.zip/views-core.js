// --- views-core.js ---
// الشاشات الأساسية (تم تحصين زراير الإشعارات ضد الشاشة البيضاء نهائياً 🛡️🚀)

var { useState, useEffect, useRef, useMemo } = React;
var ADMIN_EMAIL = "mohammadsafe202a@gmail.com";

window.NotificationsView = ({ user, showAlert, setTab }) => {
    const [activeNotifTab, setActiveNotifTab] = useState('general');
    const [news, setNews] = useState([]);
    const [interactions, setInteractions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [pushStatus, setPushStatus] = useState('default'); 
    const [debugMsg, setDebugMsg] = useState(''); 
    const [currentUserData, setCurrentUserData] = useState(null); 
    
    // 🌟 حالة الزر لمنع الكراش أثناء القبول والرفض 🌟
    const [actionLoadingId, setActionLoadingId] = useState(null);
    
    const isAdmin = user.email === ADMIN_EMAIL; 
    const VAPID_KEY = "BHZB6t7XRV7U2YjHzzsouKXgnrWliR7mtEixPIwn6jjNq_xrvG9tfmBYT0LPpuhNG2hnNkuNTTuYkxpzwhRKIrs";

    useEffect(() => {
        if ('Notification' in window) {
            setPushStatus(Notification.permission);
        } else {
            setPushStatus('unsupported');
            setDebugMsg('متصفحك الحالي لا يدعم خدمة الإشعارات.');
        }
        
        const unsub = window.fb.onSnapshot(window.fb.doc(window.fb.db, "users", user.uid), doc => {
            if(doc.exists()) setCurrentUserData(doc.data());
        });
        return () => unsub();
    }, [user.uid]);

    const handleEnablePush = async () => {
        try {
            if (Notification.permission === 'denied' || pushStatus === 'denied') {
                showAlert("مقفولة من المتصفح", "أنت قمت بحظر الإشعارات مسبقاً. اضغط على علامة القفل بجوار الرابط بالأعلى واختر سماح.", "info", ()=>{});
                return;
            }
            const permission = await Notification.requestPermission();
            setPushStatus(permission);

            if (permission === 'granted') {
                showAlert("جاري التفعيل", "يتم الآن تأمين الاتصال بالنظام وتسجيل جهازك...", "info", ()=>{});
                if (!window.fb || !window.fb.messaging) {
                    showAlert("انتظر لحظة", "جاري تهيئة خدمة الإشعارات في الخلفية، يرجى المحاولة بعد قليل.", "info", ()=>{});
                    return;
                }
                const registration = await navigator.serviceWorker.register('./firebase-messaging-sw.js');
                const token = await window.fb.getToken(window.fb.messaging, { vapidKey: VAPID_KEY, serviceWorkerRegistration: registration });
                
                if (token) {
                    await window.fb.updateDoc(window.fb.doc(window.fb.db, "users", user.uid), { fcmToken: token });
                    showAlert("تم بنجاح", "تم تفعيل الإشعارات الذكية بنجاح!", "success", ()=>{});
                }
            } else { showAlert("عذراً", "تم رفض إذن الإشعارات.", "danger", ()=>{}); }
        } catch (err) { showAlert("خطأ تقني", "حدث خطأ أثناء التفعيل.", "danger", ()=>{}); }
    };

    const handleDisablePush = () => {
        showAlert("إيقاف الإشعارات", "هل تريد إيقاف استلام الإشعارات الذكية على هذا الجهاز؟", "danger", async () => {
            try {
                await window.fb.updateDoc(window.fb.doc(window.fb.db, "users", user.uid), { fcmToken: null });
                showAlert("تم", "تم إيقاف الإشعارات من نظام جامعتي.", "info", ()=>{});
                setPushStatus('default');
            } catch (err) {}
        });
    };

    useEffect(() => {
        const qNews = window.fb.query(window.fb.collection(window.fb.db, "news"));
        const unsubNews = window.fb.onSnapshot(qNews, (snapshot) => {
            const rawData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            const filteredData = rawData.filter(item => !item.targetUid || item.targetUid === user.uid || isAdmin);
            filteredData.sort((a, b) => (b.date ? new Date(b.date) : new Date(0)) - (a.date ? new Date(a.date) : new Date(0)));
            setNews(filteredData);
            if (!isAdmin && filteredData.length > 0) markAsSeen(filteredData, user.uid);
        });

        const qInteractions = window.fb.query(window.fb.collection(window.fb.db, "interactions"), window.fb.where("recipientUid", "==", user.uid));
        const unsubInteractions = window.fb.onSnapshot(qInteractions, (snapshot) => {
            const fetchedInt = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            fetchedInt.sort((a, b) => b.createdAt - a.createdAt);
            setInteractions(fetchedInt);
            setLoading(false);
            fetchedInt.forEach(async (intItem) => { if (!intItem.seen) try { await window.fb.updateDoc(window.fb.doc(window.fb.db, "interactions", intItem.id), { seen: true }); } catch (e) {} });
        });
        setTimeout(() => { if(window.lucide) window.lucide.createIcons(); }, 100);
        return () => { unsubNews(); unsubInteractions(); };
    }, [user.uid, isAdmin]);

    const markAsSeen = (newsList, userId) => {
        newsList.forEach(async (item) => {
            const seenBy = item.seenBy || [];
            if (!seenBy.includes(userId)) {
                try { await window.fb.updateDoc(window.fb.doc(window.fb.db, "news", item.id), { seenBy: window.fb.arrayUnion(userId) }); } catch (err) {}
            }
        });
    };

    const handleDeleteNews = async (id) => {
        showAlert("حذف الإشعار", "هل أنت متأكد من حذف الإشعار؟", "danger", async () => { try { await window.fb.deleteDoc(window.fb.doc(window.fb.db, "news", id)); } catch (err) {} });
    };

    const handleNewsClick = (item) => {
        if (item.type === 'council' && item.postId) {
            localStorage.setItem('openCouncilChannel', 'true');
            localStorage.setItem('scrollToPost', item.postId);
            if (setTab) setTab('forum');
        }
    };

    const handleAcceptFriendRequest = async (int) => {
        try {
            const fid = int.recipientUid < int.senderUid ? `${int.recipientUid}_${int.senderUid}` : `${int.senderUid}_${int.recipientUid}`;
            await window.fb.updateDoc(window.fb.doc(window.fb.db, "friendships", fid), { status: 'accepted', updatedAt: Date.now() });

            await window.fb.addDoc(window.fb.collection(window.fb.db, "interactions"), {
                recipientUid: int.senderUid,
                senderUid: int.recipientUid,
                senderName: currentUserData?.name || user.displayName || 'طالب',
                senderPhoto: currentUserData?.photo || '',
                type: 'friend_accept',
                postSnippet: 'وافق على طلب الصداقة',
                createdAt: Date.now(),
                seen: false
            });

            await window.fb.updateDoc(window.fb.doc(window.fb.db, "interactions", int.id), { type: 'friend_request_accepted', postSnippet: 'أصبحتم أصدقاء الآن' });
            showAlert("تم القبول", "أصبحتم أصدقاء الآن!", "success", () => {});
        } catch (e) { showAlert("خطأ", "حدث خطأ أثناء قبول الطلب.", "danger", () => {}); }
    };

    const handleRejectFriendRequest = async (int) => {
        try {
            const fid = int.recipientUid < int.senderUid ? `${int.recipientUid}_${int.senderUid}` : `${int.senderUid}_${int.recipientUid}`;
            await window.fb.deleteDoc(window.fb.doc(window.fb.db, "friendships", fid));
            await window.fb.updateDoc(window.fb.doc(window.fb.db, "interactions", int.id), { type: 'friend_request_rejected', postSnippet: 'تم رفض الطلب' });
        } catch (e) {}
    };

    const handleTeamRequest = async (interaction, action) => {
        setActionLoadingId(interaction.id);
        try {
            const teamRef = window.fb.doc(window.fb.db, "teams", interaction.teamId);
            const teamDoc = await window.fb.getDoc(teamRef);
            
            if (teamDoc.exists()) {
                const teamData = teamDoc.data();
                let newMembers = [...teamData.members];
                let newReqs = (teamData.joinRequests || []).filter(id => id !== interaction.senderUid);
                
                if (action === 'approve') newMembers.push(interaction.senderUid);
                
                await window.fb.updateDoc(teamRef, { members: newMembers, joinRequests: newReqs });
            }
            
            await window.fb.updateDoc(window.fb.doc(window.fb.db, "interactions", interaction.id), {
                type: action === 'approve' ? 'team_request_accepted' : 'team_request_rejected',
                postSnippet: action === 'approve' ? `وافقت على انضمامه لفريق ${interaction.teamName}` : `رفضت انضمامه لفريق ${interaction.teamName}`
            });
            
            showAlert("نجاح", action === 'approve' ? "تمت الموافقة وتم إضافة العضو للتيم" : "تم رفض الطلب", "success");
        } catch(e) {
            showAlert("خطأ", "حدث خطأ أثناء معالجة الطلب", "danger");
        } finally {
            setActionLoadingId(null);
        }
    };

    const handleInteractionClick = (int) => {
        if (int.postId && (int.type === 'like' || int.type === 'comment' || int.type === 'comment_like')) {
            localStorage.setItem('scrollToPost', int.postId);
            if (setTab) setTab('forum');
        }
    };

    const formatDate = (val) => {
        try {
            if (!val) return "الآن";
            const date = new Date(typeof val === 'number' ? val : val);
            if (isNaN(date.getTime())) return "الآن";
            return date.toLocaleDateString('ar-EG', { month: 'short', day: 'numeric', hour: '2-digit', minute:'2-digit' });
        } catch (e) { return "الآن"; }
    };

    return (
        <div className="space-y-6 animate-fade-in pb-20">
            <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-2">الإشعارات</h2>
            
            <div className="flex bg-slate-200/50 dark:bg-dark-card p-1.5 rounded-2xl shadow-sm border border-slate-200 dark:border-dark-border">
                <button onClick={() => {setActiveNotifTab('general'); setTimeout(() => {if(window.lucide) window.lucide.createIcons()}, 50);}} className={`flex-1 py-2 text-sm font-bold rounded-xl transition flex items-center justify-center gap-2 ${activeNotifTab === 'general' ? 'bg-white dark:bg-dark-bg text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-indigo-500'}`}>
                    <i data-lucide="megaphone" className="w-4 h-4"></i> عام
                </button>
                <button onClick={() => {setActiveNotifTab('interactions'); setTimeout(() => {if(window.lucide) window.lucide.createIcons()}, 50);}} className={`flex-1 py-2 text-sm font-bold rounded-xl transition flex items-center justify-center gap-2 ${activeNotifTab === 'interactions' ? 'bg-white dark:bg-dark-bg text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-indigo-500'}`}>
                    <i data-lucide="heart" className="w-4 h-4"></i> تفاعلات
                    {interactions.filter(i => !i.seen).length > 0 && <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>}
                </button>
            </div>

            {!isAdmin && (
                <div className={`p-4 rounded-2xl flex justify-between items-center border transition-all ${pushStatus === 'granted' ? 'bg-green-50/50 border-green-100 dark:bg-green-900/10 dark:border-green-900/30' : pushStatus === 'unsupported' ? 'bg-red-50 border-red-100' : 'bg-indigo-50 dark:bg-indigo-900/20 border-indigo-100 dark:border-indigo-900/50'}`}>
                    <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-full ${pushStatus === 'granted' ? 'bg-green-100 text-green-600' : pushStatus === 'unsupported' ? 'bg-red-100 text-red-600' : 'bg-indigo-100 text-indigo-600'}`}>
                            <i data-lucide={pushStatus === 'granted' ? "bell-ring" : pushStatus === 'unsupported' ? "alert-circle" : "bell-off"} className="w-5 h-5"></i>
                        </div>
                        <div>
                            <h3 className="font-bold text-sm text-slate-800 dark:text-white">الإشعارات الذكية</h3>
                            {pushStatus === 'unsupported' ? (
                                <p className="text-[10px] text-red-600 font-bold mt-1 max-w-[200px]">{debugMsg}</p>
                            ) : (
                                <p className="text-xs text-slate-500 dark:text-slate-400">
                                    {pushStatus === 'granted' ? 'مفعلة' : 'احصل على تنبيهات فورية'}
                                </p>
                            )}
                        </div>
                    </div>
                    {pushStatus === 'unsupported' ? (
                        <span className="text-xs text-red-500 font-bold bg-white px-2 py-1 rounded">معطلة</span>
                    ) : pushStatus === 'granted' ? (
                        <button onClick={handleDisablePush} className="px-3 py-1.5 bg-slate-200 dark:bg-dark-bg text-slate-600 dark:text-slate-300 rounded-lg text-xs font-bold hover:bg-slate-300 transition">إيقاف</button>
                    ) : (
                        <button onClick={handleEnablePush} className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold shadow-md hover:bg-indigo-700 transition flex items-center gap-1">تفعيل <i data-lucide="zap" className="w-3 h-3"></i></button>
                    )}
                </div>
            )}

            {loading ? <div className="text-center py-10 text-slate-400">جاري التحميل...</div> : (
                <div className="grid gap-4 animate-fade-in">
                    {activeNotifTab === 'general' && (
                        news.length === 0 ? (
                            <div className="text-center py-10 bg-white dark:bg-dark-card rounded-2xl border border-dashed border-slate-300 dark:border-dark-border"><i data-lucide="bell-off" className="w-10 h-10 text-slate-300 mx-auto mb-2"></i><p className="text-slate-500 dark:text-dark-muted">لا توجد إشعارات عامة حالياً</p></div>
                        ) : news.map(item => (
                            <div 
                                key={item.id} 
                                onClick={() => handleNewsClick(item)}
                                className={`bg-white dark:bg-dark-card p-5 rounded-xl shadow-sm border transition relative group ${item.postId ? 'cursor-pointer hover:shadow-md' : ''} ${item.targetUid ? 'border-r-4 border-r-amber-500 bg-amber-50/30' : item.type === 'urgent' ? 'border-r-4 border-r-red-500' : item.type === 'council' ? 'border-r-4 border-r-orange-500' : item.type === 'event' ? 'border-r-4 border-r-purple-500' : 'border-r-4 border-r-blue-500'}`}
                            >
                                {isAdmin && (
                                    <button onClick={(e) => { e.stopPropagation(); handleDeleteNews(item.id); }} className="absolute top-4 left-4 text-slate-300 hover:text-red-500 p-2 rounded-full hover:bg-red-50 dark:hover:bg-red-900/20 transition opacity-100 md:opacity-0 md:group-hover:opacity-100 z-10"><i data-lucide="trash-2" className="w-4 h-4"></i></button>
                                )}
                                <div>
                                    <div className="flex items-center gap-2 mb-3">
                                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${item.targetUid ? 'bg-amber-100 text-amber-700' : item.type === 'urgent' ? 'bg-red-100 text-red-600' : item.type === 'council' ? 'bg-orange-100 text-orange-600' : 'bg-blue-100 text-blue-600'}`}>
                                            {item.targetUid ? 'رسالة خاصة' : item.type === 'urgent' ? 'عاجل' : item.type === 'council' ? 'مجلس الطلاب' : 'إدارة'}
                                        </span>
                                        <span className="text-xs text-slate-400 flex items-center gap-1"><i data-lucide="clock" className="w-3 h-3"></i> {formatDate(item.date)}</span>
                                    </div>
                                    <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-2">{item.title}</h3>
                                    
                                    <p className={`text-sm leading-relaxed whitespace-pre-wrap ${item.postId ? 'text-slate-500 line-clamp-2' : 'text-slate-600 dark:text-dark-muted'}`}>
                                        {item.content}
                                    </p>
                                    
                                    {item.postId && (
                                        <span className="text-xs text-indigo-600 dark:text-indigo-400 font-bold mt-3 flex items-center gap-1">
                                            اضغط لعرض التفاصيل الكاملة <i data-lucide="arrow-left" className="w-3 h-3 rtl:-scale-x-100"></i>
                                        </span>
                                    )}
                                </div>
                            </div>
                        ))
                    )}

                    {activeNotifTab === 'interactions' && (
                        interactions.length === 0 ? (
                            <div className="text-center py-10 bg-white dark:bg-dark-card rounded-2xl border border-dashed border-slate-300 dark:border-dark-border"><i data-lucide="ghost" className="w-10 h-10 text-slate-300 mx-auto mb-2"></i><p className="text-slate-500 dark:text-dark-muted">لم يتفاعل أحد معك بعد.</p></div>
                        ) : interactions.map(int => (
                            <div key={int.id} onClick={() => handleInteractionClick(int)} className={`bg-white dark:bg-dark-card p-4 rounded-xl shadow-sm border transition flex items-start gap-3 relative ${int.postId ? 'cursor-pointer hover:border-indigo-300 hover:shadow-md' : 'border-slate-200 dark:border-dark-border cursor-default'}`}>
                                <div className="relative shrink-0">
                                    <div className="w-12 h-12 rounded-full overflow-hidden bg-slate-100 border border-slate-200 flex items-center justify-center">
                                        {int.senderPhoto ? <img src={int.senderPhoto} className="w-full h-full object-cover" /> : <i data-lucide="user" className="w-6 h-6 text-slate-400"></i>}
                                    </div>
                                    
                                    <div className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full border-2 border-white dark:border-dark-card flex items-center justify-center text-white ${int.type.includes('like') ? 'bg-red-500' : int.type.includes('friend') ? 'bg-emerald-500' : int.type.includes('team') ? 'bg-amber-500' : 'bg-indigo-500'}`}>
                                        <i data-lucide={int.type.includes('like') ? "heart" : int.type.includes('friend') ? "user-check" : int.type.includes('team') ? "users" : "message-circle"} className="w-3 h-3 fill-current"></i>
                                    </div>
                                </div>
                                <div className="flex-1 pt-1 min-w-0">
                                    <p className="text-sm text-slate-800 dark:text-white leading-snug">
                                        <span className="font-bold">{int.senderName}</span> 
                                        {int.type === 'like' ? ' أعجب بمنشورك' : 
                                         int.type === 'comment_like' ? ' أعجب بتعليقك' : 
                                         int.type === 'friend_request' ? ' أرسل لك طلب صداقة' : 
                                         int.type === 'friend_request_accepted' ? ' أصبحتم أصدقاء الآن' : 
                                         int.type === 'friend_accept' ? ' وافق على طلب الصداقة' : 
                                         int.type === 'friend_request_rejected' ? ' تم رفض طلب الصداقة' : 
                                         int.type === 'team_join_request' ? ` يطلب الانضمام لفريق: ${int.teamName}` : 
                                         int.type === 'team_request_accepted' ? ' ' + int.postSnippet :
                                         int.type === 'team_request_rejected' ? ' ' + int.postSnippet :
                                         ' علق على منشورك'}
                                    </p>
                                    
                                    {int.postSnippet && !int.type.includes('team_request') && (
                                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-1 border-r-2 border-slate-200 dark:border-slate-600 pr-2 opacity-80">"{int.postSnippet}"</p>
                                    )}
                                    
                                    <span className="text-[10px] text-slate-400 mt-2 block font-medium">{formatDate(int.createdAt)}</span>
                                    
                                    {/* 🌟 زراير قبول/رفض انضمام التيمات مؤمنة بـ SVG 🌟 */}
                                    {int.type === 'team_join_request' && (
                                        <div className="mt-3 flex gap-2 w-full max-w-[250px]">
                                            <button onClick={(e) => { e.stopPropagation(); handleTeamRequest(int, 'approve'); }} disabled={actionLoadingId === int.id} className="flex-1 h-8 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg text-xs font-bold transition-colors shadow-sm flex items-center justify-center gap-1">
                                                {actionLoadingId === int.id ? <div className="spinner w-3 h-3 border-2"></div> : 
                                                <><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg> قبول</>
                                                }
                                            </button>
                                            <button onClick={(e) => { e.stopPropagation(); handleTeamRequest(int, 'reject'); }} disabled={actionLoadingId === int.id} className="flex-1 h-8 bg-red-50 hover:bg-red-100 dark:bg-red-900/20 dark:hover:bg-red-900/40 text-red-600 dark:text-red-400 border border-red-100 dark:border-red-900/50 rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1">
                                                {actionLoadingId === int.id ? <div className="spinner w-3 h-3 border-2 border-current"></div> : 
                                                <><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg> رفض</>
                                                }
                                            </button>
                                        </div>
                                    )}

                                    {/* 🌟 زراير طلبات الصداقة مؤمنة بـ SVG 🌟 */}
                                    {int.type === 'friend_request' && (
                                        <div className="mt-3 flex gap-2">
                                            <button onClick={(e) => { e.stopPropagation(); handleAcceptFriendRequest(int); }} className="flex-1 bg-indigo-600 text-white py-1.5 rounded-lg text-xs font-bold hover:bg-indigo-700 transition shadow-sm flex items-center justify-center gap-1">
                                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg> قبول
                                            </button>
                                            <button onClick={(e) => { e.stopPropagation(); handleRejectFriendRequest(int); }} className="flex-1 bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300 py-1.5 rounded-lg text-xs font-bold hover:bg-slate-200 dark:hover:bg-slate-600 transition flex items-center justify-center gap-1">
                                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg> رفض
                                            </button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))
                    )}
                </div>
            )}
        </div>
    );
};

window.HomeView = ({ user, setTab, showAlert }) => {
    const [stats, setStats] = useState({ courses: 0, tasks: 0 });
    const [nextExam, setNextExam] = useState(null);
    const [latestNews, setLatestNews] = useState(null);
    const [todayCourses, setTodayCourses] = useState([]);
    
    const displayName = user.displayName ? user.displayName.split(' ')[0] : '';
    const daysMap = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    const todayName = daysMap[new Date().getDay()];

    useEffect(() => {
        const u1 = window.fb.onSnapshot(window.fb.query(window.fb.collection(window.fb.db, "courses"), window.fb.where("uid", "==", user.uid)), s => {
            setStats(p => ({...p, courses: s.size}));
            const allCourses = s.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            const todayList = allCourses.filter(c => c.day === todayName).sort((a,b) => (a.time||'').localeCompare(b.time||''));
            setTodayCourses(todayList);
            setTimeout(() => { if(window.lucide) window.lucide.createIcons(); }, 100);
        });
        const u2 = window.fb.onSnapshot(window.fb.query(window.fb.collection(window.fb.db, "tasks"), window.fb.where("uid", "==", user.uid), window.fb.where("completed", "==", false)), s => setStats(p => ({...p, tasks: s.size})));
        const u3 = window.fb.onSnapshot(window.fb.query(window.fb.collection(window.fb.db, "exams"), window.fb.where("uid", "==", user.uid)), s => {
            const e = s.docs.map(d=>d.data()).filter(x=>new Date(x.date)>new Date()).sort((a,b)=>new Date(a.date)-new Date(b.date));
            setNextExam(e[0]);
        });
        const u4 = window.fb.onSnapshot(window.fb.query(window.fb.collection(window.fb.db, "news")), s => {
            const newsData = s.docs.map(d => d.data())
                .filter(item => !item.targetUid || item.targetUid === user.uid)
                .sort((a, b) => new Date(b.date) - new Date(a.date));
            if (newsData.length > 0) setLatestNews(newsData[0]);
        });
        return () => { u1(); u2(); u3(); u4(); };
    }, [user, todayName]);

    const handleLatestNewsClick = () => {
        if (latestNews.type === 'council' && latestNews.postId) {
            localStorage.setItem('openCouncilChannel', 'true');
            localStorage.setItem('scrollToPost', latestNews.postId);
            setTab('forum');
        } else {
            setTab('notifications');
        }
    };

    return (
        <div className="space-y-6 animate-fade-in pb-20">
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-3xl p-6 md:p-8 text-white shadow-xl relative overflow-hidden flex items-center justify-between">
                <div className="relative z-10">
                    <h1 className="text-2xl md:text-3xl font-bold mb-2">مرحباً {displayName} 👋</h1>
                    <p className="text-indigo-100 opacity-90 text-sm md:text-base">يوم رائع للإنجاز!</p>
                </div>
                
                <button onClick={() => setTab('timer')} className="relative z-10 flex items-center justify-center w-16 h-16 md:w-20 md:h-20 bg-white/20 hover:bg-white/30 backdrop-blur-md rounded-2xl border border-white/30 shadow-[0_4px_15px_rgba(0,0,0,0.1)] transition-all duration-300 hover:scale-105 hover:shadow-[0_4px_25px_rgba(255,255,255,0.4)] group">
                    <i data-lucide="box" className="w-7 h-7 md:w-8 md:h-8 text-white group-hover:rotate-12 transition-transform"></i>
                </button>
                <i data-lucide="award" className="absolute left-4 bottom-[-20px] w-32 h-32 text-white opacity-10 transform rotate-12 pointer-events-none"></i>
            </div>
            
            <div className="bg-white dark:bg-dark-card p-5 rounded-2xl border border-slate-200 dark:border-dark-border shadow-sm">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-slate-800 dark:text-white flex items-center gap-2"><i data-lucide="calendar-clock" className="w-5 h-5 text-indigo-500"></i> محاضرات اليوم ({todayName})</h3>
                    <button onClick={() => { localStorage.setItem('academic_subtab', 'timetable'); setTab('academic'); }} className="text-xs text-indigo-600 dark:text-indigo-400 font-bold bg-indigo-50 dark:bg-indigo-900/30 px-3 py-1.5 rounded-lg transition hover:bg-indigo-100">الجدول</button>
                </div>
                {todayCourses.length > 0 ? (
                    <div className="space-y-3">
                        {todayCourses.map(course => (
                            <div key={course.id} className="flex items-center gap-4 p-3 bg-slate-50 dark:bg-dark-bg/50 rounded-xl border-r-4 border-indigo-500 transition hover:shadow-sm">
                                <div className="bg-white dark:bg-dark-card p-2 rounded-lg shadow-sm text-indigo-600 dark:text-indigo-400 font-bold text-sm w-20 text-center shrink-0" dir="ltr">{course.time ? new Date('1970-01-01T' + course.time).toLocaleTimeString('en-US', {hour: 'numeric', minute:'2-digit'}) : '--:--'}</div>
                                <div className="flex-1"><div className="font-bold text-slate-800 dark:text-white text-sm">{course.name}</div><div className="text-xs text-slate-500 dark:text-dark-muted mt-1 flex items-center gap-1"><i data-lucide="user" className="w-3 h-3"></i> {course.doctor || 'غير محدد'}</div></div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-6 bg-slate-50 dark:bg-dark-bg/50 rounded-xl border border-dashed border-slate-200 dark:border-dark-border">
                        <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/20 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-2"><i data-lucide="coffee" className="w-6 h-6"></i></div>
                        <p className="text-slate-600 dark:text-slate-300 text-sm font-bold">لا توجد محاضرات اليوم</p>
                    </div>
                )}
            </div>

            {nextExam && (() => {
                const daysLeft = Math.ceil((new Date(nextExam.date) - new Date()) / (1000 * 60 * 60 * 24));
                const isUrgent = daysLeft <= 2 && daysLeft > 0;
                const typeColors = { 'Final': 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400', 'Midterm': 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400', 'Quiz': 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400', 'Practical': 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400' };
                const colorClass = typeColors[nextExam.type] || typeColors['Final'];

                return (
                    <div onClick={() => { localStorage.setItem('agenda_subtab', 'exams'); setTab('agenda'); }} className={`cursor-pointer border p-4 rounded-xl flex items-center justify-between transition hover:shadow-md ${isUrgent ? 'bg-red-50 dark:bg-red-900/10 border-red-200 dark:border-red-900/50' : 'bg-white dark:bg-dark-card border-slate-200 dark:border-dark-border'}`}>
                        <div className="flex items-center gap-3">
                            <div className={`p-3 rounded-xl flex items-center justify-center ${colorClass} ${isUrgent ? 'animate-pulse' : ''}`}><i data-lucide="alarm-clock" className="w-6 h-6"></i></div>
                            <div>
                                <div className="flex items-center gap-2 mb-1"><span className="font-bold text-slate-900 dark:text-white text-sm">{nextExam.subject}</span><span className={`text-[9px] px-2 py-0.5 rounded font-bold uppercase ${colorClass}`}>{nextExam.type}</span></div>
                                <div className="text-xs text-slate-500 dark:text-dark-muted flex items-center gap-1"><i data-lucide="calendar" className="w-3 h-3"></i> {new Date(nextExam.date).toLocaleDateString('ar-EG', {month: 'short', day: 'numeric', hour: '2-digit', minute:'2-digit'})}</div>
                            </div>
                        </div>
                        <div className="text-center bg-slate-50 dark:bg-dark-bg/50 px-3 py-2 rounded-lg border border-slate-100 dark:border-dark-border">
                            <div className={`text-xl font-bold font-mono ${isUrgent ? 'text-red-600' : 'text-slate-800 dark:text-white'}`}>{daysLeft > 0 ? daysLeft : 'اليوم'}</div><div className="text-[9px] uppercase font-bold text-slate-400">{daysLeft > 0 ? 'أيام' : 'الموعد'}</div>
                        </div>
                    </div>
                );
            })()}

            {latestNews && (
                <div onClick={handleLatestNewsClick} className={`cursor-pointer rounded-xl p-4 border shadow-sm flex items-start gap-4 transition hover:bg-slate-50 dark:hover:bg-dark-card/80 ${latestNews.targetUid ? 'bg-amber-50 border-amber-200 dark:bg-amber-900/10 dark:border-amber-900/30' : latestNews.type === 'urgent' ? 'bg-red-50 border-red-200 dark:bg-red-900/10 dark:border-red-900/30' : latestNews.type === 'council' ? 'bg-orange-50 border-orange-200 dark:bg-orange-900/10 dark:border-orange-900/30' : 'bg-white border-slate-200 dark:bg-dark-card dark:border-dark-border'}`}>
                    <div className={`p-2 rounded-full shrink-0 ${latestNews.targetUid ? 'bg-amber-100 text-amber-600' : latestNews.type === 'urgent' ? 'bg-red-100 text-red-600 animate-pulse' : latestNews.type === 'council' ? 'bg-orange-100 text-orange-600' : 'bg-indigo-100 text-indigo-600'}`}>
                        <i data-lucide={latestNews.targetUid ? "wallet" : latestNews.type === 'urgent' ? "alert-circle" : latestNews.type === 'council' ? "crown" : "bell"} className="w-6 h-6"></i>
                    </div>
                    <div className="flex-1">
                        <div className="flex justify-between items-center mb-1">
                            <h3 className={`font-bold text-sm ${latestNews.targetUid ? 'text-amber-700 dark:text-amber-500' : latestNews.type === 'urgent' ? 'text-red-700 dark:text-red-400' : latestNews.type === 'council' ? 'text-orange-700 dark:text-orange-500' : 'text-slate-800 dark:text-white'}`}>{latestNews.title}</h3>
                            <span className="text-[10px] bg-white dark:bg-dark-bg px-2 py-0.5 rounded-full border text-slate-500 shadow-sm">إشعار</span>
                        </div>
                        <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-1">{latestNews.content}</p>
                    </div>
                    <i data-lucide="chevron-left" className="w-5 h-5 text-slate-300 mt-2"></i>
                </div>
            )}
            
            <div className="grid grid-cols-2 gap-4 pb-10">
                <div onClick={() => { localStorage.setItem('academic_subtab', 'courses'); setTab('academic'); }} className="bg-white dark:bg-dark-card p-5 rounded-2xl border border-slate-100 dark:border-dark-border shadow-sm cursor-pointer hover:shadow-md transition"><i data-lucide="book-open" className="w-8 h-8 text-blue-500 mb-2"></i><div className="text-2xl font-bold text-slate-800 dark:text-white">{stats.courses}</div><div className="text-xs text-slate-500 font-bold">مواد مسجلة</div></div>
                <div onClick={() => { localStorage.setItem('agenda_subtab', 'tasks'); setTab('agenda'); }} className="bg-white dark:bg-dark-card p-5 rounded-2xl border border-slate-100 dark:border-dark-border shadow-sm cursor-pointer hover:shadow-md transition"><i data-lucide="check-square" className="w-8 h-8 text-orange-500 mb-2"></i><div className="text-2xl font-bold text-slate-800 dark:text-white">{stats.tasks}</div><div className="text-xs text-slate-500 font-bold">مهام معلقة</div></div>
            </div>
        </div>
    );
};
