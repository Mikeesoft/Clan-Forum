// --- views-forum.js ---
// الشاشة الرئيسية للمنتدى (استقرار المنشن القديم + ربط شاشة التيمات 🚀✨)

var { useState, useEffect, useRef } = React;
var ADMIN_EMAIL = "mohammadsafe202a@gmail.com";

const SafeIcon = window.SafeIcon;
const PostItem = window.PostItem;
const getSafeTime = window.getSafeTime;

// ==========================================
// 🌟 مكون مربع النص الذكي (Global) 🌟
// ==========================================
window.MentionTextarea = ({ user, userData, value, onChange, onMentionAdd, placeholder, disabled, className }) => {
    const [showDropdown, setShowDropdown] = useState(false);
    const [query, setQuery] = useState('');
    const [cursorIdx, setCursorIdx] = useState(0);
    const [friends, setFriends] = useState([]);
    const textareaRef = useRef(null);

    useEffect(() => {
        if (!user) return;
        const q = window.fb.query(
            window.fb.collection(window.fb.db, "friendships"),
            window.fb.where("users", "array-contains", user.uid),
            window.fb.where("status", "==", "accepted")
        );
        const unsub = window.fb.onSnapshot(q, async (snap) => {
            const friendsPromises = snap.docs.map(async (doc) => {
                const data = doc.data();
                const friendId = data.users.find(id => id !== user.uid);
                if(friendId) {
                    const fDoc = await window.fb.getDoc(window.fb.doc(window.fb.db, "users", friendId));
                    if(fDoc.exists()) return { id: friendId, name: fDoc.data().name, photo: fDoc.data().photo };
                }
                return null;
            });
            const resolved = await Promise.all(friendsPromises);
            let fList = resolved.filter(f => f !== null);
            // 🌟 إضافة المستخدم نفسه للقائمة 🌟
            fList.unshift({ id: user.uid, name: userData?.name || 'أنا', photo: userData?.photo });
            setFriends(fList);
        });
        return () => unsub();
    }, [user, userData]);

    const handleChange = (e) => {
        const val = e.target.value;
        onChange(val);

        const cursorPos = e.target.selectionStart;
        const textBefore = val.slice(0, cursorPos);
        const match = textBefore.match(/@([^\s]*)$/);

        if (match) {
            setShowDropdown(true);
            setQuery(match[1]);
            setCursorIdx(match.index);
        } else {
            setShowDropdown(false);
        }
    };

    const handleSelect = (selectedUser) => {
        const replacement = `@${selectedUser.name} `;
        const newText = value.slice(0, cursorIdx) + replacement + value.slice(cursorIdx + query.length + 1);
        onChange(newText);
        
        if (onMentionAdd) {
            onMentionAdd({ name: selectedUser.name, id: selectedUser.id });
        }
        
        setShowDropdown(false);
        if(textareaRef.current) textareaRef.current.focus();
    };

    const filtered = friends.filter(u => u.name.toLowerCase().includes(query.toLowerCase()));

    return (
        <div className="relative flex-1 flex flex-col w-full">
            <textarea
                ref={textareaRef}
                value={value}
                onChange={handleChange}
                disabled={disabled}
                placeholder={placeholder}
                className={`w-full ${className}`}
            />
            
            {showDropdown && filtered.length > 0 && (
                <div className="absolute z-[9999] bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 shadow-2xl rounded-2xl max-h-52 overflow-y-auto min-w-[220px] w-max max-w-[95vw] top-full mt-2 rtl:right-0 ltr:left-0 animate-fade-in custom-scrollbar ring-1 ring-black/5 dark:ring-white/10">
                    <div className="p-2.5 text-[11px] font-bold text-indigo-500 dark:text-indigo-400 border-b border-slate-100 dark:border-slate-700/50 bg-slate-50/90 dark:bg-slate-800/90 sticky top-0 z-10 flex items-center gap-1.5 backdrop-blur-md">
                        <SafeIcon name="users" className="w-3.5 h-3.5" /> اختر شخصاً للإشارة إليه
                    </div>
                    <div className="p-1.5 space-y-0.5">
                        {filtered.map(u => (
                            <div key={u.id} onClick={() => handleSelect(u)} className="flex items-center gap-3 p-2 rounded-xl hover:bg-indigo-50 dark:hover:bg-indigo-900/30 cursor-pointer transition-all duration-200 group">
                                <div className="w-9 h-9 rounded-full overflow-hidden bg-slate-100 dark:bg-slate-700 shrink-0 border border-slate-200 dark:border-slate-600 flex items-center justify-center text-slate-400 group-hover:border-indigo-300 dark:group-hover:border-indigo-500 transition-colors shadow-sm">
                                    {u.photo ? <img src={u.photo} className="w-full h-full object-cover" /> : <SafeIcon name="user" className="w-4 h-4"/>}
                                </div>
                                <div className="flex flex-col flex-1 min-w-0">
                                    <span className="text-sm font-bold text-slate-700 dark:text-slate-200 truncate group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors flex items-center gap-2">
                                        {u.name}
                                        {u.id === user.uid && <span className="text-[9px] bg-indigo-100 text-indigo-700 dark:bg-indigo-900/50 dark:text-indigo-300 px-1.5 py-0.5 rounded-full font-bold leading-none">أنت</span>}
                                    </span>
                                    <span className="text-[10px] text-slate-400 dark:text-slate-500 truncate mt-0.5">اضغط للإشارة</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

// ==========================================
// 🌟 واجهة المنتدى العامة 🌟
// ==========================================
window.ForumView = ({ user, showAlert, setTab }) => {
    const [posts, setPosts] = useState([]);
    const [newPostContent, setNewPostContent] = useState('');
    const [isPosting, setIsPosting] = useState(false);
    const [loading, setLoading] = useState(true);
    const [userData, setUserData] = useState(null);
    const [isAnonymous, setIsAnonymous] = useState(false);
    
    const [visibleCount, setVisibleCount] = useState(10);
    const [selectedUserUid, setSelectedUserUid] = useState(null);
    const [targetPostId, setTargetPostId] = useState(null);
    
    const [showCouncil, setShowCouncil] = useState(false);
    const [showCouncilChannel, setShowCouncilChannel] = useState(false); 
    const [showTeams, setShowTeams] = useState(false); // 🌟 تفعيل حالة التيمات
    
    const [activeMentions, setActiveMentions] = useState([]); 
    
    const isAdmin = user?.email === ADMIN_EMAIL;
    const MentionTextarea = window.MentionTextarea; 
    
    useEffect(() => {
        const checkRouting = () => {
            const openCouncil = localStorage.getItem('openCouncilChannel');
            if (openCouncil === 'true') {
                setShowCouncilChannel(true);
                localStorage.removeItem('openCouncilChannel');
            } else {
                const savedPostId = localStorage.getItem('scrollToPost');
                if (savedPostId) {
                    setTargetPostId(savedPostId);
                    localStorage.removeItem('scrollToPost');
                }
            }
        };
        checkRouting();
        
        let unsubUser = () => {};
        let unsubPosts = () => {};
        
        try {
            const userRef = window.fb.doc(window.fb.db, "users", user.uid);
            unsubUser = window.fb.onSnapshot(userRef, (docSnap) => {
                if (docSnap.exists()) setUserData(docSnap.data());
            });
            
            const q = window.fb.query(window.fb.collection(window.fb.db, "forum_posts"));
            unsubPosts = window.fb.onSnapshot(q, (snapshot) => {
                const fetched = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })).filter(p => !p.isCouncilUpdate);
                fetched.sort((a, b) => {
                    if (a.isPinned && !b.isPinned) return -1;
                    if (!a.isPinned && b.isPinned) return 1;
                    return getSafeTime(b.createdAt) - getSafeTime(a.createdAt);
                });
                setPosts(fetched);
                setLoading(false);
            });
        } catch (err) { setLoading(false); }
        
        return () => { unsubUser(); unsubPosts(); };
    }, [user.uid]);
    
    useEffect(() => {
        if (!loading && targetPostId && posts.length > 0 && !selectedUserUid && !showCouncil && !showCouncilChannel && !showTeams) {
            const targetIndex = posts.findIndex(p => p.id === targetPostId);
            if (targetIndex !== -1 && targetIndex >= visibleCount) { setVisibleCount(targetIndex + 5); }
            setTimeout(() => {
                const element = document.getElementById(`post-${targetPostId}`);
                if (element) {
                    element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    setTimeout(() => setTargetPostId(null), 3000);
                }
            }, 500);
        }
    }, [loading, targetPostId, posts, selectedUserUid, showCouncil, showCouncilChannel, showTeams, visibleCount]);
    
    useEffect(() => {
        let timeoutId = setTimeout(() => { try { window.lucide.createIcons(); } catch (e) {} }, 50);
        return () => clearTimeout(timeoutId);
    }, [showCouncil, showCouncilChannel, showTeams, visibleCount]); 
    
    const handleCreatePost = async (e) => {
        if (e) e.preventDefault();
        if (!newPostContent.trim() || isPosting) return;
        setIsPosting(true);
        
        let finalContent = newPostContent.trim();
        activeMentions.forEach(mention => {
            finalContent = finalContent.split(`@${mention.name}`).join(`@[${mention.name}](${mention.id})`);
        });

        try {
            await window.fb.addDoc(window.fb.collection(window.fb.db, "forum_posts"), {
                uid: user.uid, authorName: isAnonymous ? 'مجهول' : (userData?.name || 'طالب جامعي'),
                authorEmail: isAnonymous ? 'hidden' : (user.email || ''), authorPhoto: isAnonymous ? '' : (userData?.photo || ''),
                realAuthorName: userData?.name || 'طالب جامعي', authorIsVerified: userData?.isVerified || false,
                authorIsCouncil: userData?.isCouncil || false, isAnonymous: isAnonymous, isCouncilUpdate: false, 
                allowComments: true, content: finalContent, likes: [], isPinned: false, createdAt: Date.now()
            });
            setNewPostContent(''); 
            setIsAnonymous(false); 
            setActiveMentions([]);
            setVisibleCount(prev => prev + 1); 
            showAlert("تم النشر", "تم نشر مشاركتك بنجاح.", "success", () => {});
        } catch (error) { showAlert("خطأ", "حدث خطأ أثناء النشر.", "danger", () => {}); } finally { setIsPosting(false); }
    };
    
    const handleUserClick = (uid) => {
        if (uid === user.uid) {
            if (setTab) setTab('profile');
            return;
        }
        setSelectedUserUid(uid);
    };

    // 🌟 التوجيه للشاشات المختلفة 🌟
    if (showCouncil && window.CouncilView) return <window.CouncilView user={user} showAlert={showAlert} setTab={setTab} onBack={() => setShowCouncil(false)} />;
    if (showCouncilChannel && window.CouncilChannelView) return <window.CouncilChannelView user={user} userData={userData} isAdmin={isAdmin} showAlert={showAlert} onBack={() => setShowCouncilChannel(false)} setTab={setTab} />;
    if (showTeams && window.TeamsView) return <window.TeamsView user={user} showAlert={showAlert} onBack={() => setShowTeams(false)} onUserClick={handleUserClick} />;
       // 🌟 استدعاء ملف التيمات
    if (selectedUserUid) return <window.PublicProfileView currentUser={user} targetUid={selectedUserUid} onBack={() => setSelectedUserUid(null)} showAlert={showAlert} setTab={setTab} />;
    
    return (
        <div className="space-y-4 animate-fade-in pb-20 max-w-2xl mx-auto mt-2">
            
            <div className="flex justify-between items-center">
                <div className="flex-1 min-w-0 pr-2">
                    <h2 className="text-xl sm:text-2xl font-bold text-slate-800 dark:text-white flex items-center gap-2 truncate">
                        المنتدى الطلابي <SafeIcon name="users" className="w-5 h-5 text-indigo-500 shrink-0 hidden sm:block" />
                    </h2>
                    <p className="text-slate-500 text-[10px] sm:text-sm mt-0.5 truncate">شارك وتفاعل مع زملائك</p>
                </div>

                <div className="flex items-center bg-white dark:bg-dark-card border border-slate-200 dark:border-dark-border rounded-full p-1 shadow-sm shrink-0 animate-zoom-in">
                    
                    <button onClick={() => setShowCouncil(true)} title="أعضاء المجلس" className="w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-900/20 transition-all hover:scale-105">
                        <i data-lucide="shield-check" className="w-4 h-4 sm:w-5 sm:h-5"></i>
                    </button>
                    
                    <div className="w-[1px] h-5 bg-slate-100 dark:bg-dark-border mx-0.5 sm:mx-1"></div>
                    
                    <button onClick={() => setShowCouncilChannel(true)} title="أخبار المجلس" className="w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition-all hover:scale-105 relative">
                        <i data-lucide="radio" className="w-4 h-4 sm:w-5 sm:h-5"></i>
                    </button>

                    <div className="w-[1px] h-5 bg-slate-100 dark:bg-dark-border mx-0.5 sm:mx-1"></div>
                    
                    {/* 🌟 تفعيل زرار فرق العمل 🌟 */}
                    <button onClick={() => setShowTeams(true)} title="فرق العمل (التيمات)" className="w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center text-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-all hover:scale-105">
                        <i data-lucide="users-round" className="w-4 h-4 sm:w-5 sm:h-5"></i>
                    </button>
                </div>
            </div>

            <div className="bg-white dark:bg-dark-card p-5 rounded-2xl shadow-sm border border-slate-200 dark:border-dark-border relative transition-colors">
                <div className={`absolute top-0 left-0 w-1.5 h-full rounded-tl-2xl rounded-bl-2xl transition-colors ${isAnonymous ? 'bg-slate-800 dark:bg-slate-600' : 'bg-gradient-to-b from-indigo-500 to-purple-500'}`}></div>
                
                <div className={isPosting ? 'opacity-70 pointer-events-none' : ''}>
                    <div className="flex gap-3 mb-3 relative">
                        <div className={`w-12 h-12 rounded-full overflow-hidden shrink-0 border-2 shadow-sm flex items-center justify-center z-10 transition-colors ${isAnonymous ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-400'}`}>
                            {isAnonymous ? <SafeIcon name="eye-off" className="w-6 h-6" /> : (userData?.photo ? <img src={userData.photo} className="w-full h-full object-cover" /> : <SafeIcon name="user" className="w-6 h-6" />)}
                        </div>
                        
                        <MentionTextarea 
                            user={user}
                            userData={userData}
                            value={newPostContent} 
                            onChange={setNewPostContent}
                            onMentionAdd={(mention) => setActiveMentions(prev => [...prev, mention])} 
                            placeholder={isAnonymous ? 'اكتب بسرية تامة...' : `بم تفكر يا ${userData?.name?.split(' ')[0]}؟ (اكتب @ للإشارة لصديق)`}
                            disabled={isPosting}
                            className={`min-h-[70px] w-full resize-none bg-transparent border-none outline-none text-[15px] text-slate-800 dark:text-white pt-2.5 transition-colors ${isAnonymous ? 'placeholder-slate-500 font-medium' : 'placeholder-slate-400'}`}
                        />

                    </div>
                    <div className="flex justify-between items-center pt-3 border-t border-slate-100 dark:border-dark-border">
                        <button type="button" onClick={() => setIsAnonymous(!isAnonymous)} className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold bg-slate-50 text-slate-500 hover:bg-slate-100 dark:bg-dark-bg dark:text-slate-400">
                            <SafeIcon name={isAnonymous ? "eye-off" : "ghost"} className="w-4 h-4" /> <span className="hidden sm:inline">{isAnonymous ? 'مفعل' : 'مخفي'}</span>
                        </button>
                        <button type="button" onClick={handleCreatePost} disabled={!newPostContent.trim() || isPosting} className="px-6 py-2.5 rounded-xl font-bold text-sm bg-indigo-600 text-white hover:bg-indigo-700 flex items-center gap-2 shadow-sm">
                            {isPosting ? 'جاري النشر...' : 'نشر البوست'}
                        </button>
                    </div>
                </div>
            </div>

            <div className="space-y-4">
                {posts.slice(0, visibleCount).map(post => <PostItem key={post.id} post={post} currentUser={user} userData={userData} isAdmin={isAdmin} showAlert={showAlert} isHighlighted={post.id === targetPostId} onUserClick={handleUserClick} />)}
            </div>
        </div>
    );
};
