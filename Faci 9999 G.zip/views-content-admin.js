// --- views-content-admin.js ---
// شاشة إضافة المحتوى وبناء الاختبارات (نسخة الروابط الخارجية الذكية 🔗 وتجنب قيود مساحة فايربيز)

var { useState, useEffect, useRef } = React;

const CustomDropdown = ({ options, value, onChange, icon }) => {
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef(null);
    const selectedOption = options.find(opt => opt.value === value);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setIsOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    return (
        <div className="relative w-full" ref={dropdownRef}>
            <button 
                type="button"
                onClick={() => setIsOpen(!isOpen)}
                className="w-full h-11 px-4 border rounded-xl bg-white dark:bg-dark-bg dark:border-dark-border dark:text-white flex items-center justify-between outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-sm font-bold shadow-sm hover:border-indigo-300"
            >
                <span className="flex items-center gap-2">
                    {icon && <i data-lucide={icon} className="w-4 h-4 text-slate-500"></i>}
                    {selectedOption ? selectedOption.label : 'اختر...'}
                </span>
                <i data-lucide={isOpen ? "chevron-up" : "chevron-down"} className="w-4 h-4 text-slate-400"></i>
            </button>

            {isOpen && (
                <div className="absolute z-50 w-full mt-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl overflow-hidden animate-fade-in">
                    {options.map((option) => (
                        <button
                            key={option.value}
                            type="button"
                            onClick={() => {
                                onChange(option.value);
                                setIsOpen(false);
                            }}
                            className={`w-full text-right px-4 py-3 text-sm font-bold transition-colors flex items-center gap-2 ${value === option.value ? 'bg-indigo-50 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
                        >
                            {option.icon && <i data-lucide={option.icon} className="w-4 h-4"></i>}
                            {option.label}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
};

window.ContentAdminPanel = ({ onClose, showAlert }) => {
    const [isAdding, setIsAdding] = useState(false);
    const [newMat, setNewMat] = useState({ 
        courseName: '', 
        title: '', 
        url: '', 
        type: 'pdf', 
        isFree: false 
    });

    const [quizQuestions, setQuizQuestions] = useState([
        { questionText: '', options: ['', '', '', ''], correctOptionIndex: 0, explanation: '' }
    ]);

    useEffect(() => {
        let timeoutId = setTimeout(() => {
            if (window.lucide) {
                try { window.lucide.createIcons(); } catch(e) {}
            }
        }, 100);
        return () => clearTimeout(timeoutId);
    }, [newMat.type, quizQuestions.length, isAdding]);

    const handleAddQuestion = () => {
        setQuizQuestions([...quizQuestions, { questionText: '', options: ['', '', '', ''], correctOptionIndex: 0, explanation: '' }]);
    };

    const handleRemoveQuestion = (index) => {
        if (quizQuestions.length === 1) return;
        const updated = [...quizQuestions];
        updated.splice(index, 1);
        setQuizQuestions(updated);
    };

    const handleQuestionChange = (index, field, value) => {
        const updated = [...quizQuestions];
        updated[index][field] = value;
        setQuizQuestions(updated);
    };

    const handleOptionChange = (qIndex, optIndex, value) => {
        const updated = [...quizQuestions];
        updated[qIndex].options[optIndex] = value;
        setQuizQuestions(updated);
    };

    const handleSave = async (e) => {
        e.preventDefault();
        
        if (!newMat.title || !newMat.courseName) {
            showAlert("تنبيه", "يرجى كتابة اسم المادة وعنوان المحتوى.", "danger", () => {});
            return;
        }

        if (newMat.type !== 'quiz' && !newMat.url) {
            showAlert("تنبيه", "يرجى وضع رابط المحتوى (Google Drive أو YouTube).", "danger", () => {});
            return;
        }

        if (newMat.type === 'quiz') {
            for (let i = 0; i < quizQuestions.length; i++) {
                const q = quizQuestions[i];
                if (!q.questionText.trim() || q.options.some(opt => !opt.trim())) {
                    showAlert("تنبيه", `السؤال رقم ${i + 1} غير مكتمل، يرجى ملء نص السؤال وجميع الخيارات.`, "danger", () => {});
                    return;
                }
            }
        }

        setIsAdding(true);

        try {
            const payload = {
                courseName: newMat.courseName.trim(),
                title: newMat.title.trim(),
                type: newMat.type,
                isFree: newMat.isFree,
                views: 0,
                viewedBy: [],
                createdAt: Date.now()
            };

            if (newMat.type === 'quiz') {
                payload.questions = quizQuestions;
            } else {
                payload.url = newMat.url.trim();
            }

            await window.fb.addDoc(window.fb.collection(window.fb.db, "materials"), payload);
            
            setNewMat({ courseName: '', title: '', url: '', type: 'pdf', isFree: false });
            setQuizQuestions([{ questionText: '', options: ['', '', '', ''], correctOptionIndex: 0, explanation: '' }]);
            
            setTimeout(() => {
                setIsAdding(false); 
                const successMsg = newMat.type === 'quiz' ? "تمت إضافة الاختبار للمكتبة." : "تم إضافة الرابط للمكتبة بنجاح.";
                showAlert("تم بنجاح", successMsg, "success", () => {});
                onClose();
            }, 600);

        } catch (error) {
            setIsAdding(false);
            showAlert("خطأ", "حدث خطأ أثناء الحفظ، يرجى المحاولة مرة أخرى.", "danger", () => {});
        }
    };

    const typeOptions = [
        { value: 'pdf', label: 'رابط ملزمة (Drive / PDF)', icon: 'file-text' },
        { value: 'video', label: 'رابط فيديو (YouTube / Drive)', icon: 'youtube' },
        { value: 'quiz', label: 'اختبار إلكتروني (MCQ)', icon: 'help-circle' }
    ];

    const accessOptions = [
        { value: false, label: 'محتوى مدفوع (VIP)', icon: 'award' },
        { value: true, label: 'محتوى مجاني (للجميع)', icon: 'unlock' }
    ];

    return (
        <div className="bg-white dark:bg-dark-card p-5 rounded-2xl border border-slate-200 dark:border-dark-border shadow-sm mb-6 animate-fade-in relative">
            <div className="flex justify-between items-center mb-5 border-b border-slate-100 dark:border-dark-border pb-3">
                <h3 className="font-bold text-lg text-slate-800 dark:text-white flex items-center gap-2">
                    <i data-lucide="edit-3" className="w-5 h-5 text-indigo-500"></i> إضافة محتوى جديد
                </h3>
                <button onClick={onClose} disabled={isAdding} className={`p-2 rounded-lg transition-colors ${isAdding ? 'text-slate-300 cursor-not-allowed' : 'bg-slate-50 hover:bg-red-50 text-slate-400 hover:text-red-500'}`}>
                    <i data-lucide="x" className="w-5 h-5"></i>
                </button>
            </div>

            <form onSubmit={handleSave} className={`space-y-5 ${isAdding ? 'opacity-50 pointer-events-none' : ''}`}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-xs font-bold text-slate-500 mb-2">اسم المادة</label>
                        <input className="w-full h-11 px-4 border rounded-xl dark:bg-dark-bg dark:border-dark-border dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-sm shadow-sm" placeholder="مثال: فيزياء عامة" required value={newMat.courseName} onChange={e=>setNewMat({...newMat, courseName: e.target.value})} />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-slate-500 mb-2">عنوان المحتوى</label>
                        <input className="w-full h-11 px-4 border rounded-xl dark:bg-dark-bg dark:border-dark-border dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-sm shadow-sm" placeholder="مثال: المحاضرة الأولى" required value={newMat.title} onChange={e=>setNewMat({...newMat, title: e.target.value})} />
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-xs font-bold text-slate-500 mb-2">نوع المحتوى</label>
                        <CustomDropdown options={typeOptions} value={newMat.type} onChange={(val) => setNewMat({...newMat, type: val})} icon="layout" />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-slate-500 mb-2">صلاحية الوصول</label>
                        <CustomDropdown options={accessOptions} value={newMat.isFree} onChange={(val) => setNewMat({...newMat, isFree: val})} icon="shield" />
                    </div>
                </div>

                {newMat.type !== 'quiz' && (
                    <div className="animate-fade-in bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-700">
                        <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-2">الرابط الخارجي</label>
                        <div className="relative">
                            <i data-lucide="link" className="absolute right-4 top-3.5 w-4 h-4 text-slate-400"></i>
                            <input 
                                type="url" 
                                className="w-full h-11 pr-10 pl-4 border rounded-xl dark:bg-dark-bg dark:border-dark-border dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-sm direction-ltr text-left shadow-sm" 
                                placeholder="https://drive.google.com/..." 
                                required={newMat.type !== 'quiz'} 
                                value={newMat.url} 
                                onChange={e=>setNewMat({...newMat, url: e.target.value})} 
                            />
                        </div>
                        <p className="text-[10px] text-slate-500 mt-2 font-bold flex items-center gap-1">
                            <i data-lucide="info" className="w-3 h-3"></i>
                            يرجى التأكد من أن رابط (Drive) مفتوح للمشاهدة للجميع (Anyone with the link).
                        </p>
                    </div>
                )}

                {newMat.type === 'quiz' && (
                    <div className="mt-6 pt-6 border-t border-slate-100 dark:border-dark-border space-y-6">
                        <div className="flex justify-between items-center">
                            <h4 className="font-bold text-slate-800 dark:text-white flex items-center gap-2">
                                <i data-lucide="list-checks" className="w-5 h-5 text-indigo-500"></i> أسئلة الاختبار
                            </h4>
                            <span className="text-xs font-bold bg-slate-100 text-slate-600 dark:bg-dark-bg dark:text-slate-400 px-3 py-1 rounded-lg shadow-sm">
                                {quizQuestions.length} سؤال
                            </span>
                        </div>

                        {quizQuestions.map((q, qIndex) => (
                            <div key={qIndex} className="bg-slate-50 dark:bg-dark-bg/50 p-4 rounded-xl border border-slate-200 dark:border-dark-border relative shadow-sm">
                                {quizQuestions.length > 1 && (
                                    <button type="button" onClick={() => handleRemoveQuestion(qIndex)} className="absolute top-3 left-3 text-slate-400 hover:text-red-500 transition-colors" title="حذف السؤال">
                                        <i data-lucide="trash-2" className="w-4 h-4"></i>
                                    </button>
                                )}
                                
                                <div className="mb-4">
                                    <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-2">السؤال رقم {qIndex + 1}</label>
                                    <textarea className="w-full p-3 border rounded-lg dark:bg-slate-800 dark:border-slate-700 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 text-sm resize-none h-20 shadow-sm" placeholder="اكتب نص السؤال هنا..." required value={q.questionText} onChange={e => handleQuestionChange(qIndex, 'questionText', e.target.value)}></textarea>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                                    {q.options.map((opt, optIndex) => (
                                        <div key={optIndex} className="flex items-center gap-2">
                                            {/* 🌟 إصلاح كراش الأيقونة في الكويزات 🌟 */}
                                            <button 
                                                type="button" 
                                                onClick={() => handleQuestionChange(qIndex, 'correctOptionIndex', optIndex)}
                                                className={`w-6 h-6 shrink-0 rounded-full border-2 flex items-center justify-center transition-all shadow-sm ${q.correctOptionIndex === optIndex ? 'border-indigo-500 bg-indigo-500 text-white' : 'border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800'}`}
                                                title="تحديد كإجابة صحيحة"
                                            >
                                                {q.correctOptionIndex === optIndex && (
                                                    <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" strokeWidth="3" fill="none" strokeLinecap="round" strokeLinejoin="round">
                                                        <polyline points="20 6 9 17 4 12"></polyline>
                                                    </svg>
                                                )}
                                            </button>
                                            <input className={`flex-1 h-10 px-3 border rounded-lg outline-none text-sm transition-all shadow-sm dark:bg-slate-800 dark:text-white ${q.correctOptionIndex === optIndex ? 'border-indigo-500 ring-1 ring-indigo-500' : 'border-slate-200 dark:border-slate-700 focus:border-slate-400'}`} placeholder={`الخيار ${optIndex + 1}`} required value={opt} onChange={e => handleOptionChange(qIndex, optIndex, e.target.value)} />
                                        </div>
                                    ))}
                                </div>

                                <div>
                                    <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-2 flex items-center gap-1">
                                        <i data-lucide="info" className="w-3 h-3"></i> تفسير الإجابة (يظهر للطالب بعد الحل)
                                    </label>
                                    <input className="w-full h-10 px-3 border rounded-lg dark:bg-slate-800 dark:border-slate-700 dark:text-white outline-none focus:border-indigo-500 transition-all text-sm shadow-sm" placeholder="مثال: الإجابة الصحيحة هي كذا لأن القانون ينص على..." value={q.explanation} onChange={e => handleQuestionChange(qIndex, 'explanation', e.target.value)} />
                                </div>
                            </div>
                        ))}

                        <button type="button" onClick={handleAddQuestion} className="w-full h-11 border-2 border-dashed border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 font-bold rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 text-sm">
                            <i data-lucide="plus-circle" className="w-4 h-4"></i> إضافة سؤال جديد
                        </button>
                    </div>
                )}

                <div className="pt-4 flex justify-end">
                    <button disabled={isAdding} type="submit" className={`w-full md:w-auto h-11 px-8 rounded-xl font-bold transition-all shadow-md flex items-center justify-center gap-2 ${isAdding ? 'bg-indigo-400 text-indigo-100 cursor-not-allowed' : 'bg-indigo-600 text-white hover:bg-indigo-700 hover:shadow-lg active:scale-95'}`}>
                        <span style={{ display: isAdding ? 'none' : 'flex' }} className="items-center gap-2">
                            <i data-lucide="save" className="w-4 h-4"></i> حفظ ونشر
                        </span>
                        <span style={{ display: isAdding ? 'flex' : 'none' }} className="items-center gap-2">
                            <div className="spinner w-4 h-4 border-2 border-indigo-100"></div> 
                            {newMat.type === 'quiz' ? 'جاري حفظ الاختبار...' : 'جاري الحفظ...'}
                        </span>
                    </button>
                </div>
            </form>
        </div>
    );
};
