// --- app-dashboard.js ---
// ملف لوحة التحكم (تم تأمين الدوال وعرض شاشة القفل للزوار، وتم إزالة التايمر نهائياً 🛡️)

var { useState, useEffect, useRef } = React;
const ADMIN_EMAIL = "mohammadsafe202a@gmail.com";

// 🌟 شاشة القفل للزوار (Guest Mode UI) 🌟
const GuestLockedView = ({ onLoginClick }) => {
    useEffect(() => {
        let timeoutId = setTimeout(() => { try { window.lucide.createIcons(); } catch(e) {} }, 100);
        return () => clearTimeout(timeoutId);
    }, []);

    return (
        <div className="flex flex-col items-center justify-center py-20 px-4 text-center animate-fade-in min-h-[65vh]">
            <div className="w-28 h-28 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-500 rounded-full flex items-center justify-center mb-6 shadow-inner border-[6px] border-white dark:border-dark-card shadow-[0_10px_30px_rgba(79,70,229,0.15)] relative">
                <i data-lucide="lock" className="w-12 h-12"></i>
                <div className="absolute -top-1 -right-1 w-6 h-6 bg-red-500 rounded-full border-2 border-white dark:border-dark-card flex items-center justify-center"><i data-lucide="x" className="w-3 h-3 text-white"></i></div>
            </div>
            
            <h2 className="text-3xl font-bold text-slate-800 dark:text-white mb-3 tracking-tight">مرحباً بك في جامعتي 👋</h2>
            <p className="text-slate-500 dark:text-slate-400 mb-8 max-w-sm leading-relaxed mx-auto">
                أنت الآن في وضع الزائر. هذا المحتوى حصري للطلاب المسجلين فقط حفاظاً على الخصوصية. يرجى تسجيل الدخول للوصول إلى كافة الميزات والتفاعل مع زملائك.
            </p>
            
            <button onClick={onLoginClick} className="h-14 px-8 bg-indigo-600 text-white rounded-xl font-bold shadow-xl shadow-indigo-600/30 hover:bg-indigo-700 hover:scale-105 transition-all flex items-center gap-2 mx-auto">
                <i data-lucide="log-in" className="w-5 h-5 rtl:-scale-x-100"></i>
                تسجيل الدخول أو إنشاء حساب
            </button>
        </div>
    );
};

window.Dashboard = ({ user, onLoginClick }) => {
    const [activeTab, setActiveTab] = useState(() => {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('post') ? 'forum' : 'home';
    });

    const [darkMode, setDarkMode] = useState(() => localStorage.getItem('theme') === 'dark'); 
    const [modalConfig, setModalConfig] = useState({ isOpen: false, title: '', message: '', type: 'danger', onConfirm: null }); 
    const [deferredPrompt, setDeferredPrompt] = useState(null);
    const [userPhoto, setUserPhoto] = useState(''); 
    const [hasUnreadNews, setHasUnreadNews] = useState(false);
    const [isBannedStatus, setIsBannedStatus] = useState(false);

    const [toast, setToast] = useState(null);
    const toastTimeoutRef = useRef(null);

    const activeTabRef = useRef(activeTab);
    useEffect(() => { activeTabRef.current = activeTab; }, [activeTab]);

    const showToast = (title, message, photo, onClick) => {
        setToast({ title, message, photo, onClick });
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = ctx.createOscillator(); const gain = ctx.createGain();
            osc.type = 'sine'; osc.frequency.setValueAtTime(800, ctx.currentTime);
            gain.gain.setValueAtTime(0.1, ctx.currentTime); gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
            osc.connect(gain); gain.connect(ctx.destination); osc.start(); osc.stop(ctx.currentTime + 0.2);
        } catch(e) {}

        if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
        toastTimeoutRef.current = setTimeout(() => { setToast(null); }, 3000); 
    };

    useEffect(() => {
        const urlParams = new URLSearchParams(window.location.search);
        const postId = urlParams.get('post');
        if (postId) {
            localStorage.setItem('scrollToPost', postId); 
            const newUrl = window.location.pathname;
            window.history.replaceState({}, document.title, newUrl);
        }
    }, []);
    
    const showAlert = (title, message, type = 'danger', onConfirm) => { setModalConfig({ isOpen: true, title, message, type, onConfirm }); };
    const closeAlert = () => { setModalConfig({ ...modalConfig, isOpen: false }); };
    
    const handleLogout = async () => {
        try {
            if(user) {
                const userRef = window.fb.doc(window.fb.db, "users", user.uid);
                await window.fb.updateDoc(userRef, { isOnline: false });
            }
            window.fb.signOut(window.fb.auth);
        } catch(e) { window.fb.signOut(window.fb.auth); }
    };

    useEffect(() => {
        if (!user) return; 
        const checkBanStatus = async () => {
            try {
                const privRef = window.fb.doc(window.fb.db, "users_private", user.uid);
                const unsubPriv = window.fb.onSnapshot(privRef, (docSnap) => {
                    if (docSnap.exists() && docSnap.data().isBanned !== undefined) { setIsBannedStatus(docSnap.data().isBanned); } 
                    else {
                        const pubRef = window.fb.doc(window.fb.db, "users", user.uid);
                        window.fb.getDoc(pubRef).then(pubSnap => { if (pubSnap.exists()) setIsBannedStatus(pubSnap.data().isBanned || false); });
                    }
                });
                return unsubPriv;
            } catch(e) {}
        };
        let unsub = () => {};
        checkBanStatus().then(res => { if(res) unsub = res; });
        return () => unsub();
    }, [user?.uid]);

    useEffect(() => { 
        if(darkMode) document.documentElement.classList.add('dark'); 
        else document.documentElement.classList.remove('dark'); 
        localStorage.setItem('theme', darkMode ? 'dark' : 'light'); 
    }, [darkMode]);

    useEffect(() => { 
        const handleInstallPrompt = (e) => { e.preventDefault(); setDeferredPrompt(e); };
        window.addEventListener('beforeinstallprompt', handleInstallPrompt);
        setTimeout(() => { if(window.lucide) window.lucide.createIcons(); }, 100); 
        return () => window.removeEventListener('beforeinstallprompt', handleInstallPrompt);
    }, [activeTab, hasUnreadNews, isBannedStatus]); 

    useEffect(() => {
        if (!user || isBannedStatus) return; 
        setTimeout(() => {
            if (window.fb && window.fb.messaging && window.fb.onMessage) {
                if ('Notification' in window && Notification.permission === 'granted') {
                    window.fb.onMessage(window.fb.messaging, (payload) => { showToast(payload.notification?.title || "إشعار جديد", payload.notification?.body || '', null, () => setActiveTab('notifications')); });
                }
            }
        }, 1500);
    }, [user?.uid, isBannedStatus]);

    useEffect(() => {
        if (!user || isBannedStatus) return; 
        const qFriendships = window.fb.query(window.fb.collection(window.fb.db, "friendships"), window.fb.where("users", "array-contains", user.uid));
        const unsub = window.fb.onSnapshot(qFriendships, (snapshot) => {
            snapshot.docChanges().forEach(async (change) => {
                if (change.type === "modified") {
                    const data = change.doc.data();
                    if (data.lastMessage && data.lastMessage.senderId !== user.uid && data.lastMessage.seen === false) {
                        if (activeTabRef.current !== 'chat') {
                            let senderName = "رسالة جديدة"; let senderPhoto = "";
                            try {
                                const userDoc = await window.fb.getDoc(window.fb.doc(window.fb.db, "users", data.lastMessage.senderId));
                                if (userDoc.exists()) { senderName = userDoc.data().name || senderName; senderPhoto = userDoc.data().photo || ""; }
                            } catch(e) {}
                            showToast(senderName, data.lastMessage.text, senderPhoto, () => { localStorage.setItem('directChatUid', data.lastMessage.senderId); setActiveTab('chat'); });
                        }
                    }
                }
            });
        });
        return () => unsub();
    }, [user?.uid, isBannedStatus]); 

    useEffect(() => {
        if (!user || isBannedStatus) return; 
        const isAdmin = user.email === ADMIN_EMAIL;
        let unreadNews = false; let unreadInteractions = false;

        const unsubNews = window.fb.onSnapshot(window.fb.query(window.fb.collection(window.fb.db, "news")), (snapshot) => {
            unreadNews = false;
            if (!isAdmin) {
                snapshot.forEach(doc => {
                    const data = doc.data();
                    if (!data.targetUid || data.targetUid === user.uid) { if (!data.seenBy || !data.seenBy.includes(user.uid)) { unreadNews = true; } }
                });
            }
            setHasUnreadNews(unreadNews || unreadInteractions);
        });

        const unsubInteractions = window.fb.onSnapshot(window.fb.query(window.fb.collection(window.fb.db, "interactions"), window.fb.where("recipientUid", "==", user.uid)), (snapshot) => {
            unreadInteractions = snapshot.docs.some(doc => doc.data().seen === false);
            setHasUnreadNews(unreadNews || unreadInteractions);
        });

        return () => { unsubNews(); unsubInteractions(); };
    }, [user?.uid, isBannedStatus]);

    useEffect(() => {
        if (!user || isBannedStatus) return; 
        const userRef = window.fb.doc(window.fb.db, "users", user.uid);
        window.fb.updateDoc(userRef, { isOnline: true }).catch(()=>{});

        const handleUnload = () => { window.fb.updateDoc(userRef, { isOnline: false }).catch(()=>{}); };
        const handleOffline = () => { window.fb.updateDoc(userRef, { isOnline: false }).catch(()=>{}); };
        const handleOnline = () => { window.fb.updateDoc(userRef, { isOnline: true }).catch(()=>{}); };

        window.addEventListener('beforeunload', handleUnload);
        window.addEventListener('offline', handleOffline);
        window.addEventListener('online', handleOnline);

        const unsubPhoto = window.fb.onSnapshot(userRef, (docSnap) => {
            if (docSnap.exists() && docSnap.data().photo) setUserPhoto(docSnap.data().photo);
        });

        return () => {
            window.removeEventListener('beforeunload', handleUnload);
            window.removeEventListener('offline', handleOffline);
            window.removeEventListener('online', handleOnline);
            unsubPhoto();
            window.fb.updateDoc(userRef, { isOnline: false }).catch(()=>{});
        };
    }, [user?.uid, isBannedStatus]);

    const handleInstall = async () => { if (deferredPrompt) { deferredPrompt.prompt(); const { outcome } = await deferredPrompt.userChoice; if (outcome === 'accepted') setDeferredPrompt(null); } };
    
    // إرجاع زر الرئيسية لطبيعته البسيطة
    const handleHomeButtonClick = () => setActiveTab('home');

    if (user && isBannedStatus && user?.email !== ADMIN_EMAIL) {
        setTimeout(() => { if(window.lucide) window.lucide.createIcons(); }, 50);
        return (
            <div className="min-h-screen bg-slate-50 dark:bg-dark-bg flex items-center justify-center p-4">
                <div className="bg-white dark:bg-dark-card p-8 rounded-3xl shadow-2xl max-w-sm w-full text-center border-t-4 border-red-500 animate-zoom-in">
                    <div className="w-20 h-20 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">{window.ManualIcons.logout}</div>
                    <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-2">حساب موقوف</h2>
                    <p className="text-slate-500 dark:text-dark-muted mb-6 text-sm">تم إيقاف حسابك من قِبل الإدارة لمخالفة القواعد.</p>
                    <button onClick={handleLogout} className="w-full h-12 bg-slate-900 dark:bg-slate-800 text-white rounded-xl font-bold hover:bg-black transition">تسجيل الخروج</button>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-slate-50 dark:bg-dark-bg transition-colors flex relative">
            <style>{`
                @keyframes iosDrop { 0% { transform: translate(-50%, -150%); opacity: 0; } 100% { transform: translate(-50%, 0); opacity: 1; } }
                .animate-ios-drop { animation: iosDrop 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
            `}</style>

            {toast && (
                <div onClick={() => { if (toast.onClick) toast.onClick(); setToast(null); }} className="fixed top-6 left-1/2 w-[90%] max-w-sm z-[200] bg-white/90 dark:bg-dark-card/90 backdrop-blur-xl border border-slate-200/50 dark:border-dark-border/50 shadow-[0_10px_40px_rgba(0,0,0,0.15)] dark:shadow-[0_10px_40px_rgba(0,0,0,0.6)] rounded-2xl p-3 flex items-center gap-3 cursor-pointer animate-ios-drop">
                    <div className="w-12 h-12 rounded-full overflow-hidden shrink-0 bg-indigo-50 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-500">
                        {toast.photo ? <img src={toast.photo} className="w-full h-full object-cover" /> : window.ManualIcons.user}
                    </div>
                    <div className="flex-1 overflow-hidden">
                        <h4 className="font-bold text-sm text-slate-800 dark:text-white truncate">{toast.title}</h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">{toast.message}</p>
                    </div>
                </div>
            )}

            <window.ConfirmModal isOpen={modalConfig.isOpen} title={modalConfig.title} message={modalConfig.message} type={modalConfig.type} onConfirm={() => { if(modalConfig.onConfirm) modalConfig.onConfirm(); closeAlert(); }} onCancel={closeAlert} />
            
            {window.DesktopSidebar && (
                <window.DesktopSidebar 
                    user={user} onLoginClick={onLoginClick}
                    activeTab={activeTab} setActiveTab={setActiveTab} 
                    deferredPrompt={deferredPrompt} handleInstall={handleInstall} 
                    darkMode={darkMode} setDarkMode={setDarkMode} 
                    showAlert={showAlert} handleLogout={handleLogout} 
                    hasUnreadNews={hasUnreadNews} 
                />
            )}

            <div className="flex-1 flex flex-col h-screen overflow-hidden relative">
                
                {window.MobileHeader && (
                    <window.MobileHeader 
                        user={user} onLoginClick={onLoginClick}
                        setActiveTab={setActiveTab} darkMode={darkMode} 
                        setDarkMode={setDarkMode} activeTab={activeTab} 
                        hasUnreadNews={hasUnreadNews} userPhoto={userPhoto} 
                        handleLogout={handleLogout} showAlert={showAlert}
                    />
                )}

                <main className="flex-1 overflow-y-auto p-4 lg:p-8 custom-scrollbar pb-32 lg:pb-8 relative">
                    <div className="max-w-5xl mx-auto">
                        
                        {!user ? (
                            <GuestLockedView onLoginClick={onLoginClick} />
                        ) : (
                            <>
                                {activeTab === 'home' && window.HomeView && <window.HomeView user={user} setTab={setActiveTab} showAlert={showAlert}/>}
                                {activeTab === 'ai' && window.AiView && <window.AiView user={user} showAlert={showAlert} />}
                                {activeTab === 'academic' && window.AcademicView && <window.AcademicView user={user} showAlert={showAlert} />}
                                {activeTab === 'agenda' && window.AgendaView && <window.AgendaView user={user} showAlert={showAlert}/>}
                                {activeTab === 'content' && window.ContentView && <window.ContentView user={user} showAlert={showAlert}/>}
                                {activeTab === 'forum' && window.ForumView && <window.ForumView user={user} showAlert={showAlert} setTab={setActiveTab} />}
                                {activeTab === 'notifications' && window.NotificationsView && <window.NotificationsView user={user} showAlert={showAlert} setTab={setActiveTab} />}
                                {activeTab === 'profile' && window.ProfileView && <window.ProfileView user={user} setTab={setActiveTab} showAlert={showAlert}/>}
                                {activeTab === 'chat' && window.ProfileView && <window.ProfileView user={user} setTab={setActiveTab} showAlert={showAlert} forceTab="chats" />}
                                {activeTab === 'admin' && window.AdminPanelView && <window.AdminPanelView user={user} showAlert={showAlert}/>}
                            </>
                        )}
                        
                    </div>
                </main>

                {window.MobileBottomNav && (
                    <window.MobileBottomNav 
                        activeTab={activeTab} setActiveTab={setActiveTab}
                        handleHomeButtonClick={handleHomeButtonClick} showAlert={showAlert}
                    />
                )}

            </div>
        </div>
    );
};
