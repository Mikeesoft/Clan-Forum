// --- app-layout.js ---
// ملف الواجهات الهيكلية (بشريط جانبي عمودي للتابلت + أيقونة إعدادات ذكية تتمدد حسب المكان 🪄)

// 🌟 الإصلاح هنا: استدعاء الدوال من React بشكل صحيح 🌟
var { useState, useEffect, useRef } = React;

// 🌟 أيقونة الإعدادات السحرية المطورة (تتمدد رأسي أو أفقي) 🌟
const MorphingSettings = ({ darkMode, setDarkMode, handleLogout, showAlert, direction = 'horizontal' }) => {
    const [isOpen, setIsOpen] = useState(false);
    const containerRef = useRef(null);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (containerRef.current && !containerRef.current.contains(event.target)) {
                setIsOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    const isVertical = direction === 'vertical';

    // إعدادات التصميم بناءً على الاتجاه
    const openClass = isVertical 
        ? 'w-10 h-24 flex-col py-1 animate-fade-in' 
        : 'w-24 h-10 flex-row px-1 animate-fade-in';
    
    const closedClass = 'w-10 h-10';

    return (
        <div 
            ref={containerRef} 
            className={`relative flex items-center justify-center transition-all duration-500 ease-in-out overflow-hidden ${isOpen ? 'bg-slate-200 dark:bg-slate-800 rounded-[20px] shadow-inner ' + openClass : 'bg-slate-100 dark:bg-dark-bg hover:bg-slate-200 dark:hover:bg-slate-800 rounded-[14px] cursor-pointer ' + closedClass}`}
        >
            {/* أيقونة الترس الأصلي */}
            <button 
                onClick={() => setIsOpen(true)} 
                className={`absolute flex items-center justify-center w-full h-full text-slate-600 dark:text-slate-400 transition-all duration-500 ${isOpen ? 'opacity-0 scale-50 rotate-180 pointer-events-none' : 'opacity-100 scale-100 rotate-0'}`}
            >
                {window.ManualIcons.settings}
            </button>

            {/* الأيقونات الداخلية التي تظهر عند التمدد */}
            <div className={`flex items-center justify-between w-full h-full transition-all duration-500 ${isOpen ? 'opacity-100 scale-100' : 'opacity-0 scale-50 absolute pointer-events-none'} ${isVertical ? 'flex-col' : 'flex-row'}`}>
                <button 
                    onClick={() => { setDarkMode(!darkMode); setIsOpen(false); }} 
                    className="w-8 h-8 flex items-center justify-center text-slate-700 dark:text-slate-200 hover:text-indigo-600 bg-white dark:bg-dark-card rounded-full shadow-sm transition-transform hover:scale-110 active:scale-90" 
                    title={darkMode ? "تفعيل النهاري" : "تفعيل الليلي"}
                >
                    {darkMode ? window.ManualIcons.sun : window.ManualIcons.moon}
                </button>
                
                <button 
                    onClick={() => { setIsOpen(false); showAlert("تسجيل الخروج", "هل تود تسجيل الخروج من حسابك؟", "danger", handleLogout); }} 
                    className="w-8 h-8 flex items-center justify-center text-red-500 hover:text-red-700 bg-white dark:bg-dark-card rounded-full shadow-sm transition-transform hover:scale-110 active:scale-90" 
                    title="خروج"
                >
                    {window.ManualIcons.logout}
                </button>
            </div>
        </div>
    );
};

const SlimNavItem = ({ id, activeTab, setActiveTab, iconKey, label, hasBadge }) => (
    <button onClick={() => setActiveTab(id)} className={`w-12 h-12 mb-2 rounded-2xl flex flex-col items-center justify-center transition-all relative group ${activeTab === id ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-500 hover:bg-indigo-50 hover:text-indigo-600 dark:text-slate-400 dark:hover:bg-indigo-900/30'}`}>
        {window.ManualIcons[iconKey]}
        {hasBadge && <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white dark:border-dark-card animate-pulse"></span>}
        <span className="absolute right-14 bg-slate-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50 shadow-lg">
            {label}
        </span>
    </button>
);

// 🌟 نسخة التابلت والديسكتوب (عمودية) 🌟
window.DesktopSidebar = ({ user, activeTab, setActiveTab, onLoginClick, deferredPrompt, handleInstall, darkMode, setDarkMode, showAlert, handleLogout, hasUnreadNews }) => (
    <aside className="hidden lg:flex flex-col items-center w-20 bg-white dark:bg-dark-card border-l border-slate-200 dark:border-dark-border py-6 shadow-sm z-50 sticky top-0 h-screen">
        <div className="text-indigo-600 dark:text-indigo-400 mb-8 cursor-pointer hover:scale-110 transition" onClick={() => setActiveTab('home')}>
            {window.ManualIcons.gradcap}
        </div>
        
        <nav className="flex-1 flex flex-col items-center w-full px-2">
            <SlimNavItem id="home" activeTab={activeTab} setActiveTab={setActiveTab} iconKey="home" label="الرئيسية" />
            <SlimNavItem id="notifications" activeTab={activeTab} setActiveTab={setActiveTab} iconKey="bell" label="الإشعارات" hasBadge={hasUnreadNews} />
            <SlimNavItem id="ai" activeTab={activeTab} setActiveTab={setActiveTab} iconKey="bot" label="المساعد الذكي" />
            <div className="w-10 h-px bg-slate-200 dark:bg-dark-border my-2"></div>
            <SlimNavItem id="academic" activeTab={activeTab} setActiveTab={setActiveTab} iconKey="academic" label="أكاديمي" />
            <SlimNavItem id="agenda" activeTab={activeTab} setActiveTab={setActiveTab} iconKey="agenda" label="الأجندة" />
            <SlimNavItem id="content" activeTab={activeTab} setActiveTab={setActiveTab} iconKey="content" label="المحتوى" />
            <SlimNavItem id="forum" activeTab={activeTab} setActiveTab={setActiveTab} iconKey="forum" label="المنتدى" />
        </nav>
        
        <div className="mt-auto flex flex-col items-center gap-4 w-full px-2">
            {deferredPrompt && (
                <button onClick={handleInstall} className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center hover:bg-emerald-100 transition shadow-sm" title="تثبيت التطبيق">
                    {window.ManualIcons.download}
                </button>
            )}
            
            {/* هنا حددنا الاتجاه عمودي (vertical) للتابلت */}
            <MorphingSettings darkMode={darkMode} setDarkMode={setDarkMode} handleLogout={handleLogout} showAlert={showAlert} direction="vertical" />
            
            <div onClick={user ? () => setActiveTab('profile') : onLoginClick} className={`w-10 h-10 mt-2 rounded-xl overflow-hidden cursor-pointer border-2 transition-all flex items-center justify-center ${!user ? 'border-indigo-500 bg-indigo-600 text-white' : activeTab === 'profile' ? 'border-indigo-500 shadow-md transform scale-110' : 'border-slate-200 dark:border-dark-border hover:border-indigo-300 bg-slate-100 dark:bg-dark-bg'}`} title={user ? 'حسابي' : 'تسجيل الدخول'}>
                {user ? ( window.userPhoto ? <img src={window.userPhoto} className="w-full h-full object-cover" /> : window.ManualIcons.user ) : (
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="rtl:-scale-x-100"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path><polyline points="10 17 15 12 10 7"></polyline><line x1="15" y1="12" x2="3" y2="12"></line></svg>
                )}
            </div>
        </div>
    </aside>
);

// 🌟 نسخة الموبايل (أفقية) 🌟
window.MobileHeader = ({ user, setActiveTab, onLoginClick, darkMode, setDarkMode, activeTab, hasUnreadNews, userPhoto, handleLogout, showAlert }) => (
    <header className="lg:hidden bg-white dark:bg-dark-card border-b border-slate-200 dark:border-dark-border p-4 flex justify-between items-center z-40 sticky top-0 shadow-sm">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setActiveTab('home')}>
            <div className="text-indigo-600 dark:text-indigo-400 w-6 h-6">{window.ManualIcons.gradcap}</div>
            <span className="font-bold text-lg text-slate-800 dark:text-white">جامعتي</span>
        </div>
        
        <div className="flex items-center gap-2">
            <button onClick={() => setActiveTab('notifications')} className={`relative p-2 rounded-[14px] transition-all ${activeTab === 'notifications' ? 'bg-indigo-100 text-indigo-600 dark:bg-indigo-900/40' : 'bg-slate-100 dark:bg-dark-bg text-slate-600 dark:text-slate-400'}`}>
                {window.ManualIcons.bell}
                {hasUnreadNews && <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white dark:border-dark-bg animate-pulse"></span>}
            </button>

            {/* هنا الاتجاه الافتراضي أفقي (horizontal) للموبايل */}
            <MorphingSettings darkMode={darkMode} setDarkMode={setDarkMode} handleLogout={handleLogout} showAlert={showAlert} direction="horizontal" />
            
            <div onClick={user ? () => setActiveTab('profile') : onLoginClick} className={`w-10 h-10 ml-1 rounded-xl overflow-hidden cursor-pointer border-2 transition-all flex items-center justify-center ${!user ? 'border-indigo-500 shadow-md bg-indigo-600 text-white' : activeTab === 'profile' ? 'border-indigo-500 shadow-md transform scale-110' : 'border-slate-200 dark:border-dark-border hover:border-indigo-300'}`}>
                {user ? ( userPhoto ? <img src={userPhoto} alt="User" className="w-full h-full object-cover" /> : <div className="w-full h-full bg-slate-100 dark:bg-dark-bg flex items-center justify-center text-slate-400">{window.ManualIcons.user}</div> ) : (
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="rtl:-scale-x-100"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path><polyline points="10 17 15 12 10 7"></polyline><line x1="15" y1="12" x2="3" y2="12"></line></svg>
                )}
            </div>
        </div>
    </header>
);

const BottomNavItem = ({ id, activeTab, setActiveTab, iconKey, label }) => (
    <button onClick={() => setActiveTab(id)} className={`flex flex-col items-center justify-center w-full py-1 transition-all ${activeTab === id ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400 dark:text-slate-500 hover:text-indigo-500'}`}>
        <span className={`flex items-center justify-center w-8 h-8 rounded-xl mb-1 transition-all ${activeTab === id ? 'bg-indigo-100 dark:bg-indigo-900/40 shadow-sm' : ''}`}>
            {window.ManualIcons[iconKey]}
        </span> 
        <span className="text-[9px] font-bold">{label}</span>
    </button>
);

window.MobileBottomNav = ({ activeTab, setActiveTab, handleHomeButtonClick }) => {
    return (
        <nav className="lg:hidden fixed bottom-6 left-0 right-0 mx-auto w-[calc(100%-2rem)] md:w-[500px] bg-white/95 dark:bg-dark-card/95 backdrop-blur-xl border border-slate-200 dark:border-dark-border/50 rounded-3xl z-[100] flex items-center justify-between px-2 h-16 shadow-[0_8px_30px_rgb(0,0,0,0.15)] dark:shadow-xl">
            <div className="flex flex-1 justify-around items-center h-full">
                <BottomNavItem id="academic" activeTab={activeTab} setActiveTab={setActiveTab} iconKey="academic" label="أكاديمي" />
                <BottomNavItem id="agenda" activeTab={activeTab} setActiveTab={setActiveTab} iconKey="agenda" label="الأجندة" />
            </div>
            
            <div className="relative -top-5 flex justify-center w-16 shrink-0 z-10">
                <button onClick={handleHomeButtonClick} className={`relative w-14 h-14 flex items-center justify-center rounded-full text-white shadow-xl transition-all duration-300 border-[5px] border-slate-50 dark:border-dark-bg ${activeTab === 'home' ? 'bg-indigo-600 scale-110' : 'bg-slate-700 dark:bg-slate-600 hover:scale-105'}`}>
                    <div className="w-6 h-6 flex items-center justify-center">{window.ManualIcons.home}</div>
                </button>
            </div>

            <div className="flex flex-1 justify-around items-center h-full">
                <BottomNavItem id="forum" activeTab={activeTab} setActiveTab={setActiveTab} iconKey="forum" label="المنتدى" />
                <BottomNavItem id="content" activeTab={activeTab} setActiveTab={setActiveTab} iconKey="content" label="المحتوى" />
            </div>
        </nav>
    );
};
 